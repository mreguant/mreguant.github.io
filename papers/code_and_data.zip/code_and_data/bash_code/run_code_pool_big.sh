#!/bin/bash

# Code to run several instances of simulations in parallel

rm jobs_list_big.txt

for m in 6 9 12 13 17 19 2 3 5 8
do 

echo run_code_job_single.sh $m 0.0 23232 0 1>>jobs_list_big.txt

for a in 14848 31284 59595 21294
do 
for p in 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0
do

echo run_code_job_single.sh $m $p $a 0 1>>jobs_list_big.txt

done
done
done

cat jobs_list_big.txt | xargs -L1 -P12 bash
