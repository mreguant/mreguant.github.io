#!/bin/bash

java -Xmx20024m -XX:+HeapDumpOnOutOfMemoryError \
-Djava.net.preferIPv4Stack=true -Dapple.awt.UIElement=true \
-cp "java_libraries/*":"java_code/" \
simulation.main.SimulationJob $1 $2 $3 $4
