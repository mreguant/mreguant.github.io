#!/bin/bash

#List of markets with less than 4 firms: 4 7 11 14 15 18

rm jobs_list_robustness.txt

for i in 11 4 7 14 15 18
do

for e in 1 1.5 2 2.5 3 3.5
do

echo -Djava.net.preferIPv4Stack=true -Dapple.awt.UIElement=true \
-cp "java_libraries/*":"java_code/" \
simulation.main.SimulationElasticity $i 0 23232 $e 1>>jobs_list_robustness.txt 

for p in 5.0 15.0 25.0 35.0 45.0 55.0 65.0
do

for m in 14848 21294 31284 59595
do

echo -Djava.net.preferIPv4Stack=true -Dapple.awt.UIElement=true \
-cp "java_libraries/*":"java_code/" \
simulation.main.SimulationElasticity $i $p $m $e 1>>jobs_list_robustness.txt

done
done

done
done

cat jobs_list_robustness.txt | xargs -L1 -P8 java
