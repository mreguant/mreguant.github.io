#!/bin/bash

# Code to run several instances of simulations in parallel

rm jobs_dynamic_elasticity_list.txt

for e in 1 1.5 2.5 3 3.5
do 

echo run_code_estimation_elasticity.sh 0 0.9 $e 2.5 >>jobs_dynamic_elasticity_list.txt

done

for e in 1.5 2 3 3.5 4
do 

echo run_code_estimation_elasticity.sh 0 0.9 2 $e >>jobs_dynamic_elasticity_list.txt

done

cat jobs_dynamic_elasticity_list.txt | xargs -L1 -P1 bash
