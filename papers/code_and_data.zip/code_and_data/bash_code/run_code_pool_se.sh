#!/bin/bash

# Code to run several instances of simulations in parallel

rm jobs_list_se.txt


for d in {1..50}
do

for m in 11 4 7 14 15 18
do
echo run_code_job_single.sh $m 0.0 23232 $d 1>>jobs_list_se.txt
for a in 14848 31284 59595 21294
do
for p in 15.0 30.0 45.0 60.0
do
echo run_code_job_single.sh $m $p $a $d 1>>jobs_list_se.txt
done
done
done

done

cat jobs_list_se.txt | xargs -L1 -P18 bash
