#!/bin/bash

# Code to run several instances of simulations in parallel

rm jobs_dynamic_list.txt

for m in {1..99}
do 

echo run_code_estimation_baseline.sh $m >>jobs_dynamic_list.txt

done

cat jobs_dynamic_list.txt | xargs -L1 -P1 bash
