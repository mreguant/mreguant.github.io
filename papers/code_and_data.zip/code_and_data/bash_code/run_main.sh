#!/bin/bash

# Code to run "Market-Based Emissions Regulation and Industry Dynamics"
# Meredith L. Fowlie, Mar Reguant and Stephen Ryan (2014)

# IMPORTANT: to run this code one needs to install IBM ILOG Cplex, which is
# available for free under the Academic Initiative.
# The following bash files need to be modified to reflect the IBM ILOG Cplex path:
#  - run_code_estimation*

# WARNING: bash files are set up to process in parallel. Bash files can be modified
# to taylor number of parallel processes to the capabilities of the local machine.


# preliminaries --------------------------------------------------------------------------
# create a sub-folder estimation that will populate with estimation results
mkdir data/estimation


# minimal version (baseline estimation + simulation N=2,3 markets) -----------------------
bash bash_code/run_code_estimation_baseline.sh 	#(base estimation)
bash bash_code/run_code_static.sh 				#(static outcomes)
bash bash_code/run_code_pool.sh					#(dynamic outcomes small markets)


# full version (uncomment to run) --------------------------------------------------------
# estimation  -- section 5
# bash bash_code/run_code_dynamic_pool.sh			#(bootstrap estimation, 100 draws)
# 
# simulations -- section 6
# bash bash_code/run_static_outcomes.sh 			#(static outcomes)
# bash bash_code/run_code_pool.sh					#(dynamic outcomes small markets)
# bash bash_code/run_code_pool_big.sh				#(dynamic outcomes big markets)
# bash bash_code/run_code_robustness.sh			#(robustness demand elasticity)
# bash bash_code/run_code_robustness_imports.sh	#(robustness import elasticity)
# bash bash_code/run_code_pool_se.sh				#(dynamic outcomes bootstrap)
# bash bash_code/run_code_robustness_beta.sh		#(robustness discount factor)
