#!/bin/bash

java -Xmx20024m -XX:+HeapDumpOnOutOfMemoryError \
-Djava.net.preferIPv4Stack=true -Dapple.awt.UIElement=true \
-cp "java_libraries/*":"java_code/" \
simulation.solve.ComputeStaticOutcomes
