#!/bin/bash

java -Djava.library.path="/Users/macmreguant/Applications/ILOG/CPLEX_Studio126/cplex/bin/x86-64_osx/" -Xms1524M -Xmx4048M \
-cp "/Users/macmreguant/Applications/ILOG/CPLEX_Studio126/cplex/lib/*":\
"java_libraries/*":"java_code/" \
estimation.main.EstimationMain $1
