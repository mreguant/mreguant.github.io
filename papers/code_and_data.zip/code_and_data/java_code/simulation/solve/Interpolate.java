/**
 * Interpolate.java
 * 
 * Auxiliary functions to perform a cubic interpolation.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package simulation.solve;

import Jama.Matrix;


public class Interpolate {

	private Jama.Matrix triMatrixInverse;
	private Jama.Matrix idata;
	private Jama.Matrix icoeff;
	private Jama.Matrix ones;
	private Jama.Matrix onesc;
	private Jama.Matrix matpp;

	public Interpolate(int N) {
		triMatrixInverse = (diagI(N - 2, 0).times(4)).plus(
				diagI(N - 3, 1).plus(diagI(N - 3, -1))).inverse();
		idata = new Matrix(N, 1);
		icoeff = new Matrix(N + 2, 1);
		ones = new Matrix(N, 1);
		onesc = new Matrix(N + 2, 1);
		for (int i = 0; i < N; i++) {
			idata.set(i, 0, i);
			ones.set(i, 0, 1);
			icoeff.set(i, 0, i);
			onesc.set(i, 0, 1);
		}
		for (int i = N; i < N + 2; i++) {
			icoeff.set(i, 0, i);
			onesc.set(i, 0, 1);
		}
		double[][] array = { { 0, 0, 0, 0 }, { -.5, 0, .5, 0 },
				{ 1, -2, 1, 0 }, { -1, 3, -3, 1 } };
		matpp = new Jama.Matrix(array);
		matpp.set(0, 0, (double) 1 / 6);
		matpp.set(0, 1, (double) 2 / 3);
		matpp.set(0, 2, (double) 1 / 6);
	}

	// Method to get coefficients of unform cubic spline -----------------------
	public Jama.Matrix getCoeff(Jama.Matrix y, double alpha, double beta,
			int D, int N, double h) {
		// y contains VECTOR with value at different points
		// alpha and beta are terminal conditions
		// D is dimension and N number of points per dimension
		// h indicates the distance between points (uniformly spaced)

		Jama.Matrix c = new Matrix((int) java.lang.Math.pow((N + 2), D), 1);
		Jama.Matrix cint = new Matrix((int) java.lang.Math.pow((N + 2), D), 1);
		cint.setMatrix(0, (int) java.lang.Math.pow(N, D) - 1, 0, 0, y);

		Jama.Matrix bdata = new Matrix(N, 1);
		Jama.Matrix bcoeff = new Matrix(N + 2, 1);

		double factor = java.lang.Math.pow(h, 2) / 6;

		for (int d = 0; d < D; d++) {// need to do as many iterations as the
										// dimension of the spline
			for (int i = 0; i < java.lang.Math.pow(N, D - d - 1); i++) {
				for (int j = 0; j < java.lang.Math.pow(N + 2, d); j++) {

					// prepare index
					bdata.setMatrix(0, N - 1, 0, 0, (idata.times(java.lang.Math
							.pow((N + 2), d))).plus(ones.times(i * N
							* java.lang.Math.pow(N + 2, d) + j)));
					bcoeff.setMatrix(0, N + 1, 0, 0, (icoeff
							.times(java.lang.Math.pow((N + 2), d))).plus(onesc
							.times(i * java.lang.Math.pow(N + 2, d + 1) + j)));

					// second coefficients
					c.set((int) bcoeff.get(1, 0), 0,
							(cint.get((int) bdata.get(0, 0), 0) - alpha
									* factor) / 6);
					c.set((int) bcoeff.get(N, 0), 0,
							(cint.get((int) bdata.get(N - 1, 0), 0) - beta
									* factor) / 6);

					// inner coefficients
					Matrix yModified = new Matrix(N - 2, 1);
					yModified.set(
							0,
							0,
							cint.get((int) bdata.get(1, 0), 0)
									- c.get((int) bcoeff.get(1, 0), 0));
					yModified.set(
							N - 3,
							0,
							cint.get((int) bdata.get(N - 2, 0), 0)
									- c.get((int) bcoeff.get(N, 0), 0));
					int[] relevant1 = new int[N - 4];
					for (int n = 0; n < N - 4; n++) {
						relevant1[n] = (int) bdata.get(n + 2, 0);
					}
					yModified.setMatrix(1, N - 4, 0, 0,
							cint.getMatrix(relevant1, 0, 0));
					int[] relevant = new int[N - 2];
					for (int n = 0; n < N - 2; n++) {
						relevant[n] = (int) bcoeff.get(n + 2, 0);
					}
					c.setMatrix(relevant, 0, 0,
							triMatrixInverse.times(yModified));

					// outer coefficients
					c.set((int) bcoeff.get(0, 0),
							0,
							alpha * factor + 2
									* c.get((int) bcoeff.get(1, 0), 0)
									- c.get((int) bcoeff.get(2, 0), 0));
					c.set((int) bcoeff.get(N + 1, 0),
							0,
							beta * factor + 2
									* c.get((int) bcoeff.get(N, 0), 0)
									- c.get((int) bcoeff.get(N - 1, 0), 0));
				}
			}
			cint.setMatrix(0, (int) (java.lang.Math.pow((N + 2), D) - 1), 0, 0,
					c.getMatrix(0, (int) java.lang.Math.pow((N + 2), D) - 1, 0,
							0));
		}
		c.timesEquals(java.lang.Math.pow(6, D)); // normalize coefficients
		return c;
	}

	// Method to evaluate a uniform cubic spline at a point --------------------
	// need to make it more efficient for the forward simulation
	public static double getValue(Jama.Matrix x, Jama.Matrix c, int D, int N,
			double a, double h) {
		// x contains VECTOR with point to evaluate (size D)
		// c are the coefficients (i.e. obtained with getCoeff)
		// D is dimension and N number of points per dimension
		// a is the value of the first grid point
		// h indicates the distance between points (uniformly spaced)

		double fval = 0;
		if (D != x.getRowDimension()) {
			System.out.println("Size of vector and dimension not consistent!");
		}
		// determine relevant coefficients (non-zero basis)
		double[][] basis = new double[D][4];
		int[][] index = new int[D][4];
		for (int d = 0; d < D; d++) {
			int ind = (int) java.lang.Math.floor((x.get(d, 0) - a) / h);
			for (int k = java.lang.Math.max(ind, 0); k < java.lang.Math.min(
					ind + 4, N + 2); k++) { // loop only relevant states
				basis[d][k - ind] = cubicFunction(x.get(d, 0), k, N, a, h);
				index[d][k - ind] = k;
			}
		}
		// loop to get value
		for (int k = 0; k < java.lang.Math.pow(4, D); k++) {
			double bs = 1;
			int ind = 0;
			for (int d = 0; d < D; d++) {
				int j = (int) (java.lang.Math.floor(k
						/ java.lang.Math.pow(4, d)) - java.lang.Math.floor(k
						/ java.lang.Math.pow(4, d + 1)) * 4);
				bs = bs * basis[d][j];
				ind += index[d][j] * java.lang.Math.pow(N + 2, D - d - 1);
			}
			fval = fval + bs * c.get(ind, 0);
		}
		return fval;
	}

	// Method to obtain the optimum of a uniform cubic spline -----------------
	public double getOptimum(Jama.Matrix c, int D, int N, double a, double h) {
		// c are the coefficients (i.e. obtained with getCoeff)
		// D is dimension and N number of points per dimension
		// a is the value of the first grid point
		// h indicates the distance between points (uniformly spaced)
		if (D > 1) {
			System.out.println("Only available for one-dimensional spline!!!");
			return 0.0;
		} else {
			Jama.Matrix ppform = new Jama.Matrix(N - 1, 4);
			Jama.Matrix coeff = new Jama.Matrix(4, 1);
			// get ppform
			for (int i = 1; i < N; i++) {
				coeff.set(0, 0, c.get(i - 1, 0));
				coeff.set(1, 0, c.get(i, 0));
				coeff.set(2, 0, c.get(i + 1, 0));
				coeff.set(3, 0, c.get(i + 2, 0));
				ppform.setMatrix(i - 1, i - 1, 0, 3, matpp.times(coeff)
						.transpose());
			}
			// find possible candidates, evaluate them, and compare them
			double best = -100000;
			double value;
			double optimum = 0;
			// evaluate tails
			value = Interpolate.getValue(a, c, D, N, a, h);
			if (value > best) {
				best = value;
				optimum = a;
			}
			value = Interpolate.getValue(a + (N - 1) * h, c, D, N, a, h);
			if (value > best) {
				best = value;
				optimum = a + (N - 1) * h;
			}
			// evaluate interior candidates
			for (int i = 0; i < N - 1; i++) {
				double candidate = 0;
				double A = ppform.get(i, 3) / (2 * java.lang.Math.pow(h, 3)); // 3*a
				double B = ppform.get(i, 2) / java.lang.Math.pow(h, 2); // 2*b
				double C = ppform.get(i, 1) / h;
				double T = java.lang.Math.sqrt(java.lang.Math.pow(B, 2) - 4 * A
						* C);
				if (java.lang.Math.pow(B, 2) - 4 * A * C >= 0) {
					candidate = (-B + T) / (2 * A);
					// positive
					if (candidate >= 0 & candidate <= h) {
						// System.out.println(a+i*h+candidate);
						value = Interpolate.getValue(a + i * h + candidate, c,
								D, N, a, h);
						if (value > best) {
							best = value;
							optimum = a + i * h + candidate;
						}
					}
					// negative
					candidate = (-B - T) / (2 * A);
					// System.out.println(a+i*h+candidate);
					if (candidate >= 0 & candidate <= h) {
						// System.out.println(a+i*h+candidate +" "+
						// Interpolate.getValue(a+i*h+candidate, c, D, N));
						value = Interpolate.getValue(a + i * h + candidate, c,
								D, N, a, h);
						if (value > best) {
							best = value;
							optimum = a + i * h + candidate;
						}
					}
				}
			}
			return optimum;
		}
	}

	// Method to evaluate a single-dimensional uniform cubic spline at a point -
	public static double getValue(double x, Jama.Matrix c, int D, int N,
			double a, double h) {
		// x contains point to evaluate
		// c are the coefficients (i.e. obtained with getCoeff)
		// D is dimension and N number of points per dimension (should be 1)
		// a is the value of the first grid point
		// h indicates the distance between points (uniformly spaced)

		double fval = 0;
		if (D != 1) {
			System.out.println("Not valid dimension!");
			return 0;
		}
		// efficient: loop only over relevant coefficients (non-zero basis)
		int index = (int) java.lang.Math.floor((x - a) / h);
		for (int k = index; k < java.lang.Math.min(index + 4, N + 2); k++) {
			double basis = cubicFunction(x, k, N, a, h);
			fval = fval + basis * c.get(k, 0);
		}
		return fval;
	}

	// Auxiliary function to get weights of spline -----------------------------
	// for a particular coefficient (returns double)
	public static double cubicFunction(double x, int c, int N, double a,
			double h) {
		double phi = 0;
		double t = java.lang.Math.abs((x - a) / h - c + 1);
		if (1 <= t & t <= 2) {
			phi = java.lang.Math.pow(2 - t, 3) / 6;
		} else if (t < 1) {
			phi = (4 - 6 * java.lang.Math.pow(t, 2) + 3 * java.lang.Math.pow(t,
					3)) / 6;
		}
		return phi;
	}

	// for all coefficients (returns Jama.Matrix)
	public static Jama.Matrix cubicFunction(double x, int N, double a, double h) {
		Jama.Matrix phi = new Jama.Matrix(1, N + 2);
		for (int i = 0; i < N + 2; i++) {
			double t = java.lang.Math.abs((x - a) / h - i + 1); // careful
																// wether there
																// is minimum or
																// not
			if (1 <= t & t <= 2) {
				phi.set(0, i, java.lang.Math.pow(2 - t, 3) / 6);
			} else if (t < 1) {
				phi.set(0, i,
						(4 - 6 * java.lang.Math.pow(t, 2) + 3 * java.lang.Math
								.pow(t, 3)) / 6);
			}
		}
		return phi;
	}

	// Auxiliary function to construct diagonal matrix -------------------------
	private static Jama.Matrix diagI(int size, int offset) {
		int d = java.lang.Math.abs(offset) + size;
		Matrix D = new Matrix(d, d);
		if (offset > 0) {
			for (int k = 0; k < size; k++) {
				D.set(k, k + offset, 1);
			}
		} else {
			for (int k = 0; k < size; k++) {
				D.set(k + java.lang.Math.abs(offset), k, 1);
			}
		}
		return D;
	}

	// try some of the functions
	public static void main(String[] args) {
		double prova = 1415;
		cubicFunction(prova, 4, 200, 600).print(0, 3);
		System.out.println(java.lang.Math.floor((prova - 200) / 600));
		System.out
				.println(cubicFunction(prova,
						(int) (java.lang.Math.floor((prova - 200) / 600)), 4,
						200, 600));
	}

}
