/**
 * stateSpace.java
 *
 * Creates an instance of the state space. A state space
 * contains all the different state space points, the
 * number of firms and the execution data (information about
 * the market and the policy considered).
 * It is set up to avoid duplicating symmetric states, e.g.
 * three firms with the same technology {200, 800, 400} and 
 * {200, 400, 800}.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package simulation.solve;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import javax.swing.*;


public class stateSpace {

	private ArrayList<stateSpacePoint> list;
	private ArrayList<expandedSpacePoint> expandedList;
	private int numFirms;
	private stateSpaceTableModel model;
	private int numStates;
	private ArrayList<Jama.Matrix> actionSpace;
	private ExecutionInformation executionData;

	/**
	 * Creates a new instance of stateSpace
	 */
	public stateSpace(ExecutionInformation executionData) {
		this.executionData = executionData;
		regionalMarket market = executionData.getMarket();
		numFirms = market.NUM_FIRMS;

		list = new ArrayList<stateSpacePoint>();
		expandedList = new ArrayList<expandedSpacePoint>();
		actionSpace = actionSpace(numFirms - 1);
		numStates = 0;
		// create combinations of types of firms (expanded state) - use symmetry
		// when possible
		Jama.Matrix seed = new Jama.Matrix(numFirms, 1);
		this.addExpandedSpace();

		ExecutorService tpes = Executors.newFixedThreadPool(1);
		ArrayList<Future<Integer>> futureList = new ArrayList<Future<Integer>>();
		for (int i = 0; i < expandedList.size(); i++) {
			Jama.Matrix expanded = expandedList.get(i).getMatrix();
			seed = new Jama.Matrix(numFirms, 2);
			seed.setMatrix(0, numFirms - 1, 1, 1, expanded);
			futureList.add(tpes.submit(new SetUpSpaceTask(this, seed, numFirms)));
			numStates += 1;
		}
		try {
			for (int i = 0; i < futureList.size(); i++) {
				futureList.get(i).get();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Collections.sort(list);
		Collections.sort(expandedList);

		tpes.shutdown();
	}

	/*
	 * implements state space with expanded state space and reduced states when
	 * possible
	 */
	public void addSeedingExpandedState(Jama.Matrix last, int level,
			int lastCap, ArrayList<stateSpacePoint> stateSeedingList,
			int maximumLevel) {
		if (level == maximumLevel) {
			if (lastCap == 0
					|| last.get(level - 1, 1) != last.get(level - 2, 1)) {
				Jama.Matrix vector = last.copy();
				vector.set(level - 1, 0, 0);
				if (vector.get(level - 1, 1) == 0) {
					stateSeedingList.add(new stateSpacePoint(vector, this,
							getExecutionData()));
				}
				for (int cap = getExecutionData().getMinCapacity(); cap <= getExecutionData()
						.getMaxCapacity(); cap += getExecutionData()
						.getCapacityIncrement()) {
					vector = last.copy();
					vector.set(level - 1, 0, cap);
					stateSeedingList.add(new stateSpacePoint(vector, this,
							getExecutionData()));
				}
			} else {
				for (int cap = lastCap; cap <= getExecutionData()
						.getMaxCapacity(); cap += getExecutionData()
						.getCapacityIncrement()) {
					Jama.Matrix vector = last.copy();
					vector.set(level - 1, 0, cap);
					stateSeedingList.add(new stateSpacePoint(vector, this,
							getExecutionData()));
				}
			}
		} else if (level == 1) {
			Jama.Matrix vector = last.copy();
			vector.set(level - 1, 0, lastCap);
			if (vector.get(level - 1, 1) == 0) {
				addSeedingExpandedState(vector, level + 1, lastCap,
						stateSeedingList, maximumLevel);
			}
			for (int cap = getExecutionData().getMinCapacity(); cap <= getExecutionData()
					.getMaxCapacity(); cap += getExecutionData()
					.getCapacityIncrement()) {
				vector = last.copy();
				vector.set(level - 1, 0, cap);
				addSeedingExpandedState(vector, level + 1, 0, stateSeedingList,
						maximumLevel);
			}
		} else {
			if (lastCap == 0
					|| last.get(level - 1, 1) != last.get(level - 2, 1)) {
				Jama.Matrix vector = last.copy();
				vector.set(level - 1, 0, lastCap);
				if (vector.get(level - 1, 1) == 0) {
					addSeedingExpandedState(vector, level + 1, lastCap,
							stateSeedingList, maximumLevel);
				}
				for (int cap = getExecutionData().getMinCapacity(); cap <= getExecutionData()
						.getMaxCapacity(); cap += getExecutionData()
						.getCapacityIncrement()) {
					vector = last.copy();
					vector.set(level - 1, 0, cap);
					addSeedingExpandedState(vector, level + 1, cap,
							stateSeedingList, maximumLevel);
				}
			} else {
				for (int cap = lastCap; cap <= getExecutionData()
						.getMaxCapacity(); cap += getExecutionData()
						.getCapacityIncrement()) {
					Jama.Matrix vector = last.copy();
					vector.set(level - 1, 0, cap);
					addSeedingExpandedState(vector, level + 1, cap,
							stateSeedingList, maximumLevel);
				}
			}
		}
	}

	// Creates expanded state space taking into account number of firms of each
	// type
	public void addExpandedSpace() {

		regionalMarket market = executionData.getMarket();
		Jama.Matrix vector = new Jama.Matrix(numFirms, 1, 0);
		for (int i = 0; i < numFirms; i++) {
			vector.set(i, 0, market.TYPE[i]);
		}
		// add relevant states when all active
		for (int j = 0; j < numFirms; j++) { // each firm as active firm
			Jama.Matrix swapOriginal = vector.copy();
			for (int i = 0; i < numFirms; i++) {
				if (i - j >= 0) {
					swapOriginal.set(i, 0, vector.get(i - j, 0));
				} else {
					swapOriginal.set(i, 0, vector.get(i - j + numFirms, 0));
				}
			}
			swapOriginal = sortOn(swapOriginal);
			if (!expandedList.contains(new expandedSpacePoint(swapOriginal))) {
				expandedList.add(new expandedSpacePoint(swapOriginal));
			}
			// adding vector when one entrant
			for (int k = 0; k < numFirms; k++) {
				Jama.Matrix swap = swapOriginal.copy();
				swap.set(k, 0, 0);
				swap = sortOn(swap);
				if (!expandedList.contains(new expandedSpacePoint(swap))) {
					expandedList.add(new expandedSpacePoint(swap));
				}
				// adding with two entrants
				for (int l = k; l < numFirms; l++) {
					swap = swapOriginal.copy();
					swap.set(k, 0, 0);
					swap.set(l, 0, 0);
					swap = sortOn(swap);
					if (!expandedList.contains(new expandedSpacePoint(swap))) {
						expandedList.add(new expandedSpacePoint(swap));
					}
					// adding with three entrants
					if (numFirms >= 3) {
						for (int m = l; m < numFirms; m++) {
							swap = swapOriginal.copy();
							swap.set(k, 0, 0);
							swap.set(l, 0, 0);
							swap.set(m, 0, 0);
							swap = sortOn(swap);
							if (!expandedList.contains(new expandedSpacePoint(
									swap))) {
								expandedList.add(new expandedSpacePoint(swap));
							}
							// adding with four entrants
							if (numFirms >= 4) {
								for (int n = m; n < numFirms; n++) {
									swap = swapOriginal.copy();
									swap.set(k, 0, 0);
									swap.set(l, 0, 0);
									swap.set(m, 0, 0);
									swap.set(n, 0, 0);
									swap = sortOn(swap);
									if (!expandedList
											.contains(new expandedSpacePoint(
													swap))) {
										expandedList
												.add(new expandedSpacePoint(
														swap));
									}
									// adding with five entrants
									if (numFirms >= 5) {
										for (int o = n; o < numFirms; o++) {
											swap = swapOriginal.copy();
											swap.set(k, 0, 0);
											swap.set(l, 0, 0);
											swap.set(m, 0, 0);
											swap.set(n, 0, 0);
											swap.set(o, 0, 0);
											swap = sortOn(swap);
											if (!expandedList
													.contains(new expandedSpacePoint(
															swap))) {
												expandedList
														.add(new expandedSpacePoint(
																swap));
											}
											// adding with six entrants
											if (numFirms >= 6) {
												for (int p = o; p < numFirms; p++) {
													swap = swapOriginal.copy();
													swap.set(k, 0, 0);
													swap.set(l, 0, 0);
													swap.set(m, 0, 0);
													swap.set(n, 0, 0);
													swap.set(o, 0, 0);
													swap.set(p, 0, 0);
													swap = sortOn(swap);
													if (!expandedList
															.contains(new expandedSpacePoint(
																	swap))) {
														expandedList
																.add(new expandedSpacePoint(
																		swap));
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	// This generates a list of others possible actions (not enter or exit,
	// stay, and stay and invest)
	public ArrayList<Jama.Matrix> actionSpace(int numberFirms) {
		Jama.Matrix seed = new Jama.Matrix(numberFirms, 1);
		ArrayList<Jama.Matrix> list = new ArrayList<Jama.Matrix>();
		actionSpace(seed, 1, list, numberFirms);
		return list;
	}

	private void actionSpace(Jama.Matrix last, int level,
			ArrayList<Jama.Matrix> list, int numberFirms) {
		int lastCap = 0;
		if (level == numberFirms) {
			for (int cap = lastCap; cap <= 2; cap += 1) {
				Jama.Matrix vector = last.copy();
				vector.set(level - 1, 0, cap);
				// vector.print(0,0);
				list.add(vector);
			}
		} else {
			for (int cap = lastCap; cap <= 2; cap += 1) {
				Jama.Matrix vector = last.copy();
				vector.set(level - 1, 0, cap);
				actionSpace(vector, level + 1, list, numberFirms);
			}
		}
	}

	public void setupSpace(ArrayList<stateSpacePoint> plist, int numberFirms) {
		list = plist;
		numFirms = numberFirms;
		model = new stateSpaceTableModel(this);
	}

	public ArrayList<stateSpacePoint> getList() {
		return list;
	}

	public ArrayList<expandedSpacePoint> getExpandedList() {
		return expandedList;
	}

	public stateSpaceTableModel getTableModel() {
		return model;
	}

	public int getNumFirms() {
		return numFirms;
	}

	public int getNumStates() {
		return numStates;
	}

	public ArrayList<Jama.Matrix> getActionSpace() {
		return actionSpace;
	}

	public JTable getTable(iteratedSolver solver) {
		model = new stateSpaceTableModel(this);
		JTable table = new JTable(model);
		return table;
	}

	public void updateTable(int row) {
		model.fireTableRowsUpdated(row, row);
	}

	public int getStateSpaceSize() {
		return list.size();
	}

	public void printResults() {
		for (int i = 0; i < list.size(); i++) {
			stateSpacePoint point = list.get(i);
			System.out.println(point + "," + point.getValue() + ","
					+ point.getPolicy() + "," + point.getEntryProbability()
					+ "," + point.getExitProbability());
		}
	}

	public stateSpacePoint getPoint(Jama.Matrix s) {
		// have to sort s
		s = sortOnFirmId(s);
		stateSpacePoint point = null;
		try {
			point = list.get(Collections.binarySearch(list,
					new stateSpacePoint(s, getExecutionData())));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("********** ");
			System.out.println("State not found!");
			s.print(0, 0);
			System.out.println("********** ");
		}
		return point;
	}

	public stateSpacePoint getPoint(Jama.Matrix s, int exchangeIndex) {
		Jama.Matrix ns = new Jama.Matrix(s.getRowDimension(),
				s.getColumnDimension());
		ns.setMatrix(0, s.getRowDimension() - 1, 0, s.getColumnDimension() - 1,
				s);
		ns.set(0, 0, s.get(exchangeIndex, 0));
		ns.set(exchangeIndex, 0, s.get(0, 0));
		ns.set(0, 1, s.get(exchangeIndex, 1));
		ns.set(exchangeIndex, 1, s.get(0, 1));
		ns = sortOnFirmId(ns);
		return getPoint(ns);
	}

	public stateSpacePoint getPoint(int i) {
		return list.get(i);
	}

	public int getPointIndex(stateSpacePoint state) {
		return list.indexOf(state);
	}

	public int getExpandedIndex(Jama.Matrix expanded) {
		expandedSpacePoint expandedState = expandedList.get(Collections
				.binarySearch(expandedList, new expandedSpacePoint(expanded)));
		return expandedList.indexOf(expandedState);
	}

	void updateTable() {
		model.fireTableDataChanged();
	}

	private Jama.Matrix sortOn(Jama.Matrix x) {
		// sort firms depending on their id (used in shortcut)
		int size = x.getRowDimension(); // number of firms
		Jama.Matrix temp = new Jama.Matrix(size, 1);
		temp.set(0, 0, x.get(0, 0)); // firm state
		ArrayList<Double> list = new ArrayList<Double>(size - 1);
		for (int i = 1; i < size; i++) {
			list.add(new Double(x.get(i, 0)));
		}
		Collections.sort(list);
		for (int i = 1; i < size; i++) {
			double value = (list.get(i - 1)).doubleValue();
			temp.set(i, 0, value);
		}
		return temp;
	}

	public Jama.Matrix sortOnFirmId(Jama.Matrix x) {
		// sort firms depending on their id (used in shortcut)
		int size = x.getRowDimension(); // number of firms
		Jama.Matrix temp = new Jama.Matrix(size, 2);
		temp.set(0, 0, x.get(0, 0)); // firm state
		temp.set(0, 1, x.get(0, 1)); // firm id
		int count = 0;
		int lastCount = 0;
		// select firms with different ids and sort them
		while (count <= size) {
			int intCount = 0;
			ArrayList<Double> list = new ArrayList<Double>(count);
			for (int i = 1; i < size; i++) {
				if (x.get(i, 1) == count) { // different type of firms
					list.add(new Double(x.get(i, 0)));
					intCount += 1;
				}
			}
			Collections.sort(list);
			for (int i = 0; i < intCount; i++) {
				double value = (list.get(i)).doubleValue();
				temp.set(lastCount + 1 + i, 0, value);
				temp.set(lastCount + 1 + i, 1, count);
			}
			lastCount += intCount;
			count += 1;
		}
		return temp;
	}

	/**
	 * @return the executionData
	 */
	public ExecutionInformation getExecutionData() {
		return executionData;
	}

	/**
	 * @param executionData
	 *            the executionData to set
	 */
	public void setExecutionData(ExecutionInformation executionData) {
		this.executionData = executionData;
	}
}
