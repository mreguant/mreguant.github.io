/**
 * expandedSpacePoint.java
 * 
 * Creates a given expanded state (combination of capacities
 * and technologies).
 * point is described by a Nx2 matrix. First column is capacities,
 * second column is technology types. 
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;

import utility.pmUtility;


public class expandedSpacePoint implements Comparable<expandedSpacePoint> {

	private Jama.Matrix point;

	public expandedSpacePoint(Jama.Matrix seed) {
		point = pmUtility.sortOnFirstElement(seed.copy());
	}

	public Jama.Matrix getMatrix() {
		return point;
	}

	@Override
	public int compareTo(expandedSpacePoint s) {
		for (int i = 0; i < s.getMatrix().getRowDimension(); i++) {
			if (s.getMatrix().get(i, 0) < point.get(i, 0)) { // modified: used
																// to be >
				return 1;
			}
			if (s.getMatrix().get(i, 0) > point.get(i, 0)) { // modified: used
																// to be <
				return -1;
			}
		}
		return 0;
	}

	@Override
	public int hashCode() {
		int result = 0;
		for (int i = 0; i < point.getRowDimension(); i++) {
			result = result + (int) (point.get(i, 0) * Math.pow(10, i));
		}
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj.hashCode() == this.hashCode())
			return true;
		return false;
	}
}
