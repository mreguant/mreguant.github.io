/**
 * ComputeStaticOutcomes.java
 * 
 * Computes the values of the static game for several markets, carbon 
 * prices and policies and stores the information in a CSV file.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package simulation.solve;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import simulation.utility.primitives;
import utility.pmUtility;


public class ComputeStaticOutcomes {

	public ComputeStaticOutcomes() {
	}

	public static void main(String[] args) {
		
		String file = "data/regional_list/regionalList_nocustom.raw";
		regionalList regional = new regionalList(file);

		/**
		 * Prices evaluated
		 */
		double[] listPrice = { 5.0, 10.0, 15, 20.0, 25.0, 30, 35.0, 40.0, 45.0, 50.0, 55.0, 60, 65.0 };

		BufferedWriter out = null;
		try {
			out = new BufferedWriter(new FileWriter("data/static_simulation_data.csv"));
			out.write("epa_market,mechanism,welfare,cs,profit,carbonrevenue,emissions,leakage,price,quantity,capacity,num_firms,carbonprice\n");

			for (regionalMarket market : regional) {
				
				ExecutionInformation executionData = new ExecutionInformation();
				executionData.setImportIntercept(market.IMPORT_INTERCEPT);
				executionData.setImportElasticity(market.IMPORT_ELASTICITY);

				System.out.println("Parameters for market " + market.name);
				System.out.println(String.format("%d Firms: Firm 1 type %d and capacity %f",
						market.NUM_FIRMS, market.TYPE[0], market.CAPACITY[0]));
						
				double[] mgcosts = readMgParam(0);
				primitives.MARGINAL_COST_ENTRANT = mgcosts[3];
				primitives.MARGINAL_COST_INCUMBENT1 = mgcosts[3];
				primitives.MARGINAL_COST_INCUMBENT2 = mgcosts[3];
				primitives.CAPACITY_COST = mgcosts[1];
				primitives.CAPACITY_COST_BINDING_LEVEL = mgcosts[2];
			
				for (int i = 0; i < market.NUM_FIRMS; i++) {					
					if (market.TYPE[i] == 1) {// first incumbent
						market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT1;
						market.ERATE[i] = primitives.ERATE_INCUMBENT1;
					} else if (market.TYPE[i] == 2) {// second incumbent
						market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT2;
						market.ERATE[i] = primitives.ERATE_INCUMBENT2;
					} else if (market.TYPE[i] == 0) {// entrant
						market.MARGINAL_COST[i] = primitives.MARGINAL_COST_ENTRANT;
						market.ERATE[i] = primitives.ERATE_ENTRANT;
					}
				}
				if (market.NUM_FIRMS >= 5) {
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						market.TYPE[i] = 1;
						market.ERATE[i] = primitives.ERATE_INCUMBENT1;
						market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT1;
					}
				}
				executionData.setMarket(market);
				
				double capacity = 0.0;
				Jama.Matrix state = new Jama.Matrix(market.NUM_FIRMS, 2);
				for (int i = 0; i < market.NUM_FIRMS; i++) {
					state.set(i, 0, market.CAPACITY[i]);
					state.set(i, 1, market.TYPE[i]);
					capacity += market.CAPACITY[i];
				}
				if (market.NUM_FIRMS >= 5) {
					double totalCap = 0.0;
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						totalCap += executionData.getMarket().CAPACITY[i];
					}
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						executionData.getMarket().CAPACITY_GRANDFATHER[i] = totalCap / (1.0 * market.NUM_FIRMS);
					}
				}
				
				/**
				 * BASELINE
				 */
				executionData.setSimulationDescription("Baseline");
				quantitySolver Baseline = new quantitySolver(state, false, executionData);
				double profit = market.NUM_FIRMS * pmUtility.mean(Baseline.getProfits(), 0);
				double imports = getImports(Baseline.getMarketQ(), Baseline.getPrice(),  executionData);
				double cs = Baseline.getConsumerSurplus(Baseline.getMarketQ()+imports);
				double carbonrevenue = Baseline.getCarbonRevenue();
				double welfare = profit + cs + carbonrevenue;
				double leakage = executionData.getImportEmissionsRate()
						* imports;
				out.write(market.name + ",Baseline," + welfare + "," + cs + ","
						+ profit + "," + carbonrevenue + ","
						+ Baseline.getEmissions() + "," + leakage + ","
						+ Baseline.getPrice() + "," + Baseline.getMarketQ()
						+ "," + capacity + "," + market.NUM_FIRMS + ","
						+ executionData.getCarbonTax() + "\n");

				for (Double carbonTax : listPrice) {
					executionData.setCarbonTax(carbonTax);

					/**
					 * AUCTIONING
					 */
					executionData.setScheme(primitives.SCHEME_AUCTION);
					executionData.setSimulationDescription("Auctioning");
					executionData.setMarketwideFreePermits(0);
					
					quantitySolver Auction = new quantitySolver(state, false, executionData);
					profit = market.NUM_FIRMS * pmUtility.mean(Auction.getProfits(), 0);
					imports = getImports(Auction.getMarketQ(), Auction.getPrice(),  executionData);
					cs = Auction.getConsumerSurplus(Auction.getMarketQ() + imports);
					carbonrevenue = Auction.getCarbonRevenue();
					welfare = profit + cs + carbonrevenue;
					leakage = executionData.getImportEmissionsRate() * imports;
					out.write(market.name + ",Auctioning," + welfare + "," + cs
							+ "," + profit + "," + carbonrevenue + ","
							+ Auction.getEmissions() + "," + leakage + ","
							+ Auction.getPrice() + "," + Auction.getMarketQ()
							+ "," + capacity + "," + market.NUM_FIRMS + ","
							+ executionData.getCarbonTax() + "\n");

					/**
					 * GRANDFATHERING
					 */
					double freePermitsShare = 0.425;
					double marketwideFreePermits = 0.0;
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						marketwideFreePermits += freePermitsShare * market.CAPACITY[i];
					}
					executionData.setScheme(primitives.SCHEME_GRANDFATHERING);
					executionData.setSimulationDescription("Grandfather");
					executionData.setGrandfatheringRate(freePermitsShare);
					executionData.setMarketwideFreePermits(marketwideFreePermits);
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						state.set(i, 1, i+1);
					}
					
					quantitySolver Grandfather = new quantitySolver(state, false, executionData);
					profit = market.NUM_FIRMS * pmUtility.mean(Grandfather.getProfits(), 0);
					imports = getImports(Grandfather.getMarketQ(), Grandfather.getPrice(),  executionData);
					cs = Grandfather.getConsumerSurplus(Grandfather.getMarketQ() + imports);
					carbonrevenue = Grandfather.getCarbonRevenue();
					welfare = profit + cs + carbonrevenue;
					leakage = executionData.getImportEmissionsRate()
							* imports;
					out.write(market.name + ",Grandfather," + welfare + ","
							+ cs + "," + profit + "," + carbonrevenue + ","
							+ Grandfather.getEmissions() + "," + leakage + ","
							+ Grandfather.getPrice() + ","
							+ Grandfather.getMarketQ() + "," + capacity + ","
							+ market.NUM_FIRMS + ","
							+ executionData.getCarbonTax() + "\n");
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						state.set(i, 1, executionData.getMarket().TYPE[i]);
					}

					/**
					 * OUTPUT UPDATING
					 */
					executionData.setSimulationDescription("Output");
					executionData.setScheme(primitives.SCHEME_OUTPUT_BASED);
					executionData.setGrandfatheringRate(0);
					executionData.setMarketwideFreePermits(0);
					quantitySolver Output = new quantitySolver(state, false, executionData);
					profit = market.NUM_FIRMS
							* pmUtility.mean(Output.getProfits(), 0);
					imports = getImports(Output.getMarketQ(), Output.getPrice(),  executionData);
					cs = Output.getConsumerSurplus(Output.getMarketQ() + imports);
					carbonrevenue = Output.getCarbonRevenue();
					welfare = profit + cs + carbonrevenue;
					leakage = executionData.getImportEmissionsRate()
							* imports;
					out.write(market.name + ",Output," + welfare + "," + cs
							+ "," + profit + "," + carbonrevenue + ","
							+ Output.getEmissions() + "," + leakage + ","
							+ Output.getPrice() + "," + Output.getMarketQ()
							+ "," + capacity + "," + market.NUM_FIRMS + ","
							+ executionData.getCarbonTax() + "\n");

					/**
					 * BTA
					 */
					executionData.setSimulationDescription("BTA");
					executionData.setScheme(primitives.SCHEME_BTA);
					executionData.setMarketwideFreePermits(0);
					quantitySolver BTA = new quantitySolver(state, false, executionData);
					profit = market.NUM_FIRMS
							* pmUtility.mean(BTA.getProfits(), 0);
					imports = getImports(BTA.getMarketQ(), BTA.getPrice(),  executionData);
					cs = BTA.getConsumerSurplus(BTA.getMarketQ() + imports);
					carbonrevenue = BTA.getCarbonRevenue();
					welfare = profit + cs + carbonrevenue;
					leakage = executionData.getImportEmissionsRate()
							* imports;
					out.write(market.name + ",BTA," + welfare + "," + cs + ","
							+ profit + "," + carbonrevenue + ","
							+ BTA.getEmissions() + "," + leakage + ","
							+ BTA.getPrice() + "," + BTA.getMarketQ() + ","
							+ capacity + "," + market.NUM_FIRMS + ","
							+ executionData.getCarbonTax() + "\n");

				}
			}
		} catch (IOException ex) {
		} finally {
			try {
				out.close();
			} catch (IOException ex) {
			}
		}
	}
	
	private static double[] readMgParam(int r) {

		String csvFile = "data/estimation/mgcost"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] mgcost = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				mgcost = new double[read.length + 1];
				for (int i = 0; i < read.length; i++) {
					mgcost[i + 1] = Double.valueOf(read[i]);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mgcost;

	}

    private static double getTotalQ(double thisPrice, ExecutionInformation executionData) {
        if (thisPrice == 0) {
            return 0;
        } else {
            return Math.exp(executionData.getAggregateIntercept() - executionData.getAggregateElasticity() * Math.log(thisPrice));
        }
    }

    private static double getImports(double thisMarketQ, double thisPrice, ExecutionInformation executionData) {
       double imports = 0.0;
       imports = Math.max(getTotalQ(thisPrice, executionData) - thisMarketQ, 0);
       return imports;
    }
}
