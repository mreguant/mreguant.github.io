/**
 * stateSpacePoint.java
 *
 * A stateSpacePoint is an object that contains the information
 * of a given point in the state space (capacities, policy functions,
 * value function, etc.).
 * This object has very useful functions to compute the equilibrium.
 * In particular, it has the method "solveValue", which crucially
 * computes the best-response of the firm at a given guess.
 * The method "modifiedCoefficients" is also crucial, as it integrates
 * out the uncertainty about other firms' actions so that the
 * expected value function of the firm at a given capacity choice can
 * be described as a single dimensional cubic spline.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;

import JSci.maths.statistics.NormalDistribution;
import Jama.Matrix;
import simulation.utility.*;
import utility.pmUtility;

import java.util.ArrayList;


public class stateSpacePoint implements Comparable<stateSpacePoint> {

	private Jama.Matrix state;
	private Jama.Matrix expandedState;
	private stateSpace space;
	private double stateValue;
	private double stateInvestment;
	private Jama.Matrix profits;
	private int numFirms;
	private double exitProb = 0.0;
	private double entryProb = 0.0;
	private double price;
	private double priceEmissions;
	private double emissions;
	private Boolean shortcut = null;
	private Integer shortcutIndex = null;
	private double consumerWelfare = 0.0;
	private double carbonRevenue = 0.0;
	private double marketQ = 0.0;
	private double investProb = 0.0;
	private static NormalDistribution standardNormal = new NormalDistribution(0, 1);
	private double rV = 0.0;
	private double rProbabilityExit = 0.0;
	private double rProbabilityEntry = 0.0;
	private double rProbabilityInvestment = 0.0;
	private double rInvestment = 0.0;
	private double changeV = 0.0;
	private double entryValue = 0.0;
	private double adjustmentCutoff = 0.0;
	private double expectedMaxOptions;
	static boolean DEBUG = false;
	static double DEBUG_STATE_1 = 0.0;
	static double DEBUG_STATE_2 = 3000.0;
	private Jama.Matrix modifiedCoefficient;
	private double valueDoingNothing;
	private double valueOptimalInvestment;
	private ExecutionInformation executionData;

	/**
	 * Creates a new instance of stateSpacePoint
	 */
	public stateSpacePoint(Jama.Matrix seed, ExecutionInformation executionData) {
		this.executionData = executionData;
		state = seed.copy();
		expandedState = seed.getMatrix(0, numFirms - 1, 1, 1);
	}

	public void updateState(double dampener) {
		updateValueOnly(dampener);
		updatePolicyOnly(dampener);
	}

	public void updateValueOnly(double dampener) {
		changeV = stateValue - rV;
		rV = stateValue;
	}

	public void updateInvestmentOnly(double dampener) {
		rInvestment = (1.0 - dampener) * stateInvestment + dampener * rInvestment;
		if (state.get(0, 0) == 0) {
			rInvestment = Math.max(rInvestment, executionData.getMinCapacity());
		}
	}

	public void updatePolicyOnly(double dampener) {
		if (state.get(0, 0) == 0) {
			rProbabilityExit = 0.0;
			rProbabilityEntry = (1.0 - dampener) * entryProb + dampener * rProbabilityEntry;
		} else {
			rProbabilityExit = (1.0 - dampener) * exitProb + dampener * rProbabilityExit;
			rProbabilityEntry = 0.0;
		}
		rProbabilityInvestment = (1.0 - dampener) * investProb + dampener
				* rProbabilityInvestment;
	}

	public stateSpacePoint(Jama.Matrix seed, stateSpace spaceRef,
			ExecutionInformation executionData) {
		this.executionData = executionData;
		space = spaceRef;
		numFirms = seed.getRowDimension();
		state = seed.copy();
		expandedState = seed.getMatrix(0, numFirms - 1, 1, 1);
		if (state.get(0, 0) > 0) {
			entryProb = 1.0;
		} else {
			entryProb = 0.0;
		}
		// initialize quantities and profits here
		quantitySolver solver = new quantitySolver(state, false, executionData);
		profits = solver.getProfits();
		price = solver.getPrice();
		priceEmissions = solver.getPriceEmissions();
		emissions = solver.getEmissions();
		stateValue = 0.0;// profits.get(0, 0) * 100;
		rV = stateValue;
		stateInvestment = 0.0;
		marketQ = solver.getMarketQ();
		consumerWelfare = solver.getConsumerSurplus(marketQ);
		carbonRevenue = solver.getCarbonRevenue();		
		updateState(0);
	}

	public double getPrice() {
		return price;
	}

	public double getPriceEmissions() {
		return priceEmissions;
	}

	public double getEmissions() {
		return emissions;
	}

	public double getProfit() {
		return profits.get(0, 0);
	}

	public double getValue() {
		return rV;
	}

	public double getExitProbability() {
		return rProbabilityExit;
	}

	public double getEntryProbability() {
		return rProbabilityEntry;
	}

	public double getInvestProb() {
		return rProbabilityInvestment;
	}

	public double getPolicy() {
		return rInvestment;
	}

	@Override
	public String toString() {
		return pmUtility.stringPrettyPrintVector(state) + "," + rV + ","
				+ rInvestment + "," + rProbabilityInvestment + ","
				+ rProbabilityEntry + "," + rProbabilityExit;
	}

	public Jama.Matrix getMatrix() {
		return state;
	}

	@Override
	public int compareTo(stateSpacePoint s) {
		for (int i = 0; i < s.getMatrix().getRowDimension(); i++) {
			if (s.getMatrix().get(i, 1) < state.get(i, 1)) { // modified: used
																// to be >
				return 1;
			}
			if (s.getMatrix().get(i, 1) > state.get(i, 1)) { // modified: used
																// to be <
				return -1;
			}
		}
		for (int i = 0; i < s.getMatrix().getRowDimension(); i++) {
			if (s.getMatrix().get(i, 0) < state.get(i, 0)) { // modified: used
																// to be >
				return 1;
			}
			if (s.getMatrix().get(i, 0) > state.get(i, 0)) { // modified: used
																// to be <
				return -1;
			}
		}
		return 0;
	}

	public Boolean getShortcut() {
		return shortcut;
	}

	public Integer getShortcutIndex() {
		return shortcutIndex;
	}

	public void setShortcut(boolean shortcut) {
		this.shortcut = shortcut;
	}

	public void setShortcutIndex(int shortcutIndex) {
		this.shortcutIndex = shortcutIndex;
	}

	public double getConsumerWelfare() {
		return consumerWelfare;
	}

	public double getCarbonRevenue() {
		return carbonRevenue;
	}

	public void setConsumerWelfare(double consumerWelfare) {
		this.consumerWelfare = consumerWelfare;
	}

	public double getMarketQ() {
		return marketQ;
	}

	public void setMarketQ(double marketQ) {
		this.marketQ = marketQ;
	}

	public double getAdjustmentCutoff() {
		return adjustmentCutoff;
	}

	public double getEntryValue() {
		return entryValue;
	}

	public double getExitCutoff() {
		// cutoff is the state value
		return stateValue;
	}

	void setEntryProbability(double entryProbability) {
		rProbabilityEntry = entryProbability;
	}

	void setExitProbability(double exitProbability) {
		rProbabilityExit = exitProbability;
	}

	void setInvestmentProbability(double investmentProbability) {
		rProbabilityInvestment = investmentProbability;
	}

	void setPolicy(double policy) {
		rInvestment = policy;
	}

	void setValue(double value) {
		stateValue = value;
	}

	public double getChangeV() {
		return changeV;
	}

	/**
	 * Solve for the value function, given the new timing assumptions.
	 * 
	 * @param solvePolicy
	 *            Boolean for whether or not the optimal investments will be
	 *            solved for.
	 * @param c
	 */
	void solveValue(boolean solvePolicy, coefficientValues c) {
		// solve value using interpolation

		// set strategies of firms //
		Jama.Matrix policyVector = new Jama.Matrix(numFirms, 2);
		Jama.Matrix entryVector = new Jama.Matrix(numFirms, 1);
		Jama.Matrix exitVector = new Jama.Matrix(numFirms, 1);
		policyVector.set(0, 1, 1);
		entryVector.set(0, 0, 1); // have to assume that the entry is going to
									// happen to find the optimal investment
		exitVector.set(0, 0, 0); // converse situation with exiting
		for (int i = 1; i < numFirms; i++) {
			stateSpacePoint point = space.getPoint(state, i);
			if (DEBUG) {
				if (state.get(0, 0) == DEBUG_STATE_1
						&& state.get(1, 0) == DEBUG_STATE_2) {
					System.out.println("* filling policy vectors " + point
							+ " x: " + point.getPolicy() + " pr: "
							+ point.getInvestProb());
				}
			}
			policyVector.set(i, 0, point.getPolicy());
			policyVector.set(i, 1, point.getInvestProb());
			entryVector.set(i, 0, point.getEntryProbability());
			exitVector.set(i, 0, point.getExitProbability());
		} // what others do

		
		// summarize the expected value function conditional on others actions
		Jama.Matrix modifiedCoeff = new Jama.Matrix(
				executionData.getNumberDiscreteCapacityPoints() + 2, 1);
		if (numFirms == 1) {
			int offset = space.getExpandedIndex(expandedState);
			modifiedCoeff = c.getCoefficients(offset).getMatrix(0,
					executionData.getNumberDiscreteCapacityPoints() + 1, 0, 0);
		} else {
			modifiedCoeff = modifiedCoefficient(this.getMatrix(), policyVector,
					entryVector, exitVector, c);
		}

		// compute optimal investment given modified coefficients //
		double optimalInvestmentIgnoringFixedCosts = stateInvestment;
		if (solvePolicy) {
			optimalInvestmentIgnoringFixedCosts = solveOptimalInvestment(modifiedCoeff);
		}
		stateInvestment = optimalInvestmentIgnoringFixedCosts;

		// compute expected value at optimal investment and no investment //
		double valueAdjustment = computeBellman(optimalInvestmentIgnoringFixedCosts, modifiedCoeff);
		double valueNoInvestment = 0.0;
		if (state.get(0, 0) == 0) {
			valueNoInvestment = 0.0;
		} else {
			valueNoInvestment = computeBellman(0.0, modifiedCoeff);
		}
		valueDoingNothing = valueNoInvestment;
		valueOptimalInvestment = valueAdjustment;
		if (Double.isNaN(valueAdjustment)) {
			System.out.println("NaN in positive value adjustment");
			System.exit(0);
		}

		/**
		 * New timing means that I need to calculate W = Emax(V+ - gamma_1, V0)
		 * 
		 * Then compute Emax ( phi, W)
		 * 
		 * W is just a number, so just iterated application of conditional means
		 */

		// compute entry and exit probabilities and set stateValue
		if (state.get(0, 0) == 0) {
			/**
			 * Calculation for Entrants
			 */
			exitProb = 0.0;
			investProb = 1.0;

			if (optimalInvestmentIgnoringFixedCosts > 0.0) { // && investProb >
																// 1e-15
				/**
				 * Adjust for fact that entrant has draws on both investment
				 * costs and entry costs.
				 */
				double sumVariance = Math.pow(primitives.ENTRY_SIGMA, 2) + Math.pow(primitives.ADJUSTMENT_SIGMA, 2);
				double entryAlpha = (valueOptimalInvestment - (primitives.ADJUSTMENT_MU + primitives.ENTRY_MU)) / Math.sqrt(sumVariance);
				entryProb = standardNormal.cumulative(entryAlpha);
				if (entryProb < 1E-6) {
					entryProb = 0.0;
				}
			} else {
				entryProb = 0.0;
			}
			if (primitives.ADJUSTMENT_NATURE) {
				if (primitives.ADJUSTMENT_NATURE_CAP) {
					entryProb = Math.min(primitives.ADJUSTMENT_PROBABILITY_CAP,
							entryProb);
				} else {
					entryProb = 1.0 * entryProb / primitives.ADJUSTMENT_FACTOR;
				}
			}
					
			/**
			 * Update state value for potential entrants.
			 */
			entryValue = valueOptimalInvestment;
			stateValue = valueOptimalInvestment;

		} else {
			/**
			 * Calculation for Incumbents
			 */
			double V_diff = valueAdjustment - valueNoInvestment;
			double V_diff_normalized = (V_diff - primitives.ADJUSTMENT_MU)
					/ primitives.ADJUSTMENT_SIGMA;
			double probabilityGammaUnderCutoff = standardNormal
					.cumulative(V_diff_normalized);
			double expectedGammaUnderCutoff = primitives.ADJUSTMENT_MU;
			expectedGammaUnderCutoff -= primitives.ADJUSTMENT_SIGMA
					* (standardNormal.probability(V_diff_normalized) / standardNormal
							.cumulative(V_diff_normalized));
			if (probabilityGammaUnderCutoff < 1E-6) {
				probabilityGammaUnderCutoff = 0.0;
				expectedGammaUnderCutoff = 0.0;
			}
			if (primitives.ADJUSTMENT_NATURE) {
				if (primitives.ADJUSTMENT_NATURE_CAP) {
					probabilityGammaUnderCutoff = Math.min(
							probabilityGammaUnderCutoff,
							primitives.ADJUSTMENT_PROBABILITY_CAP);
				} else {
					probabilityGammaUnderCutoff = 1.0
							* probabilityGammaUnderCutoff
							/ primitives.ADJUSTMENT_FACTOR;
				}
			}
			if (stateInvestment == 0) {
				probabilityGammaUnderCutoff = 0.0;
			}
			double emax = (1.0 - probabilityGammaUnderCutoff)
					* valueNoInvestment + probabilityGammaUnderCutoff
					* (valueAdjustment - expectedGammaUnderCutoff);

			expectedMaxOptions = emax;

			// Decision of scrapping or not conditional on expected investment
			// pattern 'emax'
			double W_diff_normalized = (emax - primitives.SCRAP_MU)
					/ primitives.SCRAP_SIGMA;
			double probabilityPhiAboveCutoff = standardNormal
					.cumulative(-W_diff_normalized);
			double egamma = primitives.SCRAP_MU;
			egamma += primitives.SCRAP_SIGMA
					* (standardNormal.probability(W_diff_normalized) / standardNormal
							.cumulative(-W_diff_normalized));
			if (probabilityPhiAboveCutoff < 1E-6) {
				probabilityPhiAboveCutoff = 0.0;
				egamma = 0.0;
			}
			double emaxv = probabilityPhiAboveCutoff * egamma
					+ (1.0 - probabilityPhiAboveCutoff) * emax;

			entryProb = 1.0;
			investProb = probabilityGammaUnderCutoff;
			exitProb = probabilityPhiAboveCutoff;
			stateValue = emaxv;

		}
		modifiedCoefficient = modifiedCoeff;
	}

	/**
	 * 
	 * METHODS FOR VALUE FUNCTION AND POLICY COMPUTATION NOTE
	 * 
	 */
	public double computeBellman(double investment, Matrix c) {

		// evaluate expected value at final capacity using spline //
		double value = Interpolate.getValue(
				Math.max(state.get(0, 0) * (1.0 - primitives.DEPRECIATION),
				executionData.getMinCapacity()) + investment, c, 1,
				executionData.getNumberDiscreteCapacityPoints(),
				executionData.getMinCapacity(),
				executionData.getCapacityIncrement());
		value *= primitives.DISCOUNT_FACTOR;

		// add current profit and substract investment costs //
		value += getProfit();
		if (investment > 0) {
			value -= investment * primitives.INVESTMENT_MARGINAL_COST;
			value -= investment * investment * primitives.INVESTMENT_MARGINAL_COST2;
		}
		if (investment < 0) {
			value -= investment * primitives.DIVESTMENT_MARGINAL_COST;
			value -= investment * investment * primitives.DIVESTMENT_MARGINAL_COST2;
		}

		return value;

	}

	private double solveOptimalInvestment(Matrix c) {

		double optimalInvestment = 0.0;

		/*
		 * NOTE: gets new spline coefficients taking into account costs of
		 * investment alternative way: add marginal cost of investment to
		 * getOptimum method
		 */

		// compute value at investment candidates //
		int numPoints = executionData.getNumberDiscreteCapacityPoints();
		Interpolate interp = new Interpolate(numPoints);
		Jama.Matrix valueInvestment = new Jama.Matrix(numPoints, 1);
		double inc = (executionData.getMaxCapacity() - executionData.getMinCapacity()) / (numPoints - 1);
		double lowerb = 0.0;
		if (state.get(0, 0) > 0) {
			lowerb = executionData.getMinCapacity() - state.get(0, 0);
			if (!primitives.USE_DIVESTMENT) {
				lowerb = 0.0;
				inc = (executionData.getMaxCapacity() - state.get(0, 0) - lowerb) / (numPoints - 1);
			}
		} else { // if new entrant
			lowerb = executionData.getMinCapacity();
		}
		for (int i = 0; i < numPoints; i++) { // create candidate investments
												// and evaluate value
			double invest = lowerb + inc * i;
			double value = computeBellman(invest, c);
			valueInvestment.set(i, 0, value);
		}

		// fit spline and get optimum //
		Jama.Matrix cInvest = interp.getCoeff(valueInvestment, 0, 0, 1, numPoints, inc);
		optimalInvestment = interp.getOptimum(cInvest, 1, numPoints, lowerb, inc);

		// minmax it to be within established range //
		optimalInvestment = Math.min(Math.max(lowerb, optimalInvestment), executionData.getMaxCapacity());
		if (state.get(0, 0) <= executionData.getMinCapacity() + primitives.MIN_ADJUSTMENT
				&& Math.abs(optimalInvestment) < primitives.MIN_ADJUSTMENT) {
			optimalInvestment = primitives.MIN_ADJUSTMENT;
		}
		if (state.get(0, 0) > executionData.getMinCapacity() + primitives.MIN_ADJUSTMENT
				&& Math.abs(optimalInvestment) < primitives.MIN_ADJUSTMENT) {
			double valueUp = computeBellman(primitives.MIN_ADJUSTMENT, c);
			double valueDown = computeBellman(-primitives.MIN_ADJUSTMENT, c);
			if (valueUp > valueDown) {
				optimalInvestment = primitives.MIN_ADJUSTMENT;
			} else {
				optimalInvestment = -primitives.MIN_ADJUSTMENT;
			}
		}
		return optimalInvestment;
	}

	public Jama.Matrix modifiedCoefficient(Jama.Matrix start,
			Jama.Matrix policy, Jama.Matrix entry, Jama.Matrix exit,
			coefficientValues c) {
		/**
		 * this function computes the coefficients that represent the
		 * single-dimensional spline of tomorrows EV conditional on what others
		 * do it is similar to the transition matrix computation
		 */
		int N = executionData.getNumberDiscreteCapacityPoints();
		int D = executionData.getMarket().NUM_FIRMS;
		Jama.Matrix modifiedCoeff = new Jama.Matrix(N + 2, 1);
		double[][] tempC = new double[N + 2][1];
		boolean ORIGINAL = true;

		// loop over different actions that others can do (i.e.
		// enter/exit/stay/invest)
		double sumPrS = 0.0;
		ArrayList<Matrix> actionList = space.getActionSpace();
		Jama.Matrix probability = new Jama.Matrix(D, 3, 0.0);
		for (int n = 1; n < D; n++) {
			// exit or not enter
			if (start.get(n, 0) == 0) {
				probability.set(n, 0, (1 - entry.get(n, 0)));
			} else {
				probability.set(n, 0, exit.get(n, 0));
			}
			// stay
			if (start.get(n, 0) == 0) {
				probability.set(n, 1, 0.0);
			} else {
				probability.set(n, 1,
						(1 - exit.get(n, 0)) * (1 - policy.get(n, 1)));
			}
			// stay and invest or enter (assumes if enter then invest)
			if (start.get(n, 0) == 0) {
				probability.set(n, 2, entry.get(n, 0));
			} else {
				probability.set(n, 2, (1 - exit.get(n, 0)) * policy.get(n, 1));
			}
		}

		for (int i = 0; i < actionList.size(); i++) { // actions loop
			// 1. Compute probability of action happening and active firms
			double prS = 1.0;
			Jama.Matrix currentAction = actionList.get(i);
			for (int n = 1; n < D; n++) {
				prS = prS * probability.get(n, (int) currentAction.get(n - 1, 0));
			}
			// 2. Include in expectation if positive probability of action
			if (prS > 1E-5) {
				sumPrS += prS;
				int dActive = 0; // number of OTHER FIRMS active
				Jama.Matrix result = new Jama.Matrix(D, 2);
				result.set(0, 0, executionData.getMinCapacity());
				result.set(0, 1, start.get(0, 1));
				for (int n = 1; n < D; n++) {
					if (currentAction.get(n - 1, 0) == 0) { // exit or not enter
						result.set(n, 0, 0);
						result.set(n, 1, 0); // set as potential entrant for tomorrow
					} else if (currentAction.get(n - 1, 0) == 1) { // stay
						result.set(n, 0, Math.max(start.get(n, 0) * (1.0 - primitives.DEPRECIATION),
								executionData.getMinCapacity()));
						result.set(n, 1, start.get(n, 1)); // stay with same id
						dActive += 1;
					} else { // stay and invest or enter (assumes if enter then invest)
						result.set(n, 0, Math.max(start.get(n, 0) * (1.0 - primitives.DEPRECIATION) + policy.get(n, 0),
										executionData.getMinCapacity()));
						result.set(n, 1, start.get(n, 1)); // stay with same id
						dActive += 1;
					}
				}
				result = space.sortOnFirmId(result);
				if (prS > 1 - 1E-5 && modifiedCoefficient != null && result.minus(start).norm2() == 0) {
					return modifiedCoefficient;
				} else {
					if (ORIGINAL) {
						// setup offset and pick relevant coefficients
						Jama.Matrix coef = c.getCoefficients(space.getExpandedIndex(result.getMatrix(0, D - 1, 1, 1)));
						for (int j = 0; j < N + 2; j++) { // for each
															// coefficient
							double newC = 0.0;
							// determine relevant coefficient range to reduce computation time along each dimension
							// (other firms active)
							double[][] basis = new double[dActive][4];
							int[][] index = new int[dActive][4];
							int count = 0;
							for (int d = 1; d < D; d++) {
								if (result.get(d, 0) > 0) {
									int ind = (int) java.lang.Math.floor((result.get(d, 0) - executionData.getMinCapacity())
													/ executionData.getCapacityIncrement());
									for (int k = java.lang.Math.max(ind, 0); k < java.lang.Math.min(ind + 4, N + 2); k++) {
										basis[count][k - ind] = Interpolate.cubicFunction(result.get(d, 0),
														k, N, executionData.getMinCapacity(), executionData.getCapacityIncrement());
										index[count][k - ind] = k;
									}
									count += 1;
								}
							}
							// compute coefficient
							for (int k = 0; k < java.lang.Math.pow(4, dActive); k++) {
								double update = 1.0;
								int ind = 0;
								count = 0;
								for (int d = 1; d < D; d++) {
									if (result.get(d, 0) > 0) {
										int t = (int) (java.lang.Math.floor(k / java.lang.Math.pow(4, count)) - java.lang.Math
												.floor(k / java.lang.Math.pow(4, count + 1)) * 4);
										update = update * basis[count][t];
										ind += index[count][t] * java.lang.Math.pow(N + 2, dActive - count - 1);
										count += 1;
									}
								}
								ind = (int) (ind + j * java.lang.Math.pow(N + 2, dActive));
								newC += update * coef.get(ind, dActive); // pick relevant coefficient based on other active firms
							}
							// weight by probability of actions combination
							tempC[j][0] += prS * newC;
						} // each coefficient
					} else {
						// setup offset and pick relevant coefficients
						Jama.Matrix coef = c.getCoefficients(space.getExpandedIndex(result.getMatrix(0, D - 1, 1, 1)));
						Jama.Matrix wsActive = new Jama.Matrix(dActive + 1, 1);
						int count = 0;
						for (int k = 0; k < D; k++) {
							if (result.get(k, 0) > 0) {
								wsActive.set(count, 0, result.get(k, 0));
								count += 1;
							}
						}
						for (int j = 0; j < N; j++) {
							wsActive.set(0, 0, executionData.getMinCapacity()
									+ j * executionData.getCapacityIncrement());
							tempC[j][0] += prS	* Interpolate.getValue(wsActive, 
									coef.getMatrix(0, (int) java.lang.Math.pow(N + 2,dActive + 1) - 1, dActive, dActive),
													dActive + 1, N,	executionData.getMinCapacity(),	executionData.getCapacityIncrement());
						}
					}
				}
			} // if positive probability
		} // each action
		if (ORIGINAL) {
			modifiedCoeff.setMatrix(0, N + 1, 0, 0,
					new Jama.Matrix(tempC).times(1.0 / sumPrS));
		} else {
			Interpolate interp = new Interpolate(
					executionData.getNumberDiscreteCapacityPoints());
			Jama.Matrix tempValue = new Jama.Matrix(tempC).times(1.0 / sumPrS);
			modifiedCoeff = interp.getCoeff(tempValue, 0, 0, 1,
					executionData.getNumberDiscreteCapacityPoints(),
					executionData.getCapacityIncrement());
		}
		return modifiedCoeff;

	}

	/**
	 * @return the valueDoingNothing
	 */
	public double getValueDoingNothing() {
		return valueDoingNothing;
	}

	/**
	 * @param valueDoingNothing
	 *            the valueDoingNothing to set
	 */
	public void setValueDoingNothing(double valueDoingNothing) {
		this.valueDoingNothing = valueDoingNothing;
	}

	/**
	 * @return the valueOptimalInvestment
	 */
	public double getValueOptimalInvestment() {
		return valueOptimalInvestment;
	}

	/**
	 * @param valueOptimalInvestment
	 *            the valueOptimalInvestment to set
	 */
	public void setValueOptimalInvestment(double valueOptimalInvestment) {
		this.valueOptimalInvestment = valueOptimalInvestment;
	}

	/**
	 * @return the expectedMaxOptions
	 */
	public double getExpectedMaxOptions() {
		return expectedMaxOptions;
	}

	/**
	 * @param expectedMaxOptions
	 *            the expectedMaxOptions to set
	 */
	public void setExpectedMaxOptions(double expectedMaxOptions) {
		this.expectedMaxOptions = expectedMaxOptions;
	}
}
