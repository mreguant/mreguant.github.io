/**
 * regionalList.java
 * 
 * Function to read in the information from the regional
 * lit files. It creates a regional list (an array of
 * regional market objects) --see regionalMarket.java.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package simulation.solve;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import simulation.utility.primitives;


@SuppressWarnings("serial")
public class regionalList extends ArrayList<regionalMarket> {

	public regionalList() {

	}

	public regionalList(String file) {
		try {
			// read in file
			BufferedReader bufRdr = new BufferedReader(new FileReader(file));
			String line = bufRdr.readLine();
			line = bufRdr.readLine(); // remove headers
			while (line != null) {
				if (line != null) {
					regionalMarket market = new regionalMarket();
					int a = 0;
					int b = line.indexOf(",", a);
					market.name = line.substring(a, b);
					a = b + 1;
					b = line.indexOf(",", a);
					market.AVERAGE_PRICE = Double.parseDouble(line.substring(a,b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.AVERAGE_QUANTITY = Double.parseDouble(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.AGGREGATE_ELASTICITY = Double.parseDouble(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.AGGREGATE_INTERCEPT = Double.parseDouble(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.IMPORT_ELASTICITY = Double.parseDouble(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.IMPORT_INTERCEPT = Double.parseDouble(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					market.NUM_FIRMS = Integer.parseInt(line.substring(a, b));
					market.TYPE = new int[market.NUM_FIRMS];
					market.CAPACITY = new double[market.NUM_FIRMS];
					market.CAPACITY_GRANDFATHER = new double[market.NUM_FIRMS];
					market.ERATE = new double[market.NUM_FIRMS];
					market.MARGINAL_COST = new double[market.NUM_FIRMS];
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						a = b + 1;
						b = line.indexOf(",", a);
						market.TYPE[i] = Integer.parseInt(line.substring(a, b));
					}
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						a = b + 1;
						b = line.indexOf(",", a);
						market.CAPACITY[i] = Double.parseDouble(line.substring(a, b));
						market.CAPACITY_GRANDFATHER[i] = market.CAPACITY[i];
					}
					for (int i = 0; i < market.NUM_FIRMS; i++) {
						if (market.TYPE[i] == 1) {// first incumbent
							market.ERATE[i] = primitives.ERATE_INCUMBENT1;
							market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT1;
						} else if (market.TYPE[i] == 2) { // second incumbent
							market.ERATE[i] = primitives.ERATE_INCUMBENT2;
							market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT2;
						} else { // entrant
							market.ERATE[i] = primitives.ERATE_ENTRANT;
							market.MARGINAL_COST[i] = primitives.MARGINAL_COST_ENTRANT;
						}
					}
					this.add(market);
					// next line
					line = bufRdr.readLine();
				}
			}
			// close the file
			bufRdr.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
