/**
 * quantitySolver.java
 *
 * This function calculates the static equilibrium for the capacity-
 * constrained Cournot game at given capacities and policy.
 * Once solved, it has methods to return equilibrium prices, quantities,
 * emissions, welfare, etc.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;

import simulation.utility.*;

import java.util.*;


public class quantitySolver implements optimization.Uncmin_methods,
		simulation.solve.mcmcFunction {

	private Jama.Matrix state;
	private Jama.Matrix qVec;
	private int numParams;
	private int numFirms;
	private double marketQ;
	private double totalEmissions;
	private double carbonRevenue;
	private Jama.Matrix profits;
	private Jama.Matrix mgCostOperation;
	private Jama.Matrix emissionsRate;
	private Jama.Matrix grandfatheredRate;
	private Jama.Matrix grandfatheredQ;
	private double freePermits;
	private double price;
	private double priceEmissions;
	private boolean priceTaker = false;
	private double A;
	private double B;
	private double subsidy = 1.0;
	private double benchmarkRate = 0.716;
	private static double capacityCostThreshold = Math.exp(primitives.CAPACITY_COST_BINDING_LEVEL)
			/ (1.0 + Math.exp(primitives.CAPACITY_COST_BINDING_LEVEL));
	boolean verbose = false;

	ExecutionInformation executionData;

	/** Creates a new instance of marginalCostSolver */
	public quantitySolver(Jama.Matrix statePassed, boolean priceTaker,
			ExecutionInformation executionData) {
		this.priceTaker = priceTaker;
		this.executionData = executionData;
		A = executionData.getAggregateIntercept()
				/ executionData.getAggregateElasticity();
		B = 1.0 / executionData.getAggregateElasticity();
		int numActive = 0;
		ArrayList<Integer> activePos = new ArrayList<Integer>();
		for (int i = 0; i < statePassed.getRowDimension(); i++) {
			if (statePassed.get(i, 0) > 0) {
				numActive++;
				activePos.add(i);
			}
		}
		state = new Jama.Matrix(numActive, 2);
		for (int i = 0; i < numActive; i++) {
			int indexNext = activePos.get(i);
			state.set(i, 0, statePassed.get(indexNext, 0));
		}
		mgCostOperation = new Jama.Matrix(numActive, 1, primitives.MARGINAL_COST_ENTRANT);
		emissionsRate = new Jama.Matrix(numActive, 1, primitives.ERATE_ENTRANT);
		grandfatheredRate = new Jama.Matrix(numActive, 1, executionData.getGrandfatheringRate());
		grandfatheredQ = new Jama.Matrix(numActive, 1, 0.0);

		// SET DIFFERENT PARAMETERIZATION for incumbents
		// advantage is that one can differentiate in many dimensions
		for (int i = 0; i < numActive; i++) {
			int indexNext = activePos.get(i);
			if (statePassed.get(indexNext, 1) == 1) {// first incumbent
				mgCostOperation.set(i, 0, primitives.MARGINAL_COST_INCUMBENT1);
				emissionsRate.set(i, 0, primitives.ERATE_INCUMBENT1);
			} else if (statePassed.get(indexNext, 1) == 2) { // second incumbent
				mgCostOperation.set(i, 0, primitives.MARGINAL_COST_INCUMBENT2);
				emissionsRate.set(i, 0, primitives.ERATE_INCUMBENT2);
			} else if (statePassed.get(indexNext, 1) == 0) { // entrant
				mgCostOperation.set(i, 0, primitives.MARGINAL_COST_ENTRANT);
				emissionsRate.set(i, 0, primitives.ERATE_ENTRANT);
			}
		}

		// SET FREE PERMITS
		double initialCapacityEmissions = 0.0;
		for (int i = 0; i < executionData.getMarket().NUM_FIRMS; i++) {
			initialCapacityEmissions += executionData.getMarket().CAPACITY_GRANDFATHER[i] * executionData.getMarket().ERATE[i];
		}
		freePermits = 0.0;
		for (int i = 0; i < numActive; i++) {
			int indexNext = activePos.get(i);
			if (executionData.getScheme() == primitives.SCHEME_GRANDFATHERING) {
				if (initialCapacityEmissions != 0) {
					if (statePassed.get(indexNext, 1) != 0) {
						mgCostOperation.set(i,0, executionData.getMarket().MARGINAL_COST[(int) statePassed.get(indexNext, 1) - 1]);
						emissionsRate.set(i,0, executionData.getMarket().ERATE[(int) statePassed.get(indexNext, 1) - 1]);
						grandfatheredRate.set(i,0, executionData.getMarket().ERATE[i]	*
												Math.min(executionData.getMarket().CAPACITY_GRANDFATHER[(int) statePassed.get(indexNext,1) - 1],
														statePassed.get(indexNext, 0))/ (1.0 * initialCapacityEmissions));
						grandfatheredQ.set(i, 0, grandfatheredRate.get(i, 0) * executionData.getMarketwideFreePermits());
						freePermits += grandfatheredQ.get(i, 0);
					} else {
						grandfatheredRate.set(i, 0, 0.0);
						grandfatheredQ.set(i, 0, 0.0);
					}
				} else {
					freePermits = 0.0;
					grandfatheredRate.set(i, 0, 0.0);
					grandfatheredQ.set(i, 0, 0.0);
				}
			} else if (executionData.getScheme() == primitives.SCHEME_OUTPUT_BASED
					|| executionData.getScheme() == primitives.SCHEME_EMISSIONS_BASED) {
				freePermits = 0.0;
			} else {
				freePermits = 0.0;
				grandfatheredRate.set(i, 0, 0.0);
				grandfatheredQ.set(i, 0, 0.0);
			}
		}
		numParams = state.getRowDimension();
		numFirms = state.getRowDimension();

		optimization.Uncmin_f77 minimizer = new optimization.Uncmin_f77(false);

		double[] guess = new double[numParams + 1];
		double[] xpls = new double[numParams + 1];
		double[] fpls = new double[2];
		double[] gpls = new double[numParams + 1];
		int[] itrmcd = new int[2];
		double[][] a = new double[numParams + 1][numParams + 1];
		double[] udiag = new double[numParams + 1];
		double[] typsiz = new double[numParams + 1];
		for (int i = 0; i < numFirms; i++) {
			typsiz[i + 1] = 1;
			guess[i + 1] = 0.8 * state.get(i, 0);
		}
		double[] fscale = { 0, 1E-16 };
		int[] method = { 0, 1 };
		int[] iexp = { 0, 0 };
		int[] msg = { 0, 1 };
		int[] ndigit = { 0, 15 };
		int[] itnlim = { 0, 150 };
		int[] iagflg = { 0, 0 };
		int[] iahflg = { 0, 0 };
		double[] dlt = { 0, 1 };
		double[] gradtl = { 0, 1E-8 };
		double[] stepmx = { 0, 1E8 };
		double[] steptl = { 0, 1E-8 };

		if (numActive > 0) {

			simulation.solve.gibbsLTEGeneralized lte = new gibbsLTEGeneralized(this, 200, 100, guess);
			guess = lte.getLowestPoint();
			double objective = f_to_minimize(guess);
			double[] guess2 = new double[numParams + 1];
			for (int i = 0; i < numFirms; i++) {
				guess2[i + 1] = 0.1 * state.get(i, 0);
			}
			lte = new gibbsLTEGeneralized(this, 100, 10, guess2);
			guess2 = lte.getLowestPoint();
			if (f_to_minimize(guess2) < objective) {
				for (int i = 0; i < numFirms; i++) {
					guess[i + 1] = guess2[i + 1];
				}
			}
			minimizer.optif9_f77(numParams, guess, this, typsiz, fscale,
					method, iexp, msg, ndigit, itnlim, iagflg, iahflg, dlt,
					gradtl, stepmx, steptl, xpls, fpls, gpls, itrmcd, a, udiag);
		}
		
		price = calcPrice(marketQ);
		if (Double.isInfinite(price)) {
			price = 0.0;
		}
		if (executionData.getScheme() == primitives.SCHEME_OUTPUT_BASED) {
			for (int i = 1; i <= numFirms; i++) {
				freePermits += subsidy * benchmarkRate * guess[i];
				grandfatheredQ.set(i - 1, 0, subsidy * benchmarkRate * guess[i]);
			}
		}
		if (executionData.getScheme() == primitives.SCHEME_EMISSIONS_BASED) {
			for (int i = 1; i <= numFirms; i++) {
				freePermits += subsidy * emissionsRate.get(i - 1, 0) * guess[i];
				grandfatheredQ.set(i - 1, 0, subsidy * emissionsRate.get(i - 1, 0) * guess[i]);
			}
		}
		priceEmissions = calcPriceEmissions(totalEmissions);
		if (Double.isInfinite(priceEmissions)) {
			priceEmissions = 0.0;
		}

		profits = new Jama.Matrix(statePassed.getRowDimension(), 1, 0.0);
		qVec = new Jama.Matrix(statePassed.getRowDimension(), 1, 0.0);
		for (int i = 0; i < numActive; i++) {
			// calculate profits for each firm here
			int indexNext = activePos.get(i);
			double pi = guess[i + 1] * (price - mgCostOperation.get(i, 0) - emissionsRate.get(i,0) * priceEmissions) 
					+ grandfatheredQ.get(i, 0) * priceEmissions;
			double utilPct = guess[i + 1] / state.get(i, 0);
			if (utilPct > capacityCostThreshold) {
				pi -= primitives.CAPACITY_COST * Math.pow(utilPct - capacityCostThreshold, 2);
			}
			qVec.set(indexNext, 0, guess[i + 1]);
			profits.set(indexNext, 0, pi);
		}
		if (numActive > 0) {
			carbonRevenue = priceEmissions * (totalEmissions - freePermits);
		} else {
			carbonRevenue = 0.0;
		}
	}

	public double getConsumerSurplus(double quantity) {
		if (quantity == 0) {
			return 0.0;
		} else {
			return Math.exp(A) * Math.pow(quantity, -B + 1) / (-B + 1)
					- (quantity * calcPrice(quantity));
		}
	}

	private double calcPrice(double quantity) {
		/**
		 * Substitute in the residual demand curve calculator here.
		 */
		boolean useResidualDemand = true;
		if (executionData.getImportIntercept() == 0) {
			useResidualDemand = false;
		}

		if (useResidualDemand) {
			PriceSolver priceSolver = new PriceSolver(executionData);
			double p = priceSolver.getPrice(quantity);
			return p;
		}
		return Math.exp(A - B * Math.log(quantity));
	}

	public double calcPricePrime(double quantity) {
		boolean useResidualDemand = true;
		if (executionData.getImportIntercept() == 0) {
			useResidualDemand = false;
		}

		if (useResidualDemand) {
			PriceSolver priceSolver = new PriceSolver(executionData);
			return priceSolver.getSlope(quantity);
		}
		return calcPrice(quantity) * (-B) / quantity;
	}

	private double calcPriceEmissions(double emissions) {
		return executionData.getCarbonTax();
	}

	@Override
	public double f_to_minimize(double[] x) {
		marketQ = 0.0;
		totalEmissions = 0.0;
		// System.out.println(x.length);
		for (int i = 1; i <= numFirms; i++) {
			x[i] = Math.max(1E-16, x[i]);
			x[i] = Math.min(x[i], state.get(i - 1, 0));
			marketQ += x[i];
			totalEmissions += emissionsRate.get(i - 1, 0) * x[i];
		}

		price = calcPrice(marketQ);
		double pricePrime = calcPricePrime(marketQ);
		priceEmissions = calcPriceEmissions(totalEmissions);


		Jama.Matrix fvec = new Jama.Matrix(x.length - 1, 1);
		for (int i = 1; i <= numFirms; i++) {
			double marginalBenefit = price;
			if (!priceTaker) {
				marginalBenefit += x[i] * pricePrime;
			}
			double marginalCost = mgCostOperation.get(i - 1, 0)	+ emissionsRate.get(i - 1, 0) * priceEmissions;
			
			if (executionData.getScheme() == primitives.SCHEME_OUTPUT_BASED) {
				marginalCost += -subsidy * benchmarkRate * priceEmissions;
			}
			if (executionData.getScheme() == primitives.SCHEME_EMISSIONS_BASED) {
				marginalCost += -subsidy * emissionsRate.get(i - 1, 0)
						* priceEmissions;
			}
			
			double utilPct = x[i] / state.get(i - 1, 0);
			if (utilPct > capacityCostThreshold) {
				marginalCost += Math.min(primitives.CAPACITY_COST * 2.0 * (utilPct - capacityCostThreshold), 400.0);
			}
			if (verbose) {
				System.out.println("i: " + i + " q_i: " + x[i]
						+ " marginal cost: " + marginalCost
						+ " marginal revenue: " + marginalBenefit + " price: "
						+ price);
			}
			fvec.set(i - 1, 0, marginalBenefit - marginalCost);
			if (utilPct < 1E-3) {
				fvec.set(i - 1, 0, Math.min(10.0, (marginalBenefit - marginalCost)));
			}
		}
		double value = ((fvec.transpose()).times(fvec)).get(0, 0) / (1.0 * numFirms);
		return value;
	}

	@Override
	public void gradient(double[] x, double[] g) {
	}

	@Override
	public void hessian(double[] x, double[][] h) {
	}

	public Jama.Matrix getProfits() {
		return profits;
	}

	public void setProfits(Jama.Matrix profits) {
		this.profits = profits;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getPriceEmissions() {
		return priceEmissions;
	}

	double getEmissions() {
		return totalEmissions;
	}

	public double getCarbonRevenue() {
		return carbonRevenue;
	}

	public double getMarketQ() {
		return marketQ;
	}

	public void setMarketQ(double marketQ) {
		this.marketQ = marketQ;
	}

	public Jama.Matrix getQVec() {
		return qVec;
	}

	public void setQVec(Jama.Matrix qVec) {
		this.qVec = qVec;
	}

	@Override
	public double objectiveFunction(double[] x) {
		return -f_to_minimize(x);
	}

	@Override
	public double pi(double[] x) {
		return 1;
	}
}
