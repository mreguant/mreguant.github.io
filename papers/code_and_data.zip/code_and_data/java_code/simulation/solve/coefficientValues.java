/**
 * coefficientValues.java
 * 
 * Creates an object that stores the information of the
 * interpolation of the value function. It has methods to update
 * the values of the coefficients given new information.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;

import Jama.Matrix;
import java.util.ArrayList;
import java.util.Collections;

public class coefficientValues {

	private ArrayList<Jama.Matrix> coeff;
	private ArrayList<Jama.Matrix> values;
	private ArrayList<Jama.Matrix> index;
	private stateSpace space;
	private int numStates;
	private boolean isActive;
	private Interpolate interp; 

	public coefficientValues(stateSpace omega, boolean active) {
		space = omega;
		isActive = active;
		numStates = space.getNumStates();
		interp = new Interpolate(omega.getExecutionData()
				.getNumberDiscreteCapacityPoints());
		coeff = new ArrayList<Jama.Matrix>();
		index = new ArrayList<Jama.Matrix>();
		values = new ArrayList<Jama.Matrix>();
		if (active) {
			for (int t = 0; t < numStates; t++) {
				coeff.add(new Jama.Matrix((int) java.lang.Math.pow(
						omega.getExecutionData()
								.getNumberDiscreteCapacityPoints() + 2, omega
								.getExecutionData().getMarket().NUM_FIRMS),
						omega.getExecutionData().getMarket().NUM_FIRMS, 0));
				index.add(new Jama.Matrix(
						new double[(int) java.lang.Math.pow(omega
								.getExecutionData()
								.getNumberDiscreteCapacityPoints(), omega
								.getExecutionData().getMarket().NUM_FIRMS)][omega
								.getExecutionData().getMarket().NUM_FIRMS]));
				values.add(new Jama.Matrix(new double[(int) java.lang.Math.pow(
						omega.getExecutionData()
								.getNumberDiscreteCapacityPoints(), omega
								.getExecutionData().getMarket().NUM_FIRMS)][1]));
				int Dmin = countOtherIncumbents(space.getExpandedList().get(t)
						.getMatrix());
				for (int i = Dmin; i < omega.getExecutionData().getMarket().NUM_FIRMS; i++) {
					generateIndex(i + 1, t, active);
				}
			}
		} else {
			for (int t = 0; t < numStates; t++) {
				coeff.add(new Jama.Matrix((int) java.lang.Math.pow(
						omega.getExecutionData()
								.getNumberDiscreteCapacityPoints() + 2, omega
								.getExecutionData().getMarket().NUM_FIRMS - 1),
						omega.getExecutionData().getMarket().NUM_FIRMS - 1, 0));
				index.add(new Jama.Matrix(
						new double[(int) java.lang.Math.pow(omega
								.getExecutionData()
								.getNumberDiscreteCapacityPoints(), omega
								.getExecutionData().getMarket().NUM_FIRMS - 1)][omega
								.getExecutionData().getMarket().NUM_FIRMS]));
				values.add(new Jama.Matrix(
						new double[(int) java.lang.Math.pow(omega
								.getExecutionData()
								.getNumberDiscreteCapacityPoints(), omega
								.getExecutionData().getMarket().NUM_FIRMS - 1)][1]));
				int Dmin = countOtherIncumbents(space.getExpandedList().get(t)
						.getMatrix());
				if (space.getExpandedList().get(t).getMatrix().get(0, 0) == 0) {
					for (int i = Dmin; i < omega.getExecutionData().getMarket().NUM_FIRMS; i++) {
						generateIndex(i + 1, t, active);
					}
				}
			}
		}
	}

	public Jama.Matrix getCoefficients(int t) {
		return coeff.get(t);
	}

	public Jama.Matrix getValues(int t) {
		return values.get(t);
	}

	public void updateCoefficient(Jama.Matrix value) {
		// update value of coefficients
		int N = space.getExecutionData().getNumberDiscreteCapacityPoints();
		int D = space.getExecutionData().getMarket().NUM_FIRMS;
		int totalFirms = 0;
		// for each block of states over possible number of entrant active firms
		for (int t = 0; t < numStates; t++) { // possible states
			int Dmin = countOtherIncumbents(space.getExpandedList().get(t)
					.getMatrix());
			Jama.Matrix c = new Jama.Matrix((int) java.lang.Math.pow(N + 2, D),
					D);
			if (!isActive) {
				c = new Jama.Matrix((int) java.lang.Math.pow(N + 2, D - 1), D);
			}
			Jama.Matrix indexes = index.get(t);
			for (int i = Dmin; i < D; i++) { // possible combinations of other
												// active firms - needs to be
												// changed for expanded state
												// space
				if (isActive) {
					totalFirms = i + 1;
				} else {
					totalFirms = i;
				}
				int[] relevant = new int[(int) java.lang.Math.pow(N, totalFirms)];
				for (int k = 0; k < relevant.length; k++) {
					relevant[k] = (int) indexes.get(k, i);
				}
				// estimate coefficients
				Jama.Matrix y = value.getMatrix(relevant, 0, 0);
				c.setMatrix(0, (int) java.lang.Math.pow(N + 2, totalFirms) - 1,
						i, i, interp.getCoeff(y, 0, 0, totalFirms, N, space
								.getExecutionData().getCapacityIncrement()));
				if (totalFirms == 0) {
					c.set(0, 0, value.get(0, 0));
				}
			}
			coeff.set(t, c);
		}
	}

	public void updateCoefficient(Jama.Matrix value, int[] states) {
		// update value of coefficients
		int N = space.getExecutionData().getNumberDiscreteCapacityPoints();
		int D = space.getExecutionData().getMarket().NUM_FIRMS;
		int totalFirms = 0;
		// for each block of states over possible number of entrant active firms
		for (int t : states) { // possible states
			int Dmin = countOtherIncumbents(space.getExpandedList().get(t)
					.getMatrix());
			Jama.Matrix c = new Jama.Matrix((int) java.lang.Math.pow(N + 2, D),
					D);
			if (!isActive) {
				c = new Jama.Matrix((int) java.lang.Math.pow(N + 2, D - 1), D);
			}
			Jama.Matrix indexes = index.get(t);
			for (int i = Dmin; i < D; i++) { // possible combinations of other
												// active firms - needs to be
												// changed for expanded state
												// space
				if (isActive) {
					totalFirms = i + 1;
				} else {
					totalFirms = i;
				}
				int[] relevant = new int[(int) java.lang.Math
						.pow(N, totalFirms)];
				for (int k = 0; k < relevant.length; k++) {
					relevant[k] = (int) indexes.get(k, i);
				}
				// estimate coefficients
				Jama.Matrix y = value.getMatrix(relevant, 0, 0);
				c.setMatrix(0, (int) java.lang.Math.pow(N + 2, totalFirms) - 1,
						i, i, interp.getCoeff(y, 0, 0, totalFirms, N, space
								.getExecutionData().getCapacityIncrement()));
				if (totalFirms == 0) {
					c.set(0, 0, value.get(0, 0));
				}
			}
			coeff.set(t, c);
		}
	}

	private int countOtherIncumbents(Matrix matrix) {
		int incumbents = 0;
		for (int j = 1; j < space.getExecutionData().getMarket().NUM_FIRMS; j++) {
			if (matrix.get(j, 0) != 0) {
				incumbents += 1;
			}
		}
		return incumbents;
	}

	/** Creates a new instance of stateSpace */
	private void generateIndex(int numActive, int expandedState, boolean active) {
		if (active) {
			Jama.Matrix seed = new Jama.Matrix(space.getExecutionData()
					.getMarket().NUM_FIRMS, 2, 0);
			seed.setMatrix(0,
					space.getExecutionData().getMarket().NUM_FIRMS - 1, 1, 1,
					sortInverse(space.getExpandedList().get(expandedState)
							.getMatrix()));
			ArrayList<Jama.Matrix> list = new ArrayList<Jama.Matrix>();
			addSeedingState(seed, 1, numActive, expandedState, list);
		} else {
			Jama.Matrix seed = new Jama.Matrix(space.getExecutionData()
					.getMarket().NUM_FIRMS, 2, 0);
			seed.setMatrix(0,
					space.getExecutionData().getMarket().NUM_FIRMS - 1, 1, 1,
					sortInverse(space.getExpandedList().get(expandedState)
							.getMatrix()));
			ArrayList<Jama.Matrix> list = new ArrayList<Jama.Matrix>();
			addSeedingState(seed, 2, numActive, expandedState, list);
		}
	}

	public void addSeedingState(Jama.Matrix last, int level, int maximumLevel,
			int expandedState, ArrayList<Jama.Matrix> list) {
		if (level == maximumLevel) {
			Jama.Matrix vector = last.copy();
			vector.set(level - 1, 0, 0);
			for (int cap = space.getExecutionData().getMinCapacity(); cap <= space
					.getExecutionData().getMaxCapacity(); cap += space
					.getExecutionData().getCapacityIncrement()) {
				vector = last.copy();
				vector.set(level - 1, 0, cap);
				list.add(vector);
				int shortcut = findShortcut(vector);
				int kindex = list.size() - 1;
				setIndex(maximumLevel, expandedState, kindex, shortcut);
			}
		} else if (level < maximumLevel) {
			Jama.Matrix vector = last.copy();
			for (int cap = space.getExecutionData().getMinCapacity(); cap <= space
					.getExecutionData().getMaxCapacity(); cap += space
					.getExecutionData().getCapacityIncrement()) {
				vector = last.copy();
				vector.set(level - 1, 0, cap);
				addSeedingState(vector, level + 1, maximumLevel, expandedState,
						list);
			}
		} else {
			Jama.Matrix vector = last.copy();
			list.add(vector);
			int shortcut = findShortcut(vector);
			int kindex = 0;
			setIndex(maximumLevel, expandedState, kindex, shortcut);
		}
	}

	private void setIndex(int active, int expandedState, int kindex,
			int shortcut) {
		index.get(expandedState).set(kindex, active - 1, shortcut);
	}

	private int findShortcut(Jama.Matrix startMatrix) {
		// find states that are equivalent
		Jama.Matrix sortedMatrix = space.sortOnFirmId(startMatrix);
		stateSpacePoint pt = space.getPoint(sortedMatrix);
		return space.getPointIndex(pt);
	}

	private Matrix sortInverse(Matrix x) {
		// sort firms depending on their id (used in shortcut)
		int size = x.getRowDimension(); // number of firms
		Jama.Matrix temp = new Jama.Matrix(size, 1);
		temp.set(0, 0, x.get(0, 0)); // firm state
		ArrayList<Double> list = new ArrayList<Double>(size - 1);
		for (int i = 1; i < size; i++) {
			list.add(new Double(x.get(i, 0)));
		}
		Collections.sort(list);
		for (int i = 1; i < size; i++) {
			double value = (list.get(size - i - 1)).doubleValue();
			temp.set(i, 0, value);
		}
		return temp;
	}
}
