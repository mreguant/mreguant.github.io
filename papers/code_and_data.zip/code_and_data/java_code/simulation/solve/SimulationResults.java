/**
 * SimulationResults.java
 * 
 * Container class for simulation outcomes.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */
package simulation.solve;

import Jama.Matrix;

import simulation.simulate.simulationResultsCSVContainer;


public class SimulationResults {

	private double averageProducerProfit;
	private Jama.Matrix profitVector;
	private double averageSizeOverall;
	private double marketSizeOverall;
	private double quantityProduced;
	private double averagePrice;
	private double averagePriceEmissions;
	private double averageEmissions;
	private double simCS;
	private double simCarbon;
	private double simEmissions;
	private double simLeakage;
	private double nofirms;
	private double onefirm;
	private double twofirms;
	private double threefirms;
	private double fourfirms;
	private double fivefirms;
	private double sixfirms;
	private double averagefirms;
	private String simulationDescription;
	private Matrix W;
	private ExecutionInformation executionData;
	private simulationResultsCSVContainer outCSVContainer;
	private simulationResultsCSVContainer resultsOutCSVContainer;
	private simulationResultsCSVContainer panelResultsOutCSVContainer;

	public SimulationResults(simulationResultsCSVContainer out,
			simulationResultsCSVContainer resultsOut,
			simulationResultsCSVContainer panelResultsOut,
			ExecutionInformation executionData, double averageProducerProfit,
			Matrix profitVector, double averageSizeOverall,
			double marketSizeOverall, double quantityProduced,
			double averagePrice, double averagePriceEmissions,
			double averageEmissions, double simCS, double simCarbon,
			double simEmissions, double simLeakage, double nofirms,
			double onefirm, double twofirms, double threefirms,
			double fourfirms, double fivefirms, double sixfirms,
			double averagefirms, Jama.Matrix W) {
		this.outCSVContainer = out;
		this.resultsOutCSVContainer = resultsOut;
		this.panelResultsOutCSVContainer = panelResultsOut;
		this.executionData = executionData;
		this.simulationDescription = executionData.getSimulationDescription();
		this.averageProducerProfit = averageProducerProfit;
		this.profitVector = profitVector;
		this.averageSizeOverall = averageSizeOverall;
		this.marketSizeOverall = marketSizeOverall;
		this.quantityProduced = quantityProduced;
		this.averagePrice = averagePrice;
		this.averagePriceEmissions = averagePriceEmissions;
		this.averageEmissions = averageEmissions;
		this.simCS = simCS;
		this.simCarbon = simCarbon;
		this.simEmissions = simEmissions;
		this.simLeakage = simLeakage;
		this.nofirms = nofirms;
		this.onefirm = onefirm;
		this.twofirms = twofirms;
		this.threefirms = threefirms;
		this.fourfirms = fourfirms;
		this.fivefirms = fivefirms;
		this.sixfirms = sixfirms;
		this.averagefirms = averagefirms;
		this.W = W;
	}

	@Override
	public String toString() {
		return "p: " + averagePrice + " q: " + quantityProduced + " profit: "
				+ profitVector.get(0, 0);
	}

	public int getNumFirms() {
		return executionData.getMarket().NUM_FIRMS;
	}

	public double getTotalWelfare() {
		return averageProducerProfit * executionData.getMarket().NUM_FIRMS
				+ simCarbon + simCS;
	}

	public double getProfitFirm1() {
		return profitVector.get(0, 0);
	}

	/**
	 * @return the averageProducerProfit
	 */
	public double getAverageProducerProfit() {
		return averageProducerProfit;
	}

	/**
	 * @return the profitVector
	 */
	public Jama.Matrix getProfitVector() {
		return profitVector;
	}

	/**
	 * @return the averageSizeOverall
	 */
	public double getAverageSizeOverall() {
		return averageSizeOverall;
	}

	/**
	 * @return the marketSizeOverall
	 */
	public double getMarketSizeOverall() {
		return marketSizeOverall;
	}

	/**
	 * @return the quantityProduced
	 */
	public double getQuantityProduced() {
		return quantityProduced;
	}

	/**
	 * @return the averagePrice
	 */
	public double getAveragePrice() {
		return averagePrice;
	}

	/**
	 * @return the averagePriceEmissions
	 */
	public double getAveragePriceEmissions() {
		return averagePriceEmissions;
	}

	/**
	 * @return the averageEmissions
	 */
	public double getAverageEmissions() {
		return averageEmissions;
	}

	/**
	 * @return the simCS
	 */
	public double getSimCS() {
		return simCS;
	}

	/**
	 * @return the simCarbon
	 */
	public double getSimCarbon() {
		return simCarbon;
	}

	/**
	 * @return the simEmissions
	 */
	public double getSimEmissions() {
		return simEmissions;
	}

	/**
	 * @return the simLeakage
	 */
	public double getSimLeakage() {
		return simLeakage;
	}

	/**
	 * @return the nofirms
	 */
	public double getNofirms() {
		return nofirms;
	}

	/**
	 * @return the onefirm
	 */
	public double getOnefirm() {
		return onefirm;
	}

	/**
	 * @return the twofirms
	 */
	public double getTwofirms() {
		return twofirms;
	}

	/**
	 * @return the threefirms
	 */
	public double getThreefirms() {
		return threefirms;
	}

	/**
	 * @return the fourfirms
	 */
	public double getFourfirms() {
		return fourfirms;
	}

	/**
	 * @return the fivefirms
	 */
	public double getFivefirms() {
		return fivefirms;
	}

	/**
	 * @return the sixfirms
	 */
	public double getSixfirms() {
		return sixfirms;
	}

	/**
	 * @return the averagefirms
	 */
	public double getAveragefirms() {
		return averagefirms;
	}

	/**
	 * @return the simulationDescription
	 */
	public String getSimulationDescription() {
		return simulationDescription;
	}

	/**
	 * @return the W
	 */
	public Matrix getW() {
		return W;
	}

	/**
	 * @return the outCSVContainer
	 */
	public simulationResultsCSVContainer getOutCSVContainer() {
		return outCSVContainer;
	}

	/**
	 * @return the resultsOutCSVContainer
	 */
	public simulationResultsCSVContainer getResultsOutCSVContainer() {
		return resultsOutCSVContainer;
	}

	/**
	 * @return the panelResultsOutCSVContainer
	 */
	public simulationResultsCSVContainer getPanelResultsOutCSVContainer() {
		return panelResultsOutCSVContainer;
	}

	void writeResultsToCSV() {
		outCSVContainer.dumpCSV();
		resultsOutCSVContainer.dumpCSV();
		panelResultsOutCSVContainer.dumpCSV();
	}
}
