/**
 * iteratedSolver.java
 * 
 * This is the main file that performs the iterated best-response
 * equilibrium calculation. For every iteration, it computes best responses
 * and updates the value and policy functions.
 * Turn "DISPLAY_GUI" on to see the progress of the simulation.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;


import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;

import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.jfree.data.xy.XYSeries;

import simulation.utility.*;
import utility.pmUtility;


public class iteratedSolver {

	// SOLVER PARAMETERS
	private double DAMPENER = 1.0;
	
	// GUI parameters
	private boolean DISPLAY_GUI = false;
	/**
	 * Other miscellaneous variables.
	 */
	private static double convergenceThreshold = primitives.CONVERGENCE_CRITERION;
	private double dampenI = 0;
	private double dampenIP = 0;
	private double dampenP = 0;
	private double dampenInvNoAdj = 0;
	private int turnover = 1;
	private int pcount = turnover - 1;
	private double dampenLevel = DAMPENER;
	private boolean stopnow = false;
	
	// gui components
	JButton buttonShowInvestmentChange = new JButton("Show Inv");
	JButton graphButton2 = new JButton("Show Convergence");
	JCheckBox solveIndicator = new JCheckBox("Solve Inv", true);
	JCheckBox dampenIndicator = new JCheckBox("Dampen Val", false);
	JCheckBox dampenIndicatorI = new JCheckBox("Dampen Inv", false);
	JCheckBox dampenIndicatorP = new JCheckBox("Dampen PrEntry", true);
	JCheckBox dampenIndicatorIP = new JCheckBox("Dampen PrInv", true);
	JCheckBox dampenIndicatorInvNoAdj = new JCheckBox("Dampen InvNoAdj", true);
	JButton crushButton = new JButton("Crush");
	JProgressBar bar = new JProgressBar();
	JLabel status = new JLabel("Status bar");
	org.jfree.data.xy.XYSeries xy = new org.jfree.data.xy.XYSeries("Value");
	org.jfree.data.xy.XYSeries policy = new org.jfree.data.xy.XYSeries("Policy");
	org.jfree.data.xy.XYSeries conv = new org.jfree.data.xy.XYSeries(
			"Value Norm");
	XYSeries policyConvergence = new XYSeries("Investment Norm");
	XYSeries investmentProbabilityConvergence = new XYSeries("Inv Prob Norm");
	
	// state space
	stateSpace s;
	// specification modifiers
	String cf = "";
	String ceasar = "";

	ExecutorService tpes = Executors.newFixedThreadPool(6);
	ExecutionInformation executionData;

	/**
	 * Creates a new instance of iteratedSolver
	 */
	public iteratedSolver(stateSpace s) {
		this.s = s;
		executionData = s.getExecutionData();
		
		JFrame tableFrame = new JFrame("Table " + s.getStateSpaceSize() + " "
				+ " " + cf + " " + ceasar);
		tableFrame.setBounds(100, 100, 1000, 800);
		JTable table = s.getTable(this);
		JPanel tablePanel = new JPanel(true);
		tablePanel.setLayout(new BorderLayout());
		tablePanel.add(new JScrollPane(table), BorderLayout.CENTER);
		tableFrame.getContentPane().add(new JScrollPane(table),
				BorderLayout.CENTER);
		JButton showDialog = new JButton("Options");

		JPanel south = new JPanel();
		south.setLayout(new BorderLayout());
		south.add(showDialog, BorderLayout.EAST);
		south.add(status, BorderLayout.WEST);

		tableFrame.getContentPane().add(south, BorderLayout.SOUTH);

		final JDialog statusDialog = new JDialog(tableFrame, "Options", false);
		showDialog.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (statusDialog.isVisible()) {
					statusDialog.setVisible(false);
				} else {
					statusDialog.setVisible(true);
				}
			}
		});

		dampenIP = dampenLevel;
		dampenInvNoAdj = dampenLevel;
		dampenP = dampenLevel; // probability of entry
		JPanel rightPanel = new JPanel();

		rightPanel.add(dampenIndicator);
		rightPanel.add(dampenIndicatorI);
		rightPanel.add(dampenIndicatorP);
		rightPanel.add(dampenIndicatorIP);
		rightPanel.add(dampenIndicatorInvNoAdj);
		rightPanel.add(solveIndicator);
		rightPanel.add(buttonShowInvestmentChange);
		rightPanel.add(graphButton2);
		rightPanel.add(crushButton);

		crushButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				DAMPENER = (1.0 - (1.0 - DAMPENER) / 10.0);
				System.out.println("Dampener: " + DAMPENER);
			}
		});

		final JButton finishButton = new JButton("You are beaten");
		finishButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				stopnow = true;
				finishButton.setText("Shutting Down");
				dampenIndicator.setEnabled(false);
				dampenIndicatorI.setEnabled(false);
				dampenIndicatorP.setEnabled(false);
				dampenIndicatorIP.setEnabled(false);
				dampenIndicatorInvNoAdj.setEnabled(false);
				solveIndicator.setEnabled(false);
			}
		});
		rightPanel.add(finishButton);
		final JTextField dampenField = new JTextField(
				Double.toString(dampenLevel));
		dampenField.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dampenLevel = Double.parseDouble(dampenField.getText());
			}
		});

		JPanel dampenFieldPanel = new JPanel();
		dampenFieldPanel.add(new JLabel("Dampen: "));
		dampenFieldPanel.add(dampenField);
		rightPanel.add(dampenFieldPanel);

		SpinnerNumberModel model = new SpinnerNumberModel(turnover, 1, 25, 1);
		final JSpinner mySpin = new JSpinner(model);
		rightPanel.add(mySpin);
		if (s.getNumFirms() > 3) {
			rightPanel.add(bar);
		}		
		rightPanel.setLayout(new GridLayout(0, 1));
		statusDialog.getContentPane().add(rightPanel, BorderLayout.CENTER);
		statusDialog.setBounds(1100, 500, 400, 400);
		statusDialog.pack();
		statusDialog.setVisible(DISPLAY_GUI);
		tableFrame.setVisible(DISPLAY_GUI);
		tableFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		mySpin.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				turnover = ((Integer) mySpin.getValue()).intValue();
				pcount = turnover - 1;
			}
		});

		dampenIndicator.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (dampenIndicator.isSelected()) {
					DAMPENER = dampenLevel;
				} else {
					DAMPENER = 0;
				}
			}
		});

		dampenIndicatorI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (dampenIndicatorI.isSelected()) {
					dampenI = dampenLevel;
				} else {
					dampenI = 0;
				}
			}
		});

		dampenIndicatorP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (dampenIndicatorP.isSelected()) {
					dampenP = dampenLevel;
				} else {
					dampenP = 0;
				}
			}
		});

		dampenIndicatorIP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (dampenIndicatorIP.isSelected()) {
					dampenIP = dampenLevel;
				} else {
					dampenIP = 0;
				}
			}
		});

		dampenIndicatorInvNoAdj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (dampenIndicatorInvNoAdj.isSelected()) {
					dampenInvNoAdj = dampenLevel;
				} else {
					dampenInvNoAdj = 0;
				}
			}
		});

		org.jfree.data.xy.XYSeriesCollection sc = new org.jfree.data.xy.XYSeriesCollection();

		sc.addSeries(xy);
		sc.addSeries(policy);
		ChartPanel panel = new ChartPanel(ChartFactory.createXYLineChart(
				"Policy Convergence", "State", "Change", sc,
				PlotOrientation.VERTICAL, false, false, false));
		final JDialog policyChangeGraph = new JDialog(tableFrame,
				"Policy Function change");
		policyChangeGraph.setBounds(300, 300, 400, 400);
		policyChangeGraph
				.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		policyChangeGraph.getContentPane().add(panel);

		org.jfree.data.xy.XYSeriesCollection convColl = new org.jfree.data.xy.XYSeriesCollection();

		convColl.addSeries(conv);
		convColl.addSeries(policyConvergence);
		convColl.addSeries(investmentProbabilityConvergence);
		ChartPanel panel2 = new ChartPanel(ChartFactory.createXYLineChart(
				"Convergence", "Iteration", "Log Change", convColl,
				PlotOrientation.VERTICAL, true, true, true));
		final JDialog graph2 = new JDialog(tableFrame, "Convergence");
		graph2.setBounds(700, 300, 400, 400);
		graph2.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		graph2.getContentPane().add(panel2);

		buttonShowInvestmentChange
				.addActionListener(new java.awt.event.ActionListener() {

					@Override
					public void actionPerformed(java.awt.event.ActionEvent e) {
						if (policyChangeGraph.isVisible()) {
							policyChangeGraph.setVisible(false);
							buttonShowInvestmentChange.setText("Show Policy");
						} else {
							policyChangeGraph.setVisible(true);
							buttonShowInvestmentChange.setText("Hide Policy");
						}
					}
				});

		graphButton2.addActionListener(new java.awt.event.ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				if (graph2.isVisible()) {
					graph2.setVisible(false);
					graphButton2.setText("Show Convergence");
				} else {
					graph2.setVisible(true);
					graphButton2.setText("Hide Convergence");
				}
			}
		});
	}

	public void execute() {
		/*
		 * Boolean to decide whether to write output at this stage Causes
		 * problems on remote compute nodes
		 */
		boolean writeConvergenceOutput = true;

		boolean converged = false;
		boolean first = true;
		Jama.Matrix v1 = new Jama.Matrix(s.getStateSpaceSize(), 1);
		Jama.Matrix v2 = new Jama.Matrix(s.getStateSpaceSize(), 1);
		Jama.Matrix p1 = new Jama.Matrix(s.getStateSpaceSize(), 1);
		Jama.Matrix p2 = new Jama.Matrix(s.getStateSpaceSize(), 1);
		Jama.Matrix probInv1 = new Jama.Matrix(s.getStateSpaceSize(), 1);
		Jama.Matrix probInv2 = new Jama.Matrix(s.getStateSpaceSize(), 1);

		// initialize coefficients and pre-specified weights of spline
		coefficientValues coefficients = new coefficientValues(s, true);

		for (int i = 0; i < v1.getRowDimension(); i++) {
			xy.add(i, v2.get(i, 0) - v1.get(i, 0));
			policy.add(i, p2.get(i, 0) - p1.get(i, 0));
		}

		long t1, t2;

		t1 = System.currentTimeMillis();

		int countStates = 0;
		int countExpanded = 0;

		// create files to save output
		String specificationName = executionData.getMarket().name;
		specificationName += "_" + executionData.getSimulationDescription();
		specificationName += "_" + executionData.getCarbonTax();
		String resultsOutFilename = "data/" + executionData.getMarket().name
				+ "/table_" + specificationName + ".txt";
		String resultsConvergenceFilename = "data/"
				+ executionData.getMarket().name + "/convergence_"
				+ specificationName + ".txt";
		File directoryMaker = new File("data/" + executionData.getMarket().name);
		directoryMaker.mkdirs();
		BufferedWriter resultsConvergence = null;
		try {
			if (writeConvergenceOutput) {
				resultsConvergence = new BufferedWriter(new FileWriter(
						resultsConvergenceFilename));
				resultsConvergence
						.write("state;converged;valueNorm;investNorm;prInvNorm;iterations\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (int t = 0; t < s.getNumStates(); t++) {
			if (pmUtility.sortMatrixAscending(s.getExpandedList().get(t).getMatrix())
					.minus(s.getExpandedList().get(t).getMatrix()).norm1() == 0) {
				// Print current expanded state
				System.out.print("Now solving ");
				pmUtility.prettyPrintVector(s.getExpandedList().get(t)
						.getMatrix());

				// create lists of joint expanded states
				int[] temp = new int[s.getStateSpaceSize()];
				countStates = 0;
				for (int i = 0; i < s.getStateSpaceSize(); i++) {
					if (pmUtility.sortMatrixAscending(s.getPoint(i).getMatrix().getMatrix(0,executionData.getMarket().NUM_FIRMS - 1,1, 1))
							.minus(s.getExpandedList().get(t).getMatrix()).norm1() == 0) {
						temp[countStates] = i;
						countStates += 1;
					}
				}
				int[] list = new int[countStates];
				System.arraycopy(temp, 0, list, 0, countStates);
				countExpanded = 0;
				temp = new int[s.getExpandedList().size()];
				for (int i = 0; i < s.getExpandedList().size(); i++) {
					if (pmUtility.sortMatrixAscending(s.getExpandedList().get(i).getMatrix())
							.minus(s.getExpandedList().get(t).getMatrix()).norm1() == 0) {
						temp[countExpanded] = s.getExpandedIndex(s.getExpandedList().get(i).getMatrix());
						countExpanded += 1;
					}
				}
				int[] states = new int[countExpanded];
				System.arraycopy(temp, 0, states, 0, countExpanded);

				converged = false;

				int prelimIt = 0;
				int iterations = 0;
				double maxIter = 1500;
				int[] dampThreshold = { 250 }; //, 150, 0};

				for (int threshold : dampThreshold) {
					if (!converged) {
						DAMPENER = 0.9;
						iterations = 0;
						// initial guess from baseline iteration
						if (t == 0) {
							for (int i : list) {
								v1.set(i, 0, 0.0);
								p1.set(i, 0, 0.0);
								probInv1.set(i, 0, 0.0);
							}
						} else {
							// update value and policy functions
							for (int i : list) {
								Jama.Matrix state = new Jama.Matrix(s.getNumFirms(), 2);
								for (int n = 0; n < s.getNumFirms(); n++) {
									state.set(n, 0, s.getPoint(i).getMatrix().get(n, 0));
									state.set(n, 1, 0);
								}
								stateSpacePoint point = s.getPoint(state);
								v1.set(i, 0, point.getValue());
								p1.set(i, 0, point.getPolicy());
								probInv1.set(i, 0, point.getInvestProb());
							}
						}
						coefficients.updateCoefficient(v1, states);
					}
					while (!converged && iterations < maxIter) {
						if (!converged) {
							iterations++;

							long time1 = System.currentTimeMillis();
							bar.setMaximum(s.getStateSpaceSize() - 1);

							// eventually increase dampener after going to a
							// closer point
							if (iterations == threshold) {
								DAMPENER = 0.99;
							}
							if (iterations == 1000) {
								DAMPENER = 0.999;
							}

							// iterate investment and policy functions holding
							// everything else fixed (not used)
							for (int it = 0; it < prelimIt; it++) {
								for (int i : list) {
									stateSpacePoint point = s.getPoint(i);
									point.solveValue(true, coefficients);
									point.updateInvestmentOnly(DAMPENER);
								}
							}

							// solve for policies
							solveBellman(true, coefficients, list, DAMPENER);

							for (int i : list) {
								stateSpacePoint point = s.getPoint(i);
								point.updateState(DAMPENER);
								v2.set(i, 0, v1.get(i, 0));
								v1.set(i, 0, point.getValue());
								p2.set(i, 0, p1.get(i, 0));
								p1.set(i, 0, point.getPolicy());
								probInv2.set(i, 0, probInv1.get(i, 0));
								probInv1.set(i, 0, point.getInvestProb());
								s.updateTable(i);
							}

							coefficients.updateCoefficient(v1, states);

							// check convergence and others
							long time2 = System.currentTimeMillis();
							Jama.Matrix block1 = v1.getMatrix(list, 0, 0);
							Jama.Matrix block2 = v2.getMatrix(list, 0, 0);
							Jama.Matrix change = block1.minus(block2);

							Jama.Matrix pBlock1 = p1.getMatrix(list, 0, 0);
							Jama.Matrix pBlock2 = p2.getMatrix(list, 0, 0);
							Jama.Matrix pChange = pBlock1.minus(pBlock2);

							Jama.Matrix prBlock1 = probInv1.getMatrix(list, 0, 0);
							Jama.Matrix prBlock2 = probInv2.getMatrix(list, 0, 0);
							Jama.Matrix prChange = prBlock1.minus(prBlock2);

							double norm = change.norm2() / (countStates * 1000);
							double pNorm = pChange.norm2() / ((1.0 - DAMPENER) * countStates * 100);
							double prInvNorm = prChange.norm2()	/ ((1.0 - DAMPENER) * countStates);

							double largestChange = change.get(0, 0);
							double largestChangePct = change.get(0, 0) / block2.get(0, 0);
							for (int cm = 1; cm < list.length; cm++) {
								if (Math.abs(change.get(cm, 0)) > Math.abs(largestChange)) {
									largestChange = change.get(cm, 0);
								}
								if (Math.abs(change.get(cm, 0) / block2.get(cm, 0)) > Math.abs(largestChangePct)) {
									largestChangePct = change.get(cm, 0) / block2.get(cm, 0);
								}
							}

							double largestPChange = pChange.get(0, 0);
							double largestPChangePct = pChange.get(0, 0) / pBlock2.get(0, 0);
							for (int cm = 1; cm < list.length; cm++) {
								if (Math.abs(pChange.get(cm, 0)) > Math.abs(largestPChange)) {
									largestPChange = pChange.get(cm, 0);
								}
								if (Math.abs(pChange.get(cm, 0)	/ pBlock2.get(cm, 0)) > Math.abs(largestPChangePct)) {
									largestPChangePct = pChange.get(cm, 0) / pBlock2.get(cm, 0);
								}
							}

							if (first) {
								first = false;
							} else if (DISPLAY_GUI) {
								status.setText(norm + " (" + (100 * (norm))	+ ") " + pNorm + " " + prInvNorm + " time: " + ((time2 - time1) / 1000.0));
								conv.add(iterations, Math.log(1 + norm));
								policyConvergence.add(iterations, Math.log(1 + pNorm));
								investmentProbabilityConvergence.add(iterations, Math.log(1 + prInvNorm));
							}

							// Try just focusing on policy function convergence
							if (norm < convergenceThreshold && pNorm < convergenceThreshold && prInvNorm < convergenceThreshold && iterations > 5) {
								converged = true;
								try {
									if (writeConvergenceOutput) {
										resultsConvergence.write(t + ";" + converged + ";" + norm + ";"	+ pNorm + ";" + prInvNorm + ";"	+ iterations + "\n");
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
							}

							if (stopnow) {
								System.out.println("Forced stop with norms " + norm + " " + pNorm + " " + prInvNorm);
								try {
									if (writeConvergenceOutput) {
										resultsConvergence.write(t + ";" + converged + ";" + norm + ";" + pNorm + ";" + prInvNorm + ";"	+ iterations + "\n");
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
								converged = true;
							}
							if (iterations == maxIter) {
								try {
									if (writeConvergenceOutput) {
										resultsConvergence.write(t + ";" + converged + ";" + norm + ";"	+ pNorm + ";" + prInvNorm + ";"	+ iterations + "\n");
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
								System.out.println("False convergence--stopping due to the iteration limit with norms "
												+ norm
												+ " "
												+ pNorm
												+ " "
												+ prInvNorm);
							}

						}
						if (converged) {
							t2 = System.currentTimeMillis();
							System.out.println("Time to convergence " + (t2 - t1) / 1000 + " Number of iterations: " + iterations);
						}
					}
				}

			}
		}

		stateSpaceTableModel tableFinal = s.getTableModel();
		StringBuffer buffer = new StringBuffer();
		int row, column, header;
		// Write Header
		for (header = 0; header < tableFinal.getColumnCount(); header++) {
			buffer.append(tableFinal.getColumnName(header));
			buffer.append(';');
		}
		buffer.append('\n');
		// Write cell data
		for (row = 0; row < tableFinal.getRowCount(); row++) {
			for (column = 0; column < tableFinal.getColumnCount(); column++) {
				buffer.append(tableFinal.getValueAt(row, column));
				buffer.append(';');
			}
			buffer.append('\n');
		}
		// Write the buffer to a file
		BufferedWriter resultsOut;
		try {
			if (writeConvergenceOutput) {
				resultsOut = new BufferedWriter(new FileWriter(resultsOutFilename));
				resultsOut.append(buffer);
				resultsOut.close();
				resultsConvergence.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		tpes.shutdown();
	}

	private void solveBellman(boolean solvePolicy, coefficientValues c,
			int[] list, double dampener) {
		// solve Bellman if interpolation
		boolean useMultipleCPU = false;
		if (useMultipleCPU) {
			ArrayList<Future<Integer>> futureList = new ArrayList<Future<Integer>>();
			for (int i : list) {
				futureList.add(tpes.submit(new SolveBellmanTask(s.getPoint(i),
						solvePolicy, c, dampener)));
			}
			try {
				for (int i = 0; i < futureList.size(); i++) {
					futureList.get(futureList.size() - i - 1).get();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			for (int i = -list.length + 1; i < 1; i++) {
				stateSpacePoint point = s.getPoint(list[-i]);
				point.solveValue(solvePolicy, c);
				point.updateInvestmentOnly(DAMPENER);
				point.updatePolicyOnly(DAMPENER);
			}
		}
	}
}
