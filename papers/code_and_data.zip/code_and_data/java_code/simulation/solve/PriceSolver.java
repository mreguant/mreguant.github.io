/**
 * PriceSolver.java
 * 
 * This function calculate the inverse residual demand 
 * after accounting for imports.
 * It provides prices at a given domestic quantity as well as
 * the slope and the imports amount.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package simulation.solve;

import optimization.Fmin;
import optimization.Fmin_methods;
import simulation.utility.primitives;


public class PriceSolver implements Fmin_methods {

	private double aggregateElasticity;
	private double aggregateIntercept;
	private double importElasticity;
	private double importIntercept;
	private double domesticQuantity;
	private int scheme;
	private double carbontax;

	public PriceSolver(ExecutionInformation executionData) {
		this.aggregateElasticity = executionData.getAggregateElasticity();
		this.aggregateIntercept = executionData.getAggregateIntercept();
		this.importElasticity = executionData.getImportElasticity();
		this.importIntercept = executionData.getImportIntercept();
		this.scheme = executionData.getScheme();
		this.carbontax = executionData.getCarbonTax();
	}

	public double getPrice(double domesticQuantity) {
		this.domesticQuantity = domesticQuantity;
		return Fmin.fmin(0, 500, this, 1E-10);
	}

	public double getSlope(double domesticQuantity) {		
		double slope = 0;
		double h = 1E-3;
		slope = (getPrice(domesticQuantity + h) - getPrice(domesticQuantity - h)) / (2 * h);
		return slope;
	}

	public double getImports(double domesticQuantity) {
		System.out.println("Domestic quantity: " + domesticQuantity);
		System.out.println("Import Intercept: " + importIntercept);
		System.out.println("Import Elasticity: " + importElasticity);
		System.out.println("Price: " + getPrice(domesticQuantity));
		double imports = 0.0;
		if (scheme == primitives.SCHEME_BTA) {
			imports = importIntercept
					* Math.pow(Math.max(getPrice(domesticQuantity) - carbontax
								* primitives.IMPORT_ERATE, 0.0), importElasticity);
		} else {
			imports = importIntercept
					* Math.pow(getPrice(domesticQuantity), importElasticity);
		}
		return imports;
	}

	@Override
	public double f_to_minimize(double x) {
		double v = 0.0;
		if (scheme == primitives.SCHEME_BTA) {
			v = domesticQuantity
					- (Math.exp(aggregateIntercept)
							* Math.pow(x, -aggregateElasticity) - importIntercept
							* Math.pow(Math.max(x - carbontax * primitives.IMPORT_ERATE, 0.0),
									importElasticity));
		} else {
			v = domesticQuantity
					- (Math.exp(aggregateIntercept)
							* Math.pow(x, -aggregateElasticity) - importIntercept
							* Math.pow(x, importElasticity));
		}		
		return v * v;
	}

}
