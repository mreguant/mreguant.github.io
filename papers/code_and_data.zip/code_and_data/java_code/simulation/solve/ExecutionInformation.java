/**
 * ExecutionInformation.java
 * 
 * Contains information relative to a given simulation, such
 * as market, policy considered (scheme), elasticity values,
 * and number of points and size of the interpolation.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.solve;

import simulation.utility.primitives;

public class ExecutionInformation {

	private String simulationDescription;
	private regionalMarket market;
	private double carbonTax = 0.0;
	private int scheme = primitives.SCHEME_AUCTION;
	private int maxCapacity;
	private int minCapacity;
	private int capacityIncrement;
	private int numberDiscreteCapacityPoints;
	private double marketwideFreePermits = 0.0;
	private double IMPORT_TAX = 0.0;
	private double IMPORT_ELASTICITY = 2.5;
	private double IMPORT_INTERCEPT = 0.0;
	private double IMPORT_ERATE = 0.97;
	private double grandfatheringRate = 0.0;

	public ExecutionInformation() {
	}

	/**
	 * @return the simulationDescription
	 */
	public String getSimulationDescription() {
		return simulationDescription;
	}

	/**
	 * @return the market
	 */
	public regionalMarket getMarket() {
		return market;
	}

	/**
	 * @return the carbonTax
	 */
	public double getCarbonTax() {
		return carbonTax;
	}

	/**
	 * @return the SCHEME
	 */
	public int getScheme() {
		return scheme;
	}

	/**
	 * @return the MAX_CAPACITY
	 */
	public int getMaxCapacity() {
		return maxCapacity;
	}

	/**
	 * @return the MIN_CAPACITY
	 */
	public int getMinCapacity() {
		return minCapacity;
	}

	/**
	 * @return the CAPACITY_INC
	 */
	public int getCapacityIncrement() {
		return capacityIncrement;
	}

	/**
	 * @return the CAPACITY_POINTS
	 */
	public int getNumberDiscreteCapacityPoints() {
		return numberDiscreteCapacityPoints;
	}

	/**
	 * @param CAPACITY_POINTS
	 *            the CAPACITY_POINTS to set
	 */
	public void setNumberDiscreteCapacityPoints(int CAPACITY_POINTS) {
		this.numberDiscreteCapacityPoints = CAPACITY_POINTS;
	}

	/**
	 * @param simulationDescription
	 *            the simulationDescription to set
	 */
	public void setSimulationDescription(String simulationDescription) {
		this.simulationDescription = simulationDescription;
	}

	/**
	 * @param market
	 *            the market to set
	 */
	public void setMarket(regionalMarket market) {
		this.market = market;
	}

	/**
	 * @param carbonTax
	 *            the carbonTax to set
	 */
	public void setCarbonTax(double carbonTax) {
		this.carbonTax = carbonTax;
	}

	/**
	 * @param SCHEME
	 *            the SCHEME to set
	 */
	public void setScheme(int SCHEME) {
		this.scheme = SCHEME;
	}

	/**
	 * @param MAX_CAPACITY
	 *            the MAX_CAPACITY to set
	 */
	public void setMaxCapacity(int MAX_CAPACITY) {
		this.maxCapacity = MAX_CAPACITY;
	}

	/**
	 * @param MIN_CAPACITY
	 *            the MIN_CAPACITY to set
	 */
	public void setMinCapacity(int MIN_CAPACITY) {
		this.minCapacity = MIN_CAPACITY;
	}

	/**
	 * @param CAPACITY_INC
	 *            the CAPACITY_INC to set
	 */
	public void setCapacityIncrement(int CAPACITY_INC) {
		this.capacityIncrement = CAPACITY_INC;
	}

	/**
	 * @return the marketwideFreePermits
	 */
	public double getMarketwideFreePermits() {
		return marketwideFreePermits;
	}

	/**
	 * @param marketwideFreePermits
	 *            the marketwideFreePermits to set
	 */
	public void setMarketwideFreePermits(double marketwideFreePermits) {
		this.marketwideFreePermits = marketwideFreePermits;
	}

	public double getImportEmissionsRate() {
		return IMPORT_ERATE;
	}

	/**
	 * @return the IMPORT_TAX
	 */
	public double getImportTax() {
		return IMPORT_TAX;
	}

	/**
	 * @param IMPORT_TAX
	 *            the IMPORT_TAX to set
	 */
	public void setImportTax(double IMPORT_TAX) {
		this.IMPORT_TAX = IMPORT_TAX;
	}

	/**
	 * @return the IMPORT_ELASTICITY
	 */
	public double getImportElasticity() {
		return IMPORT_ELASTICITY;
	}

	/**
	 * @param IMPORT_ELASTICITY
	 *            the IMPORT_ELASTICITY to set
	 */
	public void setImportElasticity(double IMPORT_ELASTICITY) {
		this.IMPORT_ELASTICITY = IMPORT_ELASTICITY;
	}

	/**
	 * @return the IMPORT_INTERCEPT
	 */
	public double getImportIntercept() {
		return IMPORT_INTERCEPT;
	}

	/**
	 * @param IMPORT_INTERCEPT
	 *            the IMPORT_INTERCEPT to set
	 */
	public void setImportIntercept(double IMPORT_INTERCEPT) {
		this.IMPORT_INTERCEPT = IMPORT_INTERCEPT;
	}

	/**
	 * @param IMPORT_ERATE
	 *            the IMPORT_ERATE to set
	 */
	public void setImportEmissionsRate(double IMPORT_ERATE) {
		this.IMPORT_ERATE = IMPORT_ERATE;
	}

	public double getAggregateElasticity() {
		return market.AGGREGATE_ELASTICITY;
	}

	public double getAggregateIntercept() {
		return market.AGGREGATE_INTERCEPT;
	}

	/**
	 * @return the grandfatheringRate
	 */
	public double getGrandfatheringRate() {
		return grandfatheringRate;
	}

	/**
	 * @param grandfatheringRate
	 *            the grandfatheringRate to set
	 */
	public void setGrandfatheringRate(double grandfatheringRate) {
		this.grandfatheringRate = grandfatheringRate;
	}

	/**
	 * @return Price at which import supply curve intersects the market demand
	 *         curve.
	 */
	public double getPriceNoActiveDomesticFirms() {
		double ai = market.IMPORT_INTERCEPT;
		double ad = market.AGGREGATE_INTERCEPT;
		double ei = market.IMPORT_ELASTICITY;
		double ed = -market.AGGREGATE_ELASTICITY;
		double chokePrice = Math.pow(Math.exp(ad) / ai, 1.0 / (ei - ed));
		return chokePrice;
	}
}
