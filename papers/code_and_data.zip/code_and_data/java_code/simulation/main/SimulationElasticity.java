/**
 * SimulationElasticity.java
 * 
 * Function used to compute counterfactual outcomes for sensitivity
 * on the value of the aggregate demand elasticity.
 * Arguments:
 * 0 - market
 * 1 - carbon price
 * 2 - mechanism
 * 3 - elasticity
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */ 
package simulation.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import simulation.simulate.simulationInterpolation;
import simulation.solve.ExecutionInformation;
import simulation.solve.iteratedSolver;
import simulation.solve.regionalList;
import simulation.solve.regionalMarket;
import simulation.solve.stateSpace;
import simulation.utility.primitives;


public class SimulationElasticity {

	public static void main(String[] args) throws Exception {

		String file = "data/regional_list/regionalList_nocustom_" + args[3] + ".raw";
		regionalList regional = new regionalList(file);

		regionalMarket market = regional.get(Integer.valueOf(args[0]));
		double carbonTax = Double.valueOf(args[1]);
		int scenario = Integer.valueOf(args[2]);

		ExecutionInformation executionData = new ExecutionInformation();

		double[] costs = getCosts(0);
		primitives.ADJUSTMENT_MU = costs[0];
		primitives.ADJUSTMENT_SIGMA = costs[1];
		primitives.SCRAP_MU = costs[16];
		primitives.SCRAP_SIGMA = costs[17];
		primitives.ENTRY_MU = costs[18];
		primitives.ENTRY_SIGMA = costs[19];
		primitives.INVESTMENT_MARGINAL_COST = costs[6];
		primitives.INVESTMENT_MARGINAL_COST2 = costs[7];
		primitives.DIVESTMENT_MARGINAL_COST = costs[14];
		primitives.DIVESTMENT_MARGINAL_COST2 = costs[15];
		
		double[] mgcosts = readMgParam(0);
		primitives.MARGINAL_COST_ENTRANT = mgcosts[3];
		primitives.MARGINAL_COST_INCUMBENT1 = mgcosts[3];
		primitives.MARGINAL_COST_INCUMBENT2 = mgcosts[3];
		primitives.CAPACITY_COST = mgcosts[1];
		primitives.CAPACITY_COST_BINDING_LEVEL = mgcosts[2];
		
		
		for (int i = 0; i < market.NUM_FIRMS; i++) {					
			if (market.TYPE[i] == 1) {// first incumbent
				market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT1;
			} else if (market.TYPE[i] == 2) {// second incumbent
				market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT2;
			} else if (market.TYPE[i] == 0) {// entrant
				market.MARGINAL_COST[i] = primitives.MARGINAL_COST_ENTRANT;
			}
		}
		
		// String suffix = market.name;
		market.name = market.name + "_" + args[3];
		executionData.setMarket(market);
		executionData.setImportIntercept(market.IMPORT_INTERCEPT);
		executionData.setImportElasticity(market.IMPORT_ELASTICITY);

		// put max capacity and number of points
		executionData.setNumberDiscreteCapacityPoints(primitives.NUM_DISCRETE_CAPACITY_POINTS);
		// not too sparse not too many
		executionData.setMinCapacity(200);
		executionData.setMaxCapacity(2400);
		executionData.setCapacityIncrement((executionData.getMaxCapacity() - executionData.getMinCapacity())
						/ (executionData.getNumberDiscreteCapacityPoints() - 1));
		if (market.name.equals("Detroit")) {
			executionData.setMaxCapacity(3500);
			executionData.setCapacityIncrement((executionData.getMaxCapacity() - executionData.getMinCapacity())
							/ (executionData.getNumberDiscreteCapacityPoints() - 1));
			executionData.setMaxCapacity(executionData.getMinCapacity()
					+ (executionData.getNumberDiscreteCapacityPoints() - 1)
					* (executionData.getMaxCapacity() - executionData
							.getMinCapacity())
					/ (executionData.getNumberDiscreteCapacityPoints() - 1));
		}
		if (market.name.equals("Denver") || market.name.equals("Baltimore")
				|| market.name.equals("Dallas")
				|| market.name.equals("KansasCity")
				|| market.name.equals("St.Louis")) {
			executionData.setMaxCapacity(3500);
			executionData.setCapacityIncrement((executionData.getMaxCapacity() - executionData.getMinCapacity())
							/ (executionData.getNumberDiscreteCapacityPoints() - 1));
			executionData.setMaxCapacity(executionData.getMinCapacity()
					+ (executionData.getNumberDiscreteCapacityPoints() - 1)
					* (executionData.getMaxCapacity() - executionData
							.getMinCapacity())
					/ (executionData.getNumberDiscreteCapacityPoints() - 1));
		}
		if (market.name.equals("Seattle")
				|| market.name.equals("Phoenix")
				|| market.name.equals("NewYork")
				|| market.name.equals("SaltLakeCity") //
				|| market.name.equals("LosAngeles")
				|| market.name.equals("SanFrancisco")
				|| market.name.equals("SanAntonio")) {
			executionData.setMaxCapacity(3000);
			executionData.setCapacityIncrement((executionData.getMaxCapacity() - executionData.getMinCapacity())
							/ (executionData.getNumberDiscreteCapacityPoints() - 1));
			executionData.setMaxCapacity(executionData.getMinCapacity()
					+ (executionData.getNumberDiscreteCapacityPoints() - 1)
					* (executionData.getMaxCapacity() - executionData.getMinCapacity())
					/ (executionData.getNumberDiscreteCapacityPoints() - 1));
		}

		System.out.println("Parameters for market " + market.name);
		System.out.println(String.format("%d Firms: Firm 1 type %d and capacity %f", market.NUM_FIRMS,
										market.TYPE[0], market.CAPACITY[0]));

		// debug with only one state, no expanded states (faster to evaluate,
		// convergence of state 0 not affected by expansion anyway)
		boolean debug = false;
		if (debug || market.NUM_FIRMS >= 5) {
			// no heterogeneity if 5 firms or more
			for (int i = 0; i < market.NUM_FIRMS; i++) {
				market.TYPE[i] = 0;
				market.ERATE[i] = primitives.ERATE_INCUMBENT1;
				market.MARGINAL_COST[i] = primitives.MARGINAL_COST_INCUMBENT1;
			}
			primitives.ERATE_ENTRANT = primitives.ERATE_INCUMBENT1;
		}

		if (scenario == primitives.SCHEME_BASELINE) {
			executionData.setSimulationDescription("Baseline");
			// simulate baseline
			System.out.println("\tMechanism: Baseline");
			simulationInterpolation simBaseline = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simBaseline.getResults();
		}

		executionData.setCarbonTax(carbonTax);
		System.out.println("Evaluating auction with carbon price of " + carbonTax);

		/**
		 * AUCTIONING / CARBON TAX
		 */
		if (scenario == primitives.SCHEME_AUCTION) {
			executionData.setScheme(primitives.SCHEME_AUCTION);
			executionData.setSimulationDescription("Auctioning");
			executionData.setMarketwideFreePermits(0);
			System.out.println("\tMechanism: Permits Auctioned");
			simulationInterpolation simAuctionPermits_diff = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simAuctionPermits_diff.getResults();
		}

		/**
		 * GRANDFATHERING
		 */
		if (scenario == primitives.SCHEME_GRANDFATHERING) {
			double freePermitsShare = 0.425;
			System.out.println("\tMechanism: " + (100 * freePermitsShare)
					+ " Percent of Permits Grandfathered");
			double marketwideFreePermits = 0.0;
			for (int i = 0; i < market.NUM_FIRMS; i++) {
				marketwideFreePermits += freePermitsShare * market.CAPACITY[i];
			}
			executionData.setScheme(primitives.SCHEME_GRANDFATHERING);
			executionData.setSimulationDescription("Grandfather");
			executionData.setGrandfatheringRate(freePermitsShare);
			executionData.setMarketwideFreePermits(marketwideFreePermits);
			if (market.NUM_FIRMS < 5) {
				for (int i = 0; i < market.NUM_FIRMS; i++) {
					if (executionData.getMarket().TYPE[i] != 0) {
						executionData.getMarket().TYPE[i] = i + 1;
					}
				}
			} else {
				double totalCap = 0.0;
				for (int i = 0; i < market.NUM_FIRMS; i++) {
					executionData.getMarket().TYPE[i] = 1;
					totalCap += executionData.getMarket().CAPACITY[i];
				}
				for (int i = 0; i < market.NUM_FIRMS; i++) {
					executionData.getMarket().CAPACITY_GRANDFATHER[i] = totalCap
							/ (1.0 * market.NUM_FIRMS);
				}
			}
			System.out.println("\tMechanism: Grandfathering " + 100.0 * freePermitsShare + " percent of permits");
			simulationInterpolation simGrandfatherPermits_diff = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simGrandfatherPermits_diff.getResults();
		}

		/**
		 * OUTPUT UPDATING
		 */
		if (scenario == primitives.SCHEME_OUTPUT_BASED) {
			System.out.println("\tMechanism: Output Updating");
			executionData.setSimulationDescription("Output");
			executionData.setScheme(primitives.SCHEME_OUTPUT_BASED);
			simulationInterpolation simQuantityPermits_diff = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simQuantityPermits_diff.getResults();
		}

		/**
		 * EMISSIONS UPDATING
		 */
		if (scenario == primitives.SCHEME_EMISSIONS_BASED) {
			System.out.println("\tMechanism: Emissions Updating");
			executionData.setSimulationDescription("Emissions");
			executionData.setScheme(primitives.SCHEME_EMISSIONS_BASED);
			simulationInterpolation simEmissionsPermits_diff = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simEmissionsPermits_diff.getResults();
		}

		/**
		 * AUCTIONING WITH BORDER TAX ADJUSTMENT
		 */
		if (scenario == primitives.SCHEME_BTA) {
			executionData.setScheme(primitives.SCHEME_BTA);
			executionData.setSimulationDescription("BTA");
			executionData.setMarketwideFreePermits(0);
			System.out.println("\tMechanism: Permits Auctioned");
			simulationInterpolation simBTAPermits_diff = new simulationInterpolation(null, executionData, solveMPNE(executionData));
			simBTAPermits_diff.getResults();
		}

		System.exit(0);

	}

	private static stateSpace solveMPNE(ExecutionInformation executionData) {
		String fn = executionData.getMarket().name;
		fn += executionData.getSimulationDescription();
		fn += (int) executionData.getCarbonTax();

		System.out.println("Setting up state space for " + fn);
		stateSpace omega = new stateSpace(executionData);
		iteratedSolver isolve = new iteratedSolver(omega);
		System.out.println("Executing solver.");
		isolve.execute();

		return omega;
	}

	private static double[] getCosts(int r) {
		String csvFile = "data/estimation/dynamicParams"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] costs = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				String[] read = line.split(cvsSplitBy);
				if (String.valueOf(read[0]).contentEquals("dtwostep")) {
					costs = new double[read.length - 1];
					for (int i = 0; i < read.length - 1; i++) {
						costs[i] = Double.valueOf(read[i  + 1]);
					}
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return costs;

	}

	private static double[] readMgParam(int r) {

		String csvFile = "data/estimation/mgcost"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] mgcost = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				mgcost = new double[read.length + 1];
				for (int i = 0; i < read.length; i++) {
					mgcost[i + 1] = Double.valueOf(read[i]);					
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mgcost;
		
	}
}
