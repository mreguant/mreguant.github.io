/**
 * SimulationOptions.java
 * 
 * Stores the main aspects of the counterfactuals: market,
 * carbon price and mechanism. It also stores the bootstrap draw
 * if relevant, and sets costs to be updated for a given draw.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.main;

import simulation.solve.regionalMarket;

public class SimulationOptions {

	private regionalMarket market;
	private double carbonTax;
	private int scenario;
	private int draw = 0;
	private boolean updateCosts = true;

	public SimulationOptions(regionalMarket market, double carbonTax, int scenario) {
		this.market = market;
		this.carbonTax = carbonTax;
		this.scenario = scenario;
	}

	public SimulationOptions(regionalMarket market, double carbonTax, int scenario, int draw) {
		this.market = market;
		this.carbonTax = carbonTax;
		this.scenario = scenario;
		this.draw = draw;
		this.updateCosts = true;
	}

	/**
	 * @return the market
	 */
	public regionalMarket getMarket() {
		return market;
	}

	/**
	 * @return the carbonTax
	 */
	public double getCarbonTax() {
		return carbonTax;
	}

	/**
	 * @return the scenario
	 */
	public int getScenario() {
		return scenario;
	}
	
	/**
	 * @return the draw
	 */	
	public int getDraw() {
		return draw;
	}

	/**
	 * @return the boolean for bootstrap
	 */	
	public boolean getUpdateCosts() {
		return updateCosts;
	}

}
