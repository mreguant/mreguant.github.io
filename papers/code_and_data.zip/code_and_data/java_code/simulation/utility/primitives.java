/**
 * primitives.java
 *
 * Parameters to run the counterfactuals.
 *
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */
package simulation.utility;

public class primitives {

    // PARAMETERS FROM ESTIMATION
    // fixed costs
    public static boolean BOUND_FIXED_COST_ADJUSTMENT_POSITIVE = false;
    public static boolean ADJUSTMENT_NATURE = true;
    public static boolean ADJUSTMENT_NATURE_CAP = true;
    public static double ADJUSTMENT_PROBABILITY_CAP = 1.0;
    public static double ADJUSTMENT_FACTOR = 1.0;
    public static double INFLATOR = 1E5;
    public static double DEPRECIATION = 0.0;
    // discount factors
    public static double DISCOUNT_FACTOR = 0.90;
    public static double DISCOUNT_FACTOR_SOCIAL = 0.97;
    // fixed costs
    public static double ADJUSTMENT_MU = 32256.18;
    public static double ADJUSTMENT_SIGMA = 14748.44;
    public static double SCRAP_MU = -146648.78;
    public static double SCRAP_SIGMA = 82253.41;
    public static double ENTRY_MU = 58578.35;
    public static double ENTRY_SIGMA = 23300.44;
    // investment costs
    public static double MIN_ADJUSTMENT = 20.0;
    public static double INVESTMENT_MARGINAL_COST = 180.67;
    public static double INVESTMENT_MARGINAL_COST2 = 0.0;
    public static double DIVESTMENT_MARGINAL_COST = 180.0;
    public static double DIVESTMENT_MARGINAL_COST2 = 0.0;
    public static boolean USE_DIVESTMENT = true;
    // production costs
    public static double CAPACITY_COST = 803.65;
    public static double CAPACITY_COST_BINDING_LEVEL = 1.888;
    public static double MARGINAL_COST_ENTRANT = 46.99;
    public static double MARGINAL_COST_INCUMBENT1 = 46.99;
    public static double MARGINAL_COST_INCUMBENT2 = 46.99;

    // ENVIRONMENTAL PARAMETERS
    public static double ERATE_ENTRANT = 0.81;
    public static double ERATE_INCUMBENT1 = 0.93;
    public static double ERATE_INCUMBENT2 = 1.16;
    public static double IMPORT_ERATE = 0.97;
    /**
     * Global constants to identify which scheme we are using
     */
    public static int SCHEME_BASELINE = 23232;
    public static int SCHEME_AUCTION = 14848;
    public static int SCHEME_GRANDFATHERING = 21294;
    public static int SCHEME_OUTPUT_BASED = 31284;
    public static int SCHEME_EMISSIONS_BASED = 49594;
    public static int SCHEME_BTA = 59595;
    // APPROXIMATION PARAMETERS
    /**
     * Number of points to use in approximation to value function (default is 5)
     */
    public static int NUM_DISCRETE_CAPACITY_POINTS = 5;
    public static double CONVERGENCE_CRITERION = 1E-5;
    public static double CONVERGENCE_CRITERION_PCT = 1E-5;

}
