/**
 * simultationInterpolation.java
 * 
 * Simulates forward market outcomes. It requires solving for the
 * model first using the functions in the solve folder.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package simulation.simulate;

import JSci.maths.statistics.NormalDistribution;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;

import simulation.solve.*;
import simulation.utility.*;
import utility.JTextAreaAutoscroll;
import utility.pmUtility;


public class simulationInterpolation {

    double PRICE_NOFIRM;
    // SIMULATION PARAMETERS
    int NUM_SIMULATIONS = 1000;
    int SIMULATION_LENGTH = 30;
    boolean DISPLAY_PROGRESS = false;
    JTextArea jt = new JTextAreaAutoscroll();
    JFrame f = new JFrame("Simulation");
    java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
    private int simulationLength = NUM_SIMULATIONS;
    private int timeMax = SIMULATION_LENGTH;
    private NormalDistribution standardNormal = new NormalDistribution(0, 1);
    // policy coefficients
    private coefficientValues coefInvestActive;
    private coefficientValues coefAdjustmentActive;
    private coefficientValues coefInvestEntrant;
    private coefficientValues coefAdjustmentEntrant;
    private coefficientValues coefDoingNothing;
    private coefficientValues coefEntry;
    private coefficientValues coefExpectedMax;
    // market outcomes coefficients
    private coefficientValues coefProfit;
    private coefficientValues coefCarbon;
    private coefficientValues coefQuantity;
    private coefficientValues coefPrice;
    private coefficientValues coefEmission;
    private SimulationResults results;
    private stateSpace s;
    private ExecutionInformation executionData;

    /** Creates a new instance of simulation */
    public simulationInterpolation(JTextArea jtCommon, ExecutionInformation executionData, stateSpace passedStateSpace) throws IOException {
        this.executionData = executionData;
        this.jt = jtCommon;
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);


        PRICE_NOFIRM = executionData.getPriceNoActiveDomesticFirms();

        String specificationName = executionData.getMarket().name;
        specificationName += "_" + executionData.getSimulationDescription();
        specificationName += "_" + executionData.getCarbonTax();

        String sp = "";
        f.setTitle("Simulation " + sp);

        int MAXIMUM_NUMBER_FIRMS = executionData.getMarket().NUM_FIRMS;
        int MIN_CAPACITY = executionData.getMinCapacity();
        int CAPACITY_INC = executionData.getCapacityIncrement();
        double IMPORT_ERATE = executionData.getImportEmissionsRate();

        ArrayList<stateSpacePoint> list = new ArrayList<stateSpacePoint>();

        s = new stateSpace(executionData);
        if (passedStateSpace == null) {
            try {
                ObjectInputStream in = new ObjectInputStream(new FileInputStream("data/v" + MAXIMUM_NUMBER_FIRMS + specificationName + ".dat"));
                in.readDouble(); // max_capacity = in.readDouble();
                in.readDouble(); // capacity_increment = in.readDouble();
                int sizeSpace = in.readInt();
                for (int i = 0; i < sizeSpace; i++) {
                    list.add((stateSpacePoint) in.readObject());
                }
                int m = in.readInt();
                s.setupSpace(list, m);
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(0);
            }
        } else {
            list = passedStateSpace.getList();
            s.setupSpace(list, passedStateSpace.getNumFirms());
        }

        Jama.Matrix w;
        w = new Jama.Matrix(MAXIMUM_NUMBER_FIRMS, 2, 0);
        for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
            w.set(i, 0, executionData.getMarket().CAPACITY[i]);
            w.set(i, 1, executionData.getMarket().TYPE[i]);
            if (executionData.getMarket().CAPACITY[i] == 0) {
                w.set(i, 1, 0);
            }
        }
        
        determineCoefficients(list, s);
        
        ProgressMonitor mon = new ProgressMonitor(f, "Simulating Industry Paths", "0 / " + simulationLength, 0, simulationLength - 1);
        Jama.Matrix simProfit = new Jama.Matrix(simulationLength, MAXIMUM_NUMBER_FIRMS, 0);
        Random entryShock = new Random(8682031);
        Random exitShock = new Random(3087862);
        Random investShock = new Random(6745912);

        double averageSizeOverall = 0.0;
        double marketSizeOverall = 0.0;
        double quantityProduced = 0.0;
        double averagePrice = 0.0;
        double averagePriceEmissions = 0.0;
        double averageEmissions = 0.0;
        double simCS = 0.0;
        double simCarbon = 0.0;
        double simEmissions = 0.0;
        double simLeakage = 0.0;
        double nofirms = 0.0;
        double onefirm = 0.0;
        double twofirms = 0.0;
        double threefirms = 0.0;
        double fourfirms = 0.0;
        double fivefirms = 0.0;
        double sixfirms = 0.0;
        double averagefirms = 0.0;

        // keeps time series of firms in market
        String outFilename = "data/" + executionData.getMarket().name + "/firmdist" + MAXIMUM_NUMBER_FIRMS + specificationName + ".csv";
        File directoryMaker = new File("data/" + executionData.getMarket().name);
        directoryMaker.mkdirs();
        System.out.println("Trying to access " + outFilename);
        BufferedWriter out = new BufferedWriter(new FileWriter(outFilename));

        // keeps only simulation level stats
        String resultsOutFilename = "data/" + executionData.getMarket().name + "/" + specificationName + ".csv";
        BufferedWriter resultsOut = new BufferedWriter(new FileWriter(resultsOutFilename));

        String panelResultsOutFilename = "data/" + executionData.getMarket().name + "/" + specificationName + "_panel.csv";
        BufferedWriter panelResultsOut = new BufferedWriter(new FileWriter(panelResultsOutFilename));

        panelResultsOut.append("simulation,time,CS,domesticQuantity,imports,totalQuantity,price,emissions,leakage,importProfit,carbonRevenue,profit,numFirms\n");
        resultsOut.append("simulations,averageSize,marketSize,profit,import_profit,runCS,runCarbon,runEmissions,runNoFirms,runOneFirm,runTwoFirms,runThreeFirms,runFourFirms,runFiveFirms,runSixFirms,averagePriceRun,averagePriceEmissions,averageRate,runLeakage\n");
        for (int simulations = 0; simulations < simulationLength; simulations++) {
            if (DISPLAY_PROGRESS) {
                mon.setProgress(simulations);
                mon.setNote((simulations + 1) + " / " + simulationLength);
            }
            // simulate forward 25 periods
            Jama.Matrix ws = w.copy();
            double[] runProfit = new double[MAXIMUM_NUMBER_FIRMS];
            double runCS = 0.0;
            double runCarbon = 0.0;
            double runEmissions = 0.0;
            double runLeakage = 0.0;
            double runEmissionsRate = 0.0;
            for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                runProfit[i] = 0.0;
            }
            double runImportProfit = 0.0;
            double runOneFirm = 0.0;
            double runTwoFirms = 0.0;
            double runNoFirms = 0.0;
            double runThreeFirms = 0.0;
            double runFourFirms = 0.0;
            double runFiveFirms = 0.0;
            double runSixFirms = 0.0;
            double runAverageFirms = 0.0;
            double runProductionPositive = 0.0;
            double averageSize = 0.0;
            double marketSize = 0.0;
            double averagePriceRun = 0.0;
            double averagePriceEmissionsRun = 0.0;
            int N = executionData.getNumberDiscreteCapacityPoints();

            for (int time = 0; time < timeMax; time++) {
                boolean[] exit = new boolean[MAXIMUM_NUMBER_FIRMS];
                double[] investment = new double[MAXIMUM_NUMBER_FIRMS];
                double[] profit = new double[MAXIMUM_NUMBER_FIRMS];
                boolean[] entry = new boolean[MAXIMUM_NUMBER_FIRMS];
                double consumerCS = 0.0;
                double thisQuantity = 0.0;
                double thisImports = 0.0;
                double thisTotalQuantity = 0.0;
                double thisPrice = 0.0;
                double thisEmissions = 0.0;
                double thisLeakage = 0.0;
                double thisImportProfit = 0.0;
                double carbonRevenue = 0;
                double thisProfit = 0.0;
                double thisNumFirms = 0.0;
                boolean imputeData = true;

                for (int j = 0; j < MAXIMUM_NUMBER_FIRMS; j++) {
                    Jama.Matrix swap = ws.copy();
                    swap.set(j, 0, ws.get(0, 0));
                    swap.set(0, 0, ws.get(j, 0));
                    swap.set(j, 1, ws.get(0, 1));
                    swap.set(0, 1, ws.get(j, 1));
                    int numActive = 0;
                    int ownActive = 0;
                    if (swap.get(0, 0) > 0) {
                        ownActive = 1;
                    }
                    for (int k = 0; k < MAXIMUM_NUMBER_FIRMS; k++) {
                        if (swap.get(k, 0) > 0) {
                            numActive += 1;
                        }
                    }
                    swap = s.sortOnFirmId(swap);

                    Jama.Matrix wsActive = new Jama.Matrix(numActive, 1);
                    int count = 0;
                    for (int k = 0; k < MAXIMUM_NUMBER_FIRMS; k++) {
                        if (swap.get(k, 0) > 0) {
                            wsActive.set(count, 0, swap.get(k, 0));
                            count += 1;
                        }
                    }

                    int offset = s.getExpandedIndex(swap.getMatrix(0, MAXIMUM_NUMBER_FIRMS - 1, 1, 1));
                    int indexC = numActive - 1;
                    // Compute common aggregate measures
                        /*
                     * Save results when ownfirm is active if numActive > 0
                     * or at j==0 if not firm is active and market is coastal
                     */
                    if (imputeData) {
                        thisNumFirms = numActive;
                        if (numActive > 0) { // need to fix quantity computation
                            if (ownActive == 1) {
                                thisQuantity = Math.max(Interpolate.getValue(wsActive, coefQuantity.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                        numActive, N, MIN_CAPACITY, CAPACITY_INC), 0);
                                thisEmissions = Math.max(Interpolate.getValue(wsActive, coefEmission.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                        numActive, N, MIN_CAPACITY, CAPACITY_INC), 0);
                                thisPrice = Math.max(Interpolate.getValue(wsActive, coefPrice.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                        numActive, N, MIN_CAPACITY, CAPACITY_INC), 0);
                                thisTotalQuantity = getTotalQ(thisPrice);
                                thisImports = getImports(thisPrice);
                                thisLeakage = IMPORT_ERATE * thisImports;
                                thisImportProfit = thisPrice * thisImports - getImportCosts(thisImports);
                                consumerCS = getCS(thisTotalQuantity, thisPrice);
                                carbonRevenue = Interpolate.getValue(wsActive, coefCarbon.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                        numActive, N, MIN_CAPACITY, CAPACITY_INC);
                                quantityProduced += thisQuantity / (timeMax * simulationLength);
                                averageEmissions += thisEmissions / (timeMax * simulationLength);
                                averagePriceRun += thisPrice / timeMax;
                                averagePriceEmissionsRun += executionData.getCarbonTax() * 1.0 / timeMax;
                                imputeData = false;
                            }
                        } else if (executionData.getImportIntercept() != 0) {
                            /**
                             * This is where things are going awry.  thisPrice
                             * is not accurately reflecting the price when there
                             * are only imports.
                             */
                            thisPrice = PRICE_NOFIRM;
                            thisTotalQuantity = getTotalQ(thisPrice);
                            thisImports = thisTotalQuantity;
                            thisLeakage = IMPORT_ERATE * thisImports;
                            thisImportProfit = thisPrice * thisImports - getImportCosts(thisImports);
                            consumerCS = getCS(thisTotalQuantity, thisPrice);
                            averagePriceRun += thisPrice / timeMax;
                            averagePriceEmissionsRun += executionData.getCarbonTax() * 1.0 / timeMax;
                            imputeData = false;
                        }
                    }

                    /**
                     * Get the value of doing nothing from the interpolater.
                     */
                    double valueDoingNothing = 0;
                    double expectedMaxOptions = 0;

                    if (ws.get(j, 0) > 0) {
                        indexC = numActive - 1;
                        valueDoingNothing = Interpolate.getValue(wsActive, coefDoingNothing.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                        expectedMaxOptions += Interpolate.getValue(wsActive, coefExpectedMax.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                        indexC = numActive - 1;
                        profit[j] = Interpolate.getValue(wsActive, coefProfit.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                    } else {
                        profit[j] = 0.0;
                    }
                    

                    double scrapDraw = primitives.SCRAP_MU + primitives.SCRAP_SIGMA * standardNormal.inverse(exitShock.nextDouble());

                    /**
                     * We are storing the value of optimal investment,
                     * doing nothing, and zero (exit).  Draw the shocks from the unconditional
                     * distributions, and then compare the best of the three.
                     */
                    double adjustmentDraw = primitives.ADJUSTMENT_MU + primitives.ADJUSTMENT_SIGMA * standardNormal.inverse(investShock.nextDouble());
                    double valueOptimalInvestment = -adjustmentDraw;

                    if (ownActive == 1) {
                        /**
                         * Current firm is incumbent.
                         */
                        indexC = numActive - 1;
                        valueOptimalInvestment += Interpolate.getValue(wsActive, coefAdjustmentActive.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                        investment[j] = Math.max(Math.min(Interpolate.getValue(wsActive, coefInvestActive.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC), executionData.getMaxCapacity()-ws.get(j, 0)), executionData.getMinCapacity()-ws.get(j, 0));
                    } else if (ownActive == 0 && numActive > 0) {
                        /**
                         * Current firm is potential entrant with incumbent competitors.
                         */
                        indexC = numActive;
                        valueOptimalInvestment += Interpolate.getValue(wsActive, coefAdjustmentEntrant.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                        investment[j] = Interpolate.getValue(wsActive, coefInvestEntrant.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                numActive, N, MIN_CAPACITY, CAPACITY_INC);
                    } else {
                        /**
                         * Current firm is potential entrant with no incumbent competitors.
                         */
                        indexC = numActive;
                        valueOptimalInvestment += coefAdjustmentEntrant.getCoefficients(offset).get(0, indexC);
                        investment[j] = coefInvestEntrant.getCoefficients(offset).get(0, indexC);
                    }

                    /**
                     * Case of incumbent firms first.
                     */
                    if (ws.get(j, 0) > 0) {
                        if (scrapDraw > expectedMaxOptions) {
                            /**
                             * Firm exits.  Give the firm scrap value and indicate to the
                             * program that the firm is gone.
                             */
                            exit[j] = true;
                            profit[j] += scrapDraw;
                        } else {
                            exit[j] = false;
                            if (valueOptimalInvestment > valueDoingNothing) {
                                /**
                                 * Firm makes optimal positive investment.
                                 */
                                profit[j] -= adjustmentDraw;
                            } else {
                                /**
                                 * Firm does nothing, stays pat.  Drop investment to zero.
                                 */
                                investment[j] = 0;
                            }
                        }
                    }
                    /**
                     * Now potential entrants.
                     */
                    if (ws.get(j, 0) == 0) {
                        double entryDraw = primitives.ENTRY_MU + primitives.ENTRY_SIGMA * standardNormal.inverse(entryShock.nextDouble());
                        double entryCutoff = 0;
                        if (numActive > 0) {
                            entryCutoff = Interpolate.getValue(wsActive, coefEntry.getCoefficients(offset).getMatrix(0, (int) java.lang.Math.pow(N + 2, numActive) - 1, indexC, indexC),
                                    numActive, N, MIN_CAPACITY, CAPACITY_INC);
                        } else {
                            entryCutoff = coefEntry.getCoefficients(offset).get(0, indexC);
                        }

                        if (entryDraw + adjustmentDraw < entryCutoff) {
                            entry[j] = true;
                            profit[j] -= adjustmentDraw;
                            profit[j] -= entryDraw;
                        } else {
                            entry[j] = false;
                            investment[j] = 0;
                        }
                    }
                    thisProfit += profit[j];
                }

                int active = 0;
                double sumSize = 0;
                for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                    if (ws.get(i, 0) > 0) {
                        active++;
                        sumSize += ws.get(i, 0);
                    }
                }
                averageSize += sumSize * (1.0 / Math.max(1, active * timeMax));
                marketSize += sumSize * (1.0 / timeMax);
                if (active > 0 && thisQuantity > 1) {
                    runEmissionsRate += (thisEmissions / thisQuantity);
                    runProductionPositive++;
                }
                if (active == 0) {
                    runNoFirms++;
                }
                if (active == 1) {
                    runOneFirm++;
                }
                if (active == 2) {
                    runTwoFirms++;
                }
                if (MAXIMUM_NUMBER_FIRMS > 2) {
                    if (active == 3) {
                        runThreeFirms++;
                    }
                }
                if (MAXIMUM_NUMBER_FIRMS > 3) {
                    if (active == 4) {
                        runFourFirms++;
                    }
                }
                if (MAXIMUM_NUMBER_FIRMS > 4) {
                    if (active == 5) {
                        runFiveFirms++;
                    }
                }
                if (MAXIMUM_NUMBER_FIRMS > 5) {
                    if (active == 6) {
                        runSixFirms++;
                    }
                }
                runAverageFirms += 1.0 * active;

                out.append(simulations + "," + time + "," + active + ",");
                for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                    out.append(ws.get(i, 0) + ",");
                }
                for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                    out.append(ws.get(i, 1) + ",");
                }
                out.append("\n");

                // update the state now that i have a vector describing the payoffs and policies of all the firms
                double[] outcomes = new double[MAXIMUM_NUMBER_FIRMS];
                double[] types = new double[MAXIMUM_NUMBER_FIRMS];
                for (int j = 0; j < MAXIMUM_NUMBER_FIRMS; j++) {
                    if ((ws.get(j, 0) > 0 || entry[j]) && !exit[j]) {
                        outcomes[j] = ws.get(j, 0) + investment[j];
                    } else {
                        outcomes[j] = 0;
                    }
                    if (exit[j]) {
                        types[j] = 0;
                    } else {
                        types[j] = ws.get(j, 1);
                    }
                    if (investment[j] > 0 && (ws.get(j, 0) > 0 || entry[j])) {
                        profit[j] -= investment[j] * primitives.INVESTMENT_MARGINAL_COST;
                        profit[j] -= Math.pow(investment[j], 2) * primitives.INVESTMENT_MARGINAL_COST2;
                    }
                }
                Jama.Matrix outcomesMat = new Jama.Matrix(outcomes, MAXIMUM_NUMBER_FIRMS);
                Jama.Matrix typesMat = new Jama.Matrix(types, MAXIMUM_NUMBER_FIRMS);
                ws.setMatrix(0, MAXIMUM_NUMBER_FIRMS - 1, 0, 0, outcomesMat);
                ws.setMatrix(0, MAXIMUM_NUMBER_FIRMS - 1, 1, 1, typesMat);
                for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                    runProfit[i] += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * profit[i];
                }
                runCS += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * consumerCS;
                runCarbon += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * carbonRevenue;
                runEmissions += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * thisEmissions;
                runLeakage += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * thisLeakage;
                runImportProfit += Math.pow(primitives.DISCOUNT_FACTOR_SOCIAL, time) * thisImportProfit;

                panelResultsOut.append(simulations + "," + time + "," + consumerCS + "," + thisQuantity + "," + thisImports + "," + thisTotalQuantity + "," + thisPrice + "," + thisEmissions + "," + thisLeakage
                        + "," + thisImportProfit + "," + carbonRevenue + "," + thisProfit + "," + thisNumFirms + "\n");
            }

            double profit = 0.0;
            for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
                simProfit.set(simulations, i, runProfit[i]);
                profit += runProfit[i];
            }
            runEmissionsRate = runEmissionsRate / runProductionPositive;

            averageSizeOverall += averageSize / simulationLength;
            marketSizeOverall += marketSize / simulationLength;
            simCS += runCS / simulationLength;
            simCarbon += runCarbon / simulationLength;
            simEmissions += runEmissions / simulationLength;
            simLeakage += runLeakage / simulationLength;
            nofirms += runNoFirms / simulationLength;
            onefirm += runOneFirm / simulationLength;
            twofirms += runTwoFirms / simulationLength;
            threefirms += runThreeFirms / simulationLength;
            fourfirms += runFourFirms / simulationLength;
            fivefirms += runFiveFirms / simulationLength;
            sixfirms += runSixFirms / simulationLength;
            averagefirms += runAverageFirms / (simulationLength * timeMax);
            averagePrice += averagePriceRun / simulationLength;
            averagePriceEmissions += averagePriceEmissionsRun / simulationLength;

            // store results
            resultsOut.append(simulations + "," + averageSize + "," + marketSize + "," + profit + "," + runImportProfit + "," + runCS + "," + runCarbon + "," + runEmissions + "," + runNoFirms
                    + "," + runOneFirm + "," + runTwoFirms + "," + runThreeFirms + "," + runFourFirms + "," + runFiveFirms + "," + runSixFirms + "," + averagePriceRun
                    + "," + averagePriceEmissionsRun + "," + runEmissionsRate + "," + runLeakage + "\n");
        }
        averageSizeOverall = averageSizeOverall * (timeMax / (timeMax - nofirms));
        if (executionData.getImportIntercept() == 0) {
            averagePrice = averagePrice * (timeMax / (timeMax - nofirms));
        }
        averagePriceEmissions = averagePriceEmissions * (timeMax / (timeMax - nofirms));
        averagePriceEmissions = executionData.getCarbonTax();

        Jama.Matrix piVec = new Jama.Matrix(MAXIMUM_NUMBER_FIRMS, 1);
        double piTotal = 0;
        for (int i = 0; i < MAXIMUM_NUMBER_FIRMS; i++) {
            piVec.set(i, 0, pmUtility.mean(simProfit, i));
            piTotal += piVec.get(i, 0);
        }

        out.close();
        resultsOut.close();
        panelResultsOut.close();

        simulationResultsCSVContainer outContainer = new simulationResultsCSVContainer(out.toString(), outFilename);
        simulationResultsCSVContainer resultsOutContainer = new simulationResultsCSVContainer(resultsOut.toString(), resultsOutFilename);
        simulationResultsCSVContainer panelResultsOutContainer = new simulationResultsCSVContainer(panelResultsOut.toString(), panelResultsOutFilename);

        results = new SimulationResults(outContainer, resultsOutContainer, panelResultsOutContainer, executionData, piTotal / MAXIMUM_NUMBER_FIRMS, piVec, averageSizeOverall, marketSizeOverall, quantityProduced, averagePrice, averagePriceEmissions, averageEmissions,
                simCS, simCarbon, simEmissions, simLeakage, nofirms, onefirm, twofirms, threefirms, fourfirms, fivefirms, sixfirms, averagefirms, w);
    }

    public SimulationResults getResults() {
        return results;
    }

    private void determineCoefficients(ArrayList<stateSpacePoint> list, stateSpace s) {
        // compute coefficients for each of the policies
        Jama.Matrix Invest = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Adjustment = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Entry = new Jama.Matrix(list.size(), 1);
        Jama.Matrix ValueDoingNothing = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Profit = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Welfare = new Jama.Matrix(list.size(), 1);
        Jama.Matrix CarbonRevenue = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Quantity = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Price = new Jama.Matrix(list.size(), 1);
        Jama.Matrix PriceE = new Jama.Matrix(list.size(), 1);
        Jama.Matrix Emission = new Jama.Matrix(list.size(), 1);
        Jama.Matrix ExpectedMaxOptions = new Jama.Matrix(list.size(), 1);

        // put everything in a matrix and run routine similar to update coefficients for all of them
        for (int i = 0; i < list.size(); i++) {
            stateSpacePoint point = list.get(i);
            Invest.set(i, 0, point.getPolicy());
            Adjustment.set(i, 0, point.getValueOptimalInvestment());
            Entry.set(i, 0, point.getEntryValue());
            ValueDoingNothing.set(i, 0, point.getValueDoingNothing());
            Profit.set(i, 0, point.getProfit());
            Welfare.set(i, 0, point.getConsumerWelfare());
            CarbonRevenue.set(i, 0, point.getCarbonRevenue());
            Quantity.set(i, 0, point.getMarketQ());
            Price.set(i, 0, point.getPrice());
            PriceE.set(i, 0, point.getPriceEmissions());
            Emission.set(i, 0, point.getEmissions());
            ExpectedMaxOptions.set(i, 0, point.getExpectedMaxOptions());
        }

        coefInvestActive = new coefficientValues(s, true);
        coefInvestActive.updateCoefficient(Invest);
        coefInvestEntrant = new coefficientValues(s, false);
        coefInvestEntrant.updateCoefficient(Invest);
        coefAdjustmentActive = new coefficientValues(s, true);
        coefAdjustmentActive.updateCoefficient(Adjustment);
        coefAdjustmentEntrant = new coefficientValues(s, false);
        coefAdjustmentEntrant.updateCoefficient(Adjustment);
        coefEntry = new coefficientValues(s, false);
        coefEntry.updateCoefficient(Entry);
        coefDoingNothing = new coefficientValues(s, true);
        coefDoingNothing.updateCoefficient(ValueDoingNothing);
        coefExpectedMax = new coefficientValues(s, true);
        coefExpectedMax.updateCoefficient(ExpectedMaxOptions);

        coefProfit = new coefficientValues(s, true);
        coefProfit.updateCoefficient(Profit);
        coefCarbon = new coefficientValues(s, true);
        coefCarbon.updateCoefficient(CarbonRevenue);
        coefQuantity = new coefficientValues(s, true);
        coefQuantity.updateCoefficient(Quantity);
        coefPrice = new coefficientValues(s, true);
        coefPrice.updateCoefficient(Price);
        coefEmission = new coefficientValues(s, true);
        coefEmission.updateCoefficient(Emission);

    }

    private double getTotalQ(double thisPrice) {
        if (thisPrice == 0) {
            return 0;
        } else {
            return Math.exp(executionData.getAggregateIntercept() - executionData.getAggregateElasticity() * Math.log(thisPrice));
        }
    }

    private double getImportCosts(double thisImports) {
        if (thisImports == 0) {
            return 0;
        } else {
            double A = Math.log(executionData.getImportIntercept()) / executionData.getImportElasticity();
            double B = 1.0 / executionData.getImportElasticity();
            return Math.exp(A) * Math.pow(thisImports, B + 1) / (B + 1);
        }
    }

    private double getCS(double totalQuantity, double thisPrice) {
        if (totalQuantity == 0 || thisPrice == 0) {
            return 0;
        } else if (executionData.getAggregateElasticity() == 1) {
        	double A = executionData.getAggregateIntercept();
        	return Math.exp(A) * Math.log(totalQuantity) - (totalQuantity * thisPrice); 
        } else {
        	double A = executionData.getAggregateIntercept() / executionData.getAggregateElasticity();
        	double B = 1.0 / executionData.getAggregateElasticity(); // AGGREGATE_ELASTICITY;
        	return Math.exp(A) * Math.pow(totalQuantity, -B + 1) / (-B + 1) - (totalQuantity * thisPrice); 	
        }
    }

    private double getImports(double thisPrice) {
        if (thisPrice == 0) {
            return 0;
        } else {
            double imports = 0.0;
            if (executionData.getScheme()==primitives.SCHEME_BTA) {
            	imports = executionData.getImportIntercept()*Math.pow(Math.max(thisPrice - executionData.getCarbonTax()*primitives.IMPORT_ERATE, 0.0), executionData.getImportElasticity());
            } else {
            	imports = executionData.getImportIntercept()*Math.pow(thisPrice, executionData.getImportElasticity());
            }
            return imports;
        }
    }
}
