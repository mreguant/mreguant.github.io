/**
 * simulateWTask.java
 *
 * This function performs a forward simulation for a given 
 * market and combination of starting capacities. It simulates
 * forward for "simulationHorizon" years for "numSimWTak" draws.
 * It considers different deviations to create the moments 
 * (change investment, change entry/exit decision, etc.).
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.simulateW;

import estimation.main.EstimationConstants;
import estimation.ssrulesLikelihood.investmentParametersContainer;
import estimation.utility.demandCurve;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Callable;

import JSci.maths.statistics.NormalDistribution;


public class SimulateWTask implements Callable<ArrayList<Jama.Matrix>> {

	private int numSimWTask;
	private int numParams;
	private int year = 2000;
	private int market = 11;	
	private int sNumFirms = 2;
	
	private double[] productionParameters;
	private investmentParametersContainer policyParameters;
	private int simulationHorizon;
	private boolean divestUponExit;
	private double truncateExtremes = 6.0;
	private Random rng;
	private final double[] entryParameters;
	private final double[] exitParameters;
	private final double[] capacity;
	private final demandCurve priceData;
	private boolean savefiles;

	public SimulateWTask(long seed, int numSimWTask, int numParams,
			int simulationHorizon, boolean divestUponExit,
			demandCurve priceData, double[] productionParameters,
			investmentParametersContainer policyParameters,
			double[] exitParameters, double[] entryParameters,
			int market, int year, double[] capacity, boolean save) {
		this.numSimWTask = numSimWTask;
		this.numParams = numParams;
		this.priceData = priceData;
		this.productionParameters = productionParameters;
		this.policyParameters = policyParameters;
		this.simulationHorizon = simulationHorizon;
		this.divestUponExit = divestUponExit;
		this.entryParameters = entryParameters;
		this.exitParameters = exitParameters;
		this.year = year;
		this.market = market;
		this.capacity = capacity;
		this.savefiles = save;
		rng = new Random(seed);
	}

	@Override
	public ArrayList<Jama.Matrix> call() throws Exception {
		ArrayList<Jama.Matrix> wList = new ArrayList<Jama.Matrix>();
		
		sNumFirms = capacity.length;
		
		NormalDistribution stdNormal = new NormalDistribution();

		double[] cap = new double[sNumFirms];
		for (int cn = 0; cn < sNumFirms; cn++) {
			cap[cn] = capacity[cn];
		}
		
		// easiest to give them both dry and see what happens
		int[] technologies = new int[sNumFirms];
		for (int i = 0; i < sNumFirms; i++) {
			technologies[i] = EstimationConstants.TECH_DRY;
		}

		long simulateRNGBase = rng.nextLong();

		ProfitData profitData = new ProfitData(priceData, year, market, productionParameters, EstimationConstants.PROFIT_APPROX);
		
		BufferedWriter outBbl = null;
		if (savefiles) { 
			outBbl = new BufferedWriter(new FileWriter("data/estimation/bbl"+"_"+market+"_"+year+"_"+simulateRNGBase+".csv"));
		}
		
		for (int k = 0; k < 8; k++) {
			// want to hold the RNG draws fixed across the two policies
			rng = new Random(simulateRNGBase);
			
			if (k == 3) {
				cap[0] = 0.0;
			} else {
				cap[0] = capacity[0];
			}
			
			State baseState = new State(rng.nextLong(), priceData, market,
					productionParameters, policyParameters, exitParameters,
					entryParameters);
			baseState.setCapacities(cap, technologies);
			
			double[] W = new double[numParams + 1];
			for (int ci = 0; ci <= numParams; ci++) {
				W[ci] = 0.0;
			}
			
			// draws for the approximation of the deviations
			for (int j = 0; j < numSimWTask; j++) {

				State s = baseState.getDeepCopy();
				s.refreshRNG(rng.nextLong());
				
				double[] Win = new double[numParams + 1];
				for (int ci = 0; ci <= numParams; ci++) {
					Win[ci] = 0.0;
				}
				// System.out.println("s.getProduction()");
				for (int i = 0; i < simulationHorizon; i++) {
					
					double discount = Math.pow(EstimationConstants.DISCOUNT_FACTOR,i);
					double profit = profitData.getProfit(s.getCapacities(),s.getTech());
					
					// first moment: perturbation
					if (k == 1) {
						s.perturb(true);
					} else {
						s.perturb(false);
					}
					// second moment: exit for sure
					if (k == 2 && i == 0) {
						s.setForceExit(true);
					} else {
						s.setForceExit(false);
					}
					// third moment: enter for sure
					if (k == 3 && i == 0) {
						s.setForceEntry(true);
					} else {
						s.setForceEntry(false);
					}
					// fourth and sixth moment: invest for sure
					if ((k == 4 || k == 6) && i == 0) {
						s.setForceChange(true);
					} else {
						s.setForceChange(false);
					}
					//  fifth and seventh moment: not invest for sure
					if ((k == 5 || k == 7) && i == 0) {
						s.setForceNoChange(true);
					} else {
						s.setForceNoChange(false);
					}
					
					double c0 = s.getCapacity(0);
					double policy = s.getPolicyFirst(0);

					double probabilityExit = s.getProbabilityExit();
					double probabilityEntry = s.getProbabilityEntry();
					double probabilityDivestment = s.getProbabilityDivestment();
					double probabilityInvestment = s.getProbabilityInvestment();

					Win[0] += discount * profit / 1000.0;
					
					if (k == 0 && j < 100 && savefiles) {
						outBbl.write(market+","+year+","+j+","+i+","+c0+","+s.getNumFirms()+","+probabilityExit+","
									+probabilityEntry+","+probabilityDivestment+","+probabilityInvestment+","+profit+",");
						for (int n = 1; n < s.getNumFirms(); n++) {
							outBbl.write(s.getCapacity(n) + ",");
						}
						outBbl.write("\n");
					}
					if (policy > 0 && !s.getExit() && c0 != 0) {						
						double z = stdNormal.inverse(probabilityInvestment);
						z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);
						z = ( - stdNormal.probability(z) / (stdNormal.cumulative(z)));
						if (k == 4 && i == 0) {
							z = stdNormal.inverse(probabilityDivestment);
							z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);					
						}
						if (k == 6 || k == 7) {
							z = 0.0;
						}
						Win[1] -= discount;
						Win[2] -= discount * z; //expected
						Win[7] -= discount * policy;
						Win[8] -= discount * policy * policy / 1000.0;
					}
					if (policy < 0 && !s.getExit() && c0 != 0) {
						double z = stdNormal.inverse(probabilityDivestment);
						z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);
						z = ( - stdNormal.probability(z) / (stdNormal.cumulative(z)));
						if (k == 4 && i == 0) {
							z = stdNormal.inverse(probabilityDivestment);
							z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);	
						}
						if (k == 6 || k == 7) {
							z = 0.0;
						}
						Win[9]  -= discount;
						Win[10] -= discount * z; // expected
						Win[15] -= discount * policy;
						Win[16] += discount * policy * policy / 1000.0;
					}

					if (s.getExit() && c0 != 0) {
						double z = stdNormal.inverse(1 - probabilityExit);
						z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);
						if (k != 2) {
							z = (stdNormal.probability(z) / (1.0 - stdNormal.cumulative(z)));
						}
						Win[17] += discount;
						Win[18] += discount * z; // expected
						if (divestUponExit) {
							Win[15] -= discount * (-c0);
							Win[16] += discount * (-c0) * (-c0) / 1000.0;
						}
						i = simulationHorizon + 1; // if you exit, you are done
					}

					if (k == 3 && c0 == 0) {						
						double z = stdNormal.inverse(probabilityEntry);
						z = Math.max(Math.min(z, truncateExtremes), -truncateExtremes);
						Win[19] -= discount;
						Win[20] -= discount * z; // marginal unit
						Win[7] -= discount * policy;
						Win[8] -= discount * policy * policy / 1000.0;
					}
								
					s.updateState(policy);
					
				}
				for (int ci = 0; ci <= numParams; ci++) {
					W[ci] += Win[ci];
				}
			}
			for (int ci = 0; ci <= numParams; ci++) {
				W[ci] /= (numSimWTask + 0.0);
			}
			wList.add(new Jama.Matrix(W, 1));
		}
		if (savefiles) { 
			outBbl.close();
		}
		
		return wList;
	}
}
