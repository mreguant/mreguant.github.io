/**
 * profitData.java
 *
 * This function stores profit information at different combinations of
 * capacities for a given set of demand characteristics and production costs.
 * The function saves previous combinations of capacities to spare 
 * computation time. It also gives the option to approximate profits based
 * on similar capacity combinations, also to spare computation time.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.simulateW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import estimation.main.EstimationConstants;
import estimation.production.cournotSolve;
import estimation.utility.demandCurve;

public class ProfitData {
	
	private demandCurve demand;
	private int year;
	private int market;
	private double[] productionParams;
	private boolean store;
	private double roundingSize;
	
	private HashMap<String, Double> datalist; 
	
	public ProfitData(demandCurve demand, int year, int market, double[] production, boolean store) {
		
		this.demand = demand;
		this.year = year;
		this.market = market;
		this.productionParams = production;
		this.store = store;
		this.datalist = new HashMap<String, Double>();
		this.roundingSize = EstimationConstants.ROUND;
		
	}

	public double getProfit(double[] capacities, int[] tech) {
		
		double profit = 0.0;		
		
		if (store) {
			// floor
			double profitFloor = 0.0;
			double floor = Math.floor(capacities[0]/roundingSize)*roundingSize;
			double[] capfloor = new double[capacities.length];
			String keyname = "";
			keyname = keyname + "_" + (int) (Math.floor(capacities[0]/roundingSize)*roundingSize);
			capfloor[0] = (Math.floor(capacities[0]/roundingSize)*roundingSize);
			ArrayList<Integer> list = new ArrayList<Integer>();
			for (int i = 1; i < capacities.length; i++) {
				list.add(new Integer((int) (Math.ceil(capacities[i]/roundingSize)*roundingSize)));
			}
			Collections.sort(list);
			for (int i = 1; i < capacities.length; i++) {
				keyname = keyname + "_" + (list.get(i - 1)).intValue();
				capfloor[i] = (list.get(i - 1)).doubleValue();
			}
			if (datalist.get(keyname) != null) {
				profitFloor = datalist.get(keyname).doubleValue();
			} else {
				// if not in list
				cournotSolve qsolve = new cournotSolve(demand);
				qsolve.getQ(capfloor, productionParams, year, market, tech);
				profitFloor = qsolve.getProfitVector().get(0,0);
				datalist.put(keyname, profitFloor);
			}
			
			// ceiling
			double profitCeil = 0.0;
			double ceil = Math.ceil(capacities[0]/roundingSize)*roundingSize;
			double[] capceil = new double[capacities.length];
			keyname = "";
			keyname = keyname + "_" + (int) (Math.ceil(capacities[0]/roundingSize)*roundingSize);
			capceil[0] = (Math.ceil(capacities[0]/roundingSize)*roundingSize);
			list = new ArrayList<Integer>();
			for (int i = 1; i < capacities.length; i++) {
				list.add(new Integer((int) (Math.floor(capacities[i]/roundingSize)*roundingSize)));
			}
			Collections.sort(list);
			for (int i = 1; i < capacities.length; i++) {
				keyname = keyname + "_" + (list.get(i - 1)).intValue();
				capceil[i] = (list.get(i - 1)).doubleValue();
			}
			if (datalist.get(keyname) != null) {
				profitCeil = datalist.get(keyname).doubleValue();
			} else {
				// if not in list
				cournotSolve qsolve = new cournotSolve(demand);
				qsolve.getQ(capceil, productionParams, year, market, tech);
				profitCeil = qsolve.getProfitVector().get(0,0);
				datalist.put(keyname, profitCeil);
			}
			
			profit = ((ceil - capacities[0]) * profitFloor + (capacities[0] - floor) * profitCeil)/roundingSize;
					
		} else {
			cournotSolve qsolve = new cournotSolve(demand);
			qsolve.getQ(capacities, productionParams, year, market, tech);
			profit = qsolve.getProfitVector().get(0,0);
		}
		
		return profit;
		
	}

}
