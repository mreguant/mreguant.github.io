/**
 * simulateW.java
 * 
 * Creates the moments for the BBL estimation. 
 * Each forward simulation is computed for a given simulation 
 * horizon and a number of simulation draws (numSimWTask).
 * Each forward simulation is computed by the function
 * simulateWTask.java.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.simulateW;

import estimation.dataManipulation.plantRecordID;
import estimation.main.EstimationConstants;
import estimation.ssrulesLikelihood.investmentParametersContainer;
import estimation.utility.demandCurve;
import ilog.concert.*;
import ilog.cplex.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import utility.pmUtility;


public class simulateW {
	
	// simulation constants
	private static int baseYear; 
	private static int baseMarket;
	private static int simulationHorizon = 50; 
	private static int numSimIter;
	private static int numSimW; // market configurations
	private static int numSimWTask; // simulations per market configuration
	
	private ArrayList<plantRecordID> dataMaster = new ArrayList<plantRecordID>();
	
	int numParams = 22;
	
	Jama.Matrix dataEntry;
	
	double[] productionParameters = new double[6 + 1];

	static NumberFormat formatNumber = NumberFormat.getInstance();
	static NumberFormat formatMoney = NumberFormat.getCurrencyInstance();

	private double[] estimatedParameters;
	private double[] estimatedParametersJoint;
	private double[] estimatedParametersLinear;
	private double[] estimatedParametersJointLinear;
	private double[] estimatedParametersQ;
	private double[] estimatedParametersQJoint;
	private double[] estimatedParametersQLinear;
	private double[] estimatedParametersQJointLinear;
	private double[] estimatedParametersD;
	private double[] estimatedParametersDJoint;
	private double[] estimatedParametersDLinear;
	private double[] estimatedParametersDJointLinear;
	private double[] estimatedParametersA;
	private double[] estimatedParametersAJoint;
	private double[] estimatedParametersALinear;
	private double[] estimatedParametersAJointLinear;
	private double[] estimatedParametersAD;
	private double[] estimatedParametersADJoint;
	private double[] estimatedParametersADLinear;
	private double[] estimatedParametersADJointLinear;
	
	private boolean positiveAdjustment	= EstimationConstants.POSITIVE_ADJ_COST;
	private boolean divestUponExit 		= EstimationConstants.DIVEST_UPON_EXIT;
	private boolean squaredDeviations 	= EstimationConstants.DEV_SQUARE;
	private boolean noSquaredCosts 		= EstimationConstants.NO_QUADRATIC_COSTS;
	private boolean divestmentZero 		= EstimationConstants.DIVESTMENT_ZERO;
	private boolean adjustEqual			= EstimationConstants.ADJUST_EQUAL;

	public simulateW(long rngSeed, int sim, demandCurve priceData, int market, double[] productionCosts,
			investmentParametersContainer policyParameters,
			double[] exitParameters, double[] entryParameters) {
		
		formatMoney.setMaximumFractionDigits(0);
		formatNumber.setMaximumFractionDigits(0);

		ExecutorService tpes = Executors.newFixedThreadPool(EstimationConstants.NUM_THREADS);
		numParams = 22;

		baseYear = EstimationConstants.BASE_YEAR;
		baseMarket = market;
		numSimIter = EstimationConstants.NUM_SIMW_ITER;
		numSimW = EstimationConstants.NUM_SIMW;
		numSimWTask = EstimationConstants.NUM_SIMWTASK;
		
		pmUtility.prettyPrintVector(new Jama.Matrix(productionCosts, 1));
		for (int i = 0; i < 3; i++) {
			productionParameters[i + 1] = productionCosts[i + 1];
		}

		if (policyParameters.getVarianceBandEquation() == 0) {
			System.out.println("ALERT: Triggering this varianceBand=0 warning in simulateW.");
		}

		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(
					new File("data/estimation/dataEstimation"+sim+".dat")));
			int numObs = (Integer) in.readObject();
			for (int i = 0; i < numObs; i++) {
				dataMaster.add((plantRecordID) in.readObject());
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Parameters for band:");
		pmUtility.prettyPrintVector(policyParameters.getBetaBand());
		System.out.println("Variance of band: " + policyParameters.getVarianceBandEquation());
		System.out.println("Parameters for target:");
		pmUtility.prettyPrintVector(policyParameters.getBetaTarget());
		System.out.println("Variance of target: " + policyParameters.getVarianceTargetEquation());
		System.out.println(entryParameters[0] + " " + entryParameters[1] + " " + entryParameters[2]);
		double[] masterParameters = { 36000.0, 22000.0, 0.0, 0.0, 0.0, 0.0, 294, 0.0,
									  36000.0, 22000.0, 0.0, 0.0, 0.0, 0.0, 294, 0.0, 
									  70000.0, 55000.0, 0.0, 0.0, 0.0, 0.0 };

		System.out.println("Dynamic Parameters Starting values: "
				+ pmUtility.stringPrettyPrint(new Jama.Matrix(masterParameters,1)));

		estimatedParameters = new double[numParams];
		estimatedParametersJoint = new double[numParams];
		estimatedParametersLinear = new double[numParams];
		estimatedParametersJointLinear = new double[numParams];
		estimatedParametersQ = new double[numParams];
		estimatedParametersQJoint = new double[numParams];
		estimatedParametersQLinear = new double[numParams];
		estimatedParametersQJointLinear = new double[numParams];
		estimatedParametersD= new double[numParams];
		estimatedParametersDJoint = new double[numParams];
		estimatedParametersDLinear = new double[numParams];
		estimatedParametersDJointLinear = new double[numParams];
		estimatedParametersA= new double[numParams];
		estimatedParametersAJoint = new double[numParams];
		estimatedParametersALinear = new double[numParams];
		estimatedParametersAJointLinear = new double[numParams];
		estimatedParametersAD= new double[numParams];
		estimatedParametersADJoint = new double[numParams];
		estimatedParametersADLinear = new double[numParams];
		estimatedParametersADJointLinear = new double[numParams];			
		
		double[] guess = new double[numParams];
		double[] guessjoint = new double[numParams];
		for (int i = 0; i < numParams; i++) {
			guess[i] = masterParameters[i];
			guessjoint[i] = masterParameters[i];
		}
		
		Jama.Matrix guessMat = new Jama.Matrix(numParams+1, 1);
		for (int i = 0; i < numParams; i++) {
			guessMat.set(i, 0, guess[i]);
		}
		
		String[] names = { "Investment Dist Mean", "Investment Dist StdDev",
				"", "",
				"", "",
				"Investment Cost", "Investment Cost Squared",
				"Divestment Dist Mean", "Divestment Dist StdDev",
				"", "",
				"", "",
				"Divestment Cost", "Divestment Cost Squared",
				"Exit Dist Mean", "Exit Dist StdDev", "Entry Dist Mean", 
				"Entry Dist StdDev" , "", ""};
		String[] namesDev = { "Optimal", "Perturbation",
				"Exit", "Entry", "Force Change", "Force No Change" };

		System.out.println("Random number seed: " + rngSeed);
		Random rng = new Random(rngSeed);


		ArrayList<Jama.Matrix> wMasterList = new ArrayList<Jama.Matrix>();
		ArrayList<Jama.Matrix> wMasterListA = new ArrayList<Jama.Matrix>();	
		ArrayList<Jama.Matrix> wMasterListE = new ArrayList<Jama.Matrix>();
		ArrayList<Jama.Matrix> wMasterListEA = new ArrayList<Jama.Matrix>();	
		try {

			// PREPARE INEQUALITY COMBINATIONS *********************************************
			ArrayList<Future<ArrayList<Jama.Matrix>>>  futureList = new ArrayList<Future<ArrayList<Jama.Matrix>>>();
			Random rncap = new Random(rng.nextLong());
			
			for (int ik = 0; ik < dataMaster.size(); ik++) {
				plantRecordID plant = dataMaster.get(ik);
				if ( plant.getYear() == 2005 || plant.getYear()*1.0/5.0 == Math.round(plant.getYear()*1.0/5.0)) {
					if (baseMarket == 20 || plant.getMarketIndex() == baseMarket) {
						for (int j = 0; j < numSimIter; j++) {
							// set capacities
							int firms = Math.max(plant.getNumFirms(),demandCurve.sizeMarket[plant.getMarketIndex()]);
							double draw = rncap.nextDouble();
							if (j == 0) {
								draw = 0.5;
							}
							double[] cap = new double[firms];
							cap[0] = Math.max(plant.getCapacity(0)
									- EstimationConstants.SHOCK_DEV + 2 * EstimationConstants.SHOCK_DEV * draw, 
									EstimationConstants.MIN_CAPACITY);
							for (int cn = 1; cn < plant.getNumFirms(); cn++) {
								cap[cn] = Math.max(plant.getCapacity(cn), EstimationConstants.MIN_CAPACITY);
							}
							for (int cn = plant.getNumFirms(); cn < firms; cn++) {
								cap[cn] = 0.0;
							}
							if (EstimationConstants.SET_ONE_OUT && j == numSimIter-1 && j != 0) {
								cap[firms-1] = 0.0;
							}

							// send job
							//boolean savefiles = (sim == 0 && j == 0 && EstimationConstants.DISCOUNT_FACTOR == 0.9 && 
							//		EstimationConstants.ELASTICITY.contentEquals("2") && EstimationConstants.ELASTICITY_IMPORTS.contentEquals("2.5"));
							boolean savefiles = false;
							futureList.add(tpes.submit(new SimulateWTask(rng.nextLong(), numSimWTask, numParams,
									simulationHorizon, divestUponExit, priceData,	productionParameters, policyParameters,
									exitParameters, entryParameters, plant.getMarketIndex(), baseYear, cap, savefiles)));
						}
					}
				}
			}
			
			// COMPUTE INEQUALITIES *********************************************************
			numSimW = futureList.size();
			System.out.println("NumSimW: " + numSimW);
			for (int ik = 0; ik < futureList.size(); ik++) {
				
				System.out.print(ik + " ");
				Future<ArrayList<Jama.Matrix>> futureTask = futureList.get(ik);
				ArrayList<Jama.Matrix> W = futureTask.get();

				// staying vs random
				wMasterList.add(W.get(0));
				wMasterListA.add(W.get(1));
				
				// positive NPV
				if (EstimationConstants.NON_ZERO_DEVS) {
					wMasterList.add(W.get(0));
					wMasterListA.add(W.get(1).times(0.0));
				}
				// exit just indifferent at truncation point
				if (EstimationConstants.EXIT_DEVS) {					
					wMasterList.add(W.get(2));
					wMasterListA.add(W.get(0));
					wMasterList.add(W.get(0));
					wMasterListA.add(W.get(2));
				}
				
				// entry just indifferent
				wMasterListE.add(W.get(3));
				wMasterListEA.add(W.get(3).times(0.0));
				wMasterListE.add(W.get(3).times(0.0));
				wMasterListEA.add(W.get(3));

				// investment indifferent in first period
				if (EstimationConstants.FORCE_DEVS) {
					wMasterList.add(W.get(5));
					wMasterListA.add(W.get(4));
					wMasterList.add(W.get(4));
					wMasterListA.add(W.get(5));
				}
				
				// investment better than always or never
				wMasterList.add(W.get(0));
				wMasterListA.add(W.get(6));
				wMasterList.add(W.get(0));
				wMasterListA.add(W.get(7));
				
				if (ik == 0) {
					for (int i = 0; i < 6; i++) {						
						Jama.Matrix wFirst = W.get(i);
						System.out.println(" *** " + namesDev[i] + " *** ");
						for (int pr = 0; pr < wFirst.getColumnDimension(); pr++) {
							if (pr == 0) {
								System.out.println("Profits: " + wFirst.get(0, 0));
							} else {
								if (!names[pr - 1].contentEquals("")) {
									System.out.println(names[pr - 1] + " " + wFirst.get(0, pr));
								}
							}
						}
					}
				}
				
			}
			System.out.println();
				
			ArrayList<Jama.Matrix> wListDiff = new ArrayList<Jama.Matrix>();
			ArrayList<Jama.Matrix> wListDiffEntry = new ArrayList<Jama.Matrix>();
			ArrayList<Jama.Matrix> wListDiffAll = new ArrayList<Jama.Matrix>();
			
			for (int draw = 0; draw < wMasterList.size(); draw++) {
				wListDiff.add(wMasterList.get(draw).minus(wMasterListA.get(draw)));
				wListDiffAll.add(wMasterList.get(draw).minus(wMasterListA.get(draw)));
			}
			
			
			for (int draw = 0; draw < wMasterListE.size(); draw++) {
				wListDiffEntry.add(wMasterListE.get(draw).minus(wMasterListEA.get(draw)));
				wListDiffAll.add(wMasterListE.get(draw).minus(wMasterListEA.get(draw)));				
			}			
			
			// ESTIMATION *************************************************************
			// QUADRATIC MARGINAL COSTS
			divestmentZero = true;
			noSquaredCosts = true;
			squaredDeviations = true;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			System.out.println("******************* Two step *******************");
			for (int i = 0; i < names.length; i++) {
				if (!names[i].contentEquals("")) {
					System.out.println(names[i] + ":   " + guess[i]);
				}
			}
			for (int i = 0; i < guess.length; i++) {
				estimatedParameters[i] = guess[i];
			}
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);
			System.out.println("******************* One step *******************");
			for (int i = 0; i < names.length; i++) {
				if (!names[i].contentEquals("")) {
					System.out.println(names[i] + ":   " + guessjoint[i]);
				}
			}			
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersJoint[i] = guessjoint[i];
			}
			
			squaredDeviations = false;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersLinear[i] = guess[i];
			}
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);	
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersJointLinear[i] = guessjoint[i];
			}
			
			// QUADRATIC MARGINAL COSTS
			noSquaredCosts = false;
			squaredDeviations = true;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersQ[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);	
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersQJoint[i] = guessjoint[i];
			}
			
			squaredDeviations = false;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersQLinear[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);			
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersQJointLinear[i] = guessjoint[i];
			}
			
			// DIVESTMENT COSTS
			divestmentZero = false;
			noSquaredCosts = true;
			squaredDeviations = true;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersD[i] = guess[i];
			}			
			System.out.println("******************* Two step *******************");
			for (int i = 0; i < names.length; i++) {
				if (!names[i].contentEquals("")) {
					System.out.println(names[i] + ":   " + guess[i]);
				}
			}
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);	
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersDJoint[i] = guessjoint[i];
			}
			System.out.println("******************* One step *******************");
			for (int i = 0; i < names.length; i++) {
				if (!names[i].contentEquals("")) {
					System.out.println(names[i] + ":   " + guessjoint[i]);
				}
			}		
			
			squaredDeviations = false;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersDLinear[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);			
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersDJointLinear[i] = guessjoint[i];
			}
			
			divestmentZero = true;
			adjustEqual = false;
			noSquaredCosts = true;
			squaredDeviations = true;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersA[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);	
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersAJoint[i] = guessjoint[i];
			}
			
			squaredDeviations = false;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersALinear[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);			
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersAJointLinear[i] = guessjoint[i];
			}
			
			divestmentZero = false;
			adjustEqual = false;
			noSquaredCosts = true;
			squaredDeviations = true;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersAD[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);	
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersADJoint[i] = guessjoint[i];
			}
			
			squaredDeviations = false;
			guess = minimizeObjective(wListDiff, guess);
			guess = minimizeObjectiveEntry(wListDiffEntry, guess);
			for (int i = 0; i < guess.length; i++) {
				estimatedParametersADLinear[i] = guess[i];
			}			
			guessjoint = minimizeObjective(wListDiffAll, guessjoint);			
			for (int i = 0; i < guessjoint.length; i++) {
				estimatedParametersADJointLinear[i] = guessjoint[i];
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("******************* Estimation complete *******************\n");
		tpes.shutdown();
	}

	public double[] getEstimates() {
		return estimatedParameters;
	}
	
	public double[] getEstimatesJoint() {
		return estimatedParametersJoint;
	}

	public double[] getEstimatesLinear() {
		return estimatedParametersLinear;
	}
	
	public double[] getEstimatesJointLinear() {
		return estimatedParametersJointLinear;
	}
	
	public double[] getEstimatesQ() {
		return estimatedParametersQ;
	}
	
	public double[] getEstimatesQJoint() {
		return estimatedParametersQJoint;
	}

	public double[] getEstimatesQLinear() {
		return estimatedParametersQLinear;
	}
	
	public double[] getEstimatesQJointLinear() {
		return estimatedParametersQJointLinear;
	}

	public double[] getEstimatesD() {
		return estimatedParametersD;
	}
	
	public double[] getEstimatesDJoint() {
		return estimatedParametersDJoint;
	}

	public double[] getEstimatesDLinear() {
		return estimatedParametersDLinear;
	}
	
	public double[] getEstimatesDJointLinear() {
		return estimatedParametersDJointLinear;
	}

	public double[] getEstimatesA() {
		return estimatedParametersA;
	}
	
	public double[] getEstimatesAJoint() {
		return estimatedParametersAJoint;
	}

	public double[] getEstimatesALinear() {
		return estimatedParametersALinear;
	}
	
	public double[] getEstimatesAJointLinear() {
		return estimatedParametersAJointLinear;
	}

	public double[] getEstimatesAD() {
		return estimatedParametersAD;
	}
	
	public double[] getEstimatesADJoint() {
		return estimatedParametersADJoint;
	}

	public double[] getEstimatesADLinear() {
		return estimatedParametersADLinear;
	}
	
	public double[] getEstimatesADJointLinear() {
		return estimatedParametersADJointLinear;
	}
	
	// Initialize the process
	private double[] minimizeObjective(ArrayList<Jama.Matrix> Wdiff, double[] guess) {
		try {
			
			IloCplex cplex = null;
			cplex = new IloCplex();
			cplex.setOut(null); // do not display the optimization output
			cplex.setWarning(null); // do not display warnings
			
			// Choice variables
			double A = 1E7;
			IloNumVar[] theta = new IloNumVar[numParams]; // coefficients
			// Define bounds on variables
			for (int i = 0; i < numParams; i++) {
				theta[i] = cplex.numVar(-A, A);
			}
			IloNumVar[] x = new IloNumVar[Wdiff.size()]; // value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				x[i] = cplex.numVar(-1e12, 0.0);
			}
			
			// Define the objective function - minimize deviations
			IloLinearNumExpr deviations1 = cplex.linearNumExpr();
			// value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				deviations1.addTerm(1.0/(Wdiff.size()*1.0), x[i]);
			}
			IloNumExpr deviations2 = cplex.numExpr();
			// value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				deviations2 = cplex.diff(deviations2, cplex.prod(x[i],x[i],1.0/(Wdiff.size()*1.0)));
			}
			if (!squaredDeviations) {
				cplex.addMaximize(deviations1);
			} else {
				cplex.addMaximize(deviations2);
			}
				
			// x smaller than W'theta
			for (int i = 0; i < Wdiff.size(); i++) {
				IloLinearNumExpr diffValue = cplex.linearNumExpr();
				diffValue.setConstant(Wdiff.get(i).get(0,0)/(Wdiff.size()*1.0)); 
				for (int p = 0; p < numParams; p++) {
					diffValue.addTerm(Wdiff.get(i).get(0, p+1)/(1000.0 * Wdiff.size()) ,theta[p]);
				}				
				cplex.addGe(diffValue, x[i]);
			}

			// Define constraints
			// no arbitrage
			cplex.addLe(theta[14], theta[6]);
			cplex.addLe(theta[15], theta[7]);
			
			// equal adjustment costs
			if (adjustEqual) {
				cplex.addEq(theta[0], theta[8]);
				cplex.addEq(theta[1], theta[9]);
			}
			
			// positive sigma
			cplex.addGe(theta[1], 0.0);
			cplex.addGe(theta[9], 0.0);
			cplex.addGe(theta[17], 0.0);
			cplex.addGe(theta[19], 0.0);
			
			if (positiveAdjustment) {
				cplex.addGe(cplex.diff(cplex.sum(theta[0],cplex.prod(50.0,theta[6])), cplex.prod(2.0, theta[1])),0.0);
			}
			// zero divestment benefits
			if (divestmentZero) {
				cplex.addEq(0.0, theta[14]);
				cplex.addEq(0.0, theta[15]);
			}
			// quadratic costs zero
			if (noSquaredCosts) {
				cplex.addEq(0.0, theta[7]);
				cplex.addEq(0.0, theta[15]);
			}

			for (int i: new int[] {2,3,4,5,10,11,12,13,20,21}) {
				cplex.addEq(0.0, theta[i]);
			}
			
			// SOLVE THE MODEL	
			if (cplex.solve()) {
				for (int p = 0; p < numParams; p++) {
					guess[p] = cplex.getValue(theta[p]);
				}
				return guess;
			} else {
				System.out.println("*** WARNING *** No solution found.");
				for (int p = 0; p < numParams; p++) {
					guess[p] = 0.0;
				}
			}
			cplex.clearModel();
			cplex.endModel();
			cplex.end();
			cplex = null;

		} catch (IloException e) {
			e.printStackTrace();
			System.out.println("Solver failed in dynamic estimation!");
		}

		return guess;
		
	}
	
	private double[] minimizeObjectiveEntry(ArrayList<Jama.Matrix> Wdiff, double[] guess) {
		try {
			
			IloCplex cplex = null;
			cplex = new IloCplex();
			cplex.setOut(null); // do not display the optimization output
			cplex.setWarning(null); // do not display warnings
			
			// Choice variables
			double A = 1E6;
			IloNumVar[] theta = new IloNumVar[numParams]; // coefficients
			// Define bounds on variables
			for (int i = 0; i < numParams; i++) {
				theta[i] = cplex.numVar(-A, A);
			}
			IloNumVar[] x = new IloNumVar[Wdiff.size()]; // value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				x[i] = cplex.numVar(-1e12, 0.0);
			}
			
			// Define the objective function - minimize deviations
			IloLinearNumExpr deviations1 = cplex.linearNumExpr();
			// value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				deviations1.addTerm(1.0/(Math.sqrt(Wdiff.size())*1.0), x[i]);
			}
			IloNumExpr deviations2 = cplex.numExpr();
			// value objective
			for (int i = 0; i < Wdiff.size(); i++) {
				deviations2 = cplex.diff(deviations2, cplex.prod(x[i],x[i],1.0/(Math.sqrt(Wdiff.size())*1.0)));
			}
			if (!squaredDeviations) {
				cplex.addMaximize(deviations1);
			} else {
				cplex.addMaximize(deviations2);
			}
				
			// x smaller than W'theta
			for (int i = 0; i < Wdiff.size(); i++) {
				IloLinearNumExpr diffValue = cplex.linearNumExpr();
				diffValue.setConstant(Wdiff.get(i).get(0,0)); 
				for (int p = 0; p < numParams; p++) {
					diffValue.addTerm(Wdiff.get(i).get(0, p+1)/(1000.0) ,theta[p]);
				}				
				cplex.addGe(diffValue, x[i]);
			}

			// Define constraints
			// profit
			for (int p = 0; p < numParams; p++) {
				if (p != 18 && p != 19) {
					cplex.addEq(guess[p], theta[p]);
				}
			}
			// positive sigma
			cplex.addGe(theta[19], 0);
			
			// SOLVE THE MODEL		
			if (cplex.solve()) {
				for (int p = 0; p < numParams; p++) {
					guess[p] = cplex.getValue(theta[p]);
				}
				return guess;
			} else {
				System.out.println("*** WARNING *** No solution found.");
				for (int p = 0; p < numParams; p++) {
					guess[p] = 0.0;
				}
			}
			cplex.clearModel();
			cplex.endModel();
			cplex.end();
			cplex = null;

		} catch (IloException e) {
			e.printStackTrace();
			System.out.println("Solver failed in dynamic estimation!");
		}

		return guess;
		
	}
	
}
