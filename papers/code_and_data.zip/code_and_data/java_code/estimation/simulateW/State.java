/**
 * State.java
 *
 * This function creates a particular combination of capacities.
 * It provides the function to update the state based on the
 * estimated policy functions (getPolicyFirst()) and to update
 * the state accordingly (updateState()).
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.simulateW;

import JSci.maths.statistics.NormalDistribution;
import estimation.main.EstimationConstants;
import estimation.ssrulesLikelihood.investmentParametersContainer;
import estimation.utility.demandCurve;

import java.text.NumberFormat;
import java.util.Random;

import utility.pmUtility;


public class State implements Cloneable {

	private static java.text.NumberFormat format = java.text.NumberFormat.getInstance();
	private double[] productionParameters;
	private double[] capacities;
	private int[] tech;
	public boolean perturbPolicies = false;
	private Jama.Matrix betaBand;
	private Jama.Matrix betaTarget;
	private boolean exited = false;
	private boolean forceExit = false;
	private boolean forceEntry = false;
	private boolean forceChange = false;
	private boolean forceNoChange = false;		
	private static NormalDistribution normal = new NormalDistribution();
	private double iperturbtarget;
	private double iperturbband;
	private double iperturbexit;
	private NormalDistribution errorBand;
	private double probabilityInvestment;
	private double probabilityDivestment;
	private double probabilityExit;
	private double probabilityEntry;	
	private Random rng;
	private long seed2;
	private long seed;
	static boolean verbose = false;
	private int baseMarket = 11;	
	static NumberFormat nf = NumberFormat.getInstance();

	private double ENTRY_INTERCEPT;
	private double ENTRY_INCUMBENT_CAPACITY_COEFFICIENT;
	private double EXIT_INTERCEPT;
	private double EXIT_OWN_CAPACITY_COEFFICIENT;
	private double EXIT_COMPETITORS_CAPACITY_COEFFICIENT;

	private double[] exitParameters;
	private double[] entryParameters;
	private demandCurve priceData;
	private final investmentParametersContainer policyParameters;

	/**
	 * Creates a new instance of state
	 */
	public State(long seed, demandCurve priceData, int market, double[] capacityCosts,
			investmentParametersContainer policyParameters,
			double[] exitParameters, double[] entryParameters) {
		
		betaBand = policyParameters.getBetaBand();
		betaTarget = policyParameters.getBetaTarget();
		this.seed = seed;
		this.policyParameters = policyParameters;
		productionParameters = capacityCosts;
		errorBand = new NormalDistribution(0,policyParameters.getVarianceBandEquation());
		new NormalDistribution(0,policyParameters.getVarianceTargetEquation());
		rng = new Random(seed);
		seed2 = rng.nextLong();
		iperturbtarget = normal.inverse(rng.nextDouble());
		iperturbband = normal.inverse(rng.nextDouble());
		this.entryParameters = entryParameters;
		this.exitParameters = exitParameters;
		this.priceData = priceData;
		this.baseMarket = market;

		EXIT_INTERCEPT = exitParameters[1];
		EXIT_OWN_CAPACITY_COEFFICIENT = exitParameters[2];
		EXIT_COMPETITORS_CAPACITY_COEFFICIENT = exitParameters[3];

		ENTRY_INTERCEPT = entryParameters[1];
		ENTRY_INCUMBENT_CAPACITY_COEFFICIENT = entryParameters[2];

	}

	public Jama.Matrix getState() {
		return new Jama.Matrix(capacities, 1);
	}

	public void perturb(boolean perturb) {
		perturbPolicies = perturb;
		if (perturb) {
			Random rng2 = new Random(seed2);
			if (rng2.nextDouble() < 0.5) {
				// perturb threshold for investment (probability)
				iperturbband = 0.5 * normal.inverse(rng2.nextDouble());
				iperturbtarget = 0.0;
				iperturbexit = 0.0;
			} else if (rng2.nextDouble() < 0.0) {
				// perturb threshold for exit (probability)
				iperturbband = 0.0;
				iperturbtarget = 0.0;
				iperturbexit = 0.5 * normal.inverse(rng2.nextDouble());
			} else {
				// perturb level of investment
				iperturbband = 0.0;
				iperturbtarget = 0.15 * normal.inverse(rng2.nextDouble());
				iperturbexit = 0.0;
			}
		} else {
			iperturbband = 0.0;
			iperturbtarget = 0.0;
		}
	}

	public double getPolicyFirst(int firm) {
		double value = 0.0;
		double x = getCapacity(0);

		double marketCapacity = 0.0;
		for (int i = 0; i < getNumFirms(); i++) {
			marketCapacity += capacities[i];
		}

		// find basis for capother, owncap, and shocks
		if (verbose) {
			System.out.println("Using own capacity of: " + x
					+ " and market capacity of: " + marketCapacity
					+ " to compute bands and targets.");
		}

		Jama.Matrix basisX = new Jama.Matrix(1,4); 
		Jama.Matrix basisXband = new Jama.Matrix(1,3);
		basisX.set(0, 0, marketCapacity/demandCurve.maxCapacityMarket[baseMarket]);
		basisX.set(0, 1, Math.log(x + 1.0));
		if (x == 0.0) {
			basisX.set(0, 2, 1.0);
		} else {
			basisX.set(0, 2, 0.0);
		}
		basisX.set(0, 3, 1.0);
		
		basisXband.set(0, 0, marketCapacity/demandCurve.maxCapacityMarket[baseMarket]);
		basisXband.set(0, 1, Math.log(x + 1.0));
		basisXband.set(0, 2, 1.0);

		if (marketCapacity < 5 && verbose) {
			pmUtility.prettyPrintVector(betaTarget);
			pmUtility.prettyPrint(basisX);
		}
		// interpret the error here as measurement error, not structural error
		double target = basisX.times(betaTarget).get(0, 0);
		target = Math.exp(target);
		double band = basisXband.times(betaBand).get(0, 0);
		
		if (perturbPolicies && firm == 0) {
			band += iperturbband;
			target = Math.exp(Math.log(target) + iperturbtarget);
		}

		if (verbose) {
			pmUtility.prettyPrint(basisX);
			System.out.print("Current: " + nf.format(x) + " Target: "
					+ nf.format(target) + " change: " + nf.format(target - x)
					+ " Band: " + nf.format(band));
		}
		
		if (EstimationConstants.BAND) {
			if (target - x > 0) {
				// target - exp(band + e) = threshold
				// x < threshold -> investment
				// prob(exp(band + e) < target - x) -> prob(investment)
				probabilityInvestment = errorBand.cumulative(Math.log(target - x) - band);
				probabilityDivestment = 0.0;
			} else {
				// x > threshold -> divestment
				// prob(exp(band + e) > target - x) -> prob(divestment)
				probabilityDivestment = errorBand.cumulative(Math.log(x - target) - band);
				probabilityInvestment = 0.0;
			}
		} else {
			if (target - x > 0) {
				// x < threshold -> investment
				probabilityInvestment = 0.02 + 0.04*marketCapacity/demandCurve.maxCapacityMarket[baseMarket];
				probabilityDivestment = 0.0;
			} else {
				// x > threshold -> divestment
				probabilityDivestment = 0.02 + 0.04*marketCapacity/demandCurve.maxCapacityMarket[baseMarket];
				probabilityInvestment = 0.0;
			}
		}
		
		double adjustmentDraw = rng.nextDouble();
		if (target - x > 0) {
			if (adjustmentDraw < probabilityInvestment || (forceChange && firm == 0) ) {
				value = target - x;
				value = Math.min(Math.max(value, -x + EstimationConstants.MIN_CAPACITY), 1.1*demandCurve.maxCapacityMarket[baseMarket]-x);
			}
			if (forceNoChange && firm == 0) {
				value = 0.0;
			}
		}
		if (target - x < 0) {
			if (adjustmentDraw < probabilityDivestment || (forceChange && firm == 0) ) {
				value = target - x;
				value = Math.min(Math.max(value, -x + EstimationConstants.MIN_CAPACITY), 1.1*demandCurve.maxCapacityMarket[baseMarket]-x);
			}
			if (forceNoChange && firm == 0) {
				value = 0.0;
			}
		}
		
		// adjust for entrant and exit
		double entryDraw = rng.nextDouble();
		if (x == 0) {
			probabilityInvestment = 1.0;
			probabilityEntry = normal.cumulative(ENTRY_INTERCEPT + 
					ENTRY_INCUMBENT_CAPACITY_COEFFICIENT * marketCapacity
					/ demandCurve.maxCapacityMarket[baseMarket]);
			if (entryDraw < probabilityEntry || (forceEntry && firm == 0) ) {
				value = target;
				value = Math.min(Math.max(value, EstimationConstants.MIN_CAPACITY), 1.1*demandCurve.maxCapacityMarket[baseMarket]);
			}
		} else {
			probabilityEntry = 0.0;
		}

		// put in exit here
		double exitDraw = rng.nextDouble();		
		if (x > 1.0) {
			double shifter = 0.0;
			if (perturbPolicies && firm == 0) {
				shifter = iperturbexit;
			}
			probabilityExit = normal.cumulative(shifter + 
						EXIT_INTERCEPT + EXIT_OWN_CAPACITY_COEFFICIENT
						* Math.log(x + 1.0) + EXIT_COMPETITORS_CAPACITY_COEFFICIENT
						* (marketCapacity - x) / demandCurve.maxCapacityMarket[baseMarket]);
			if ( (exitDraw < probabilityExit && !forceChange && !forceNoChange) || (forceExit && firm == 0)) {
				value = -x;
				exited = true;
			}
		} else {
			probabilityExit = 0.0;
		}
		
		return value;
	}

	@Override
	public String toString() {
		String result = "";
		for (int i = 0; i < getNumFirms(); i++) {
			result = result.concat(format.format(capacities[i]) + " ");
		}
		return result;
	}

	public void updateState(double myPolicy) {

		double[] plannedPolicy = new double[capacities.length];
		plannedPolicy[0] = myPolicy;
		
		// figure out if there are any entries before determining investment
		for (int i = 1; i < getNumFirms(); i++) {
			double[] change = new double[capacities.length];
			int[] changeTech = new int[tech.length];
			for (int j = 0; j < capacities.length; j++) {
				change[j] = capacities[j];
				changeTech[j] = tech[j];
			}
			change[0] = capacities[i];
			change[i] = capacities[0];
			changeTech[0] = tech[i];
			changeTech[i] = tech[0];
			if (verbose) {
				System.out.println("swapping out");
			}
			State swap = new State(rng.nextLong(), priceData, baseMarket, productionParameters,
					policyParameters, exitParameters, entryParameters);
			swap.setCapacities(change, changeTech);
			plannedPolicy[i] = swap.getPolicyFirst(i);
		}
		
		if (verbose) {
			System.out.println("--------------- UPDATE STATE " + perturbPolicies + " ---------------");
		}

		// update the state vector
		for (int i = 0; i < getNumFirms(); i++) {
			capacities[i] += plannedPolicy[i];			
		}
		
	}

	public boolean getExit() {
		return exited;
	}

	public void setForceExit(boolean exit) {
		forceExit = exit;
	}
	
	public void setForceEntry(boolean entry) {
		forceEntry = entry;
	}
	
	public void setForceChange(boolean change) {
		forceChange = change;
	}
	
	public void setForceNoChange(boolean nochange) {
		forceNoChange = nochange;
	}
	
	
	public int getNumFirms() {
		return capacities.length;
	}

	public void setCapacities(double[] cap, int[] technologies) {
		capacities = new double[cap.length];
		tech = new int[technologies.length];
		for (int i = 0; i < cap.length; i++) {
			capacities[i] = cap[i];
			tech[i] = technologies[i];
		}
	}

	public double getCapacity(int i) {
		return capacities[i];
	}
	
	public State getDeepCopy() {
		State copy = new State(seed, priceData, baseMarket, productionParameters,
				policyParameters, exitParameters, entryParameters);
		copy.setCapacities(capacities, tech);
		return copy;
	}

	public double getProbabilityInvestment() {
		return probabilityInvestment;
	}

	public double getProbabilityDivestment() {
		return probabilityDivestment;
	}

	public double getProbabilityExit() {
		return probabilityExit;
	}

	public double getProbabilityEntry() {
		return probabilityEntry;
	}

	public void setProbabilityEntry(double entry) {
		probabilityEntry = entry;
	}
	
	public void refreshRNG(long nextLong) {
		rng = new Random(nextLong);
		seed2 = rng.nextLong();
	}

	public double[] getCapacities() {
		return capacities;
	}

	public int[] getTech() {
		return tech;
	}
	
}
