/**
 * demandCurve.java
 *
 * Reads in the data for the demand curve in each market and year.
 * It calls methods to compute the equilibrium price at given quantities. 
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.NumberFormat;
import optimization.Fmin;

public class demandCurve {

	private double[] EPAMarketAggregateElasticity = new double[20];
	private double[] EPAMarketImportElasticity = new double[20];
	private double[] EPAMarketAggregateIntercept = new double[20];
	private double[] EPAMarketImportIntercept = new double[20];

	private double[][] EPAMarketQuantity = new double[20][25];
	private double[][] EPAMarketImports = new double[20][25];
	private double[][] EPAMarketPrices = new double[20][25];
	private double[][] EPAMarketAggregateInterceptYear = new double[20][25];
	private double[][] EPAMarketImportInterceptYear = new double[20][25];

	private String ELAS;
	private String ELAS_IMPORT;

	static private String[] EPAMarketList = { "Atlanta", "Baltimore",
			"Birmingham", "Chicago", "Cincinnati", "Dallas", "Denver",
			"Detroit", "Florida", "KansasCity", "LosAngeles", "Minneapolis",
			"NewYork", "Phoenix", "Pittsburgh", "SaltLakeCity", "SanAntonio",
			"SanFrancisco", "Seattle", "St.Louis" };
	
	public static int[] sizeMarket = {6, 6, 5, 5, 3, 5, 4, 3, 5, 4, 6, 2, 4, 4, 3, 3, 6, 4, 3, 4};
	
    public static double[] maxCapacityMarket = {8204.47, 9520.295, 6439.695, 4860.705, 4759.886,
		9059.3, 4707.865, 6009.211, 6484.955, 6645.19,
		10527.7, 2003.12, 4168.501, 4551.915, 2190, 
		2704.285, 7433.701, 4273.137, 1680.778, 6092.655};
	
	private double[] averagePrice = new double[20];
	private double[] averageQuantity = new double[20];

	public demandCurve(String elas, String elas_import) {
		this.ELAS = elas;
		this.ELAS_IMPORT = elas_import;
	}

	public double getPrice(double quantity, int stateIndex, int year) {

		if (Double.isInfinite(quantity)) {
			return 0;
		}
		if (Double.isNaN(quantity)) {
			System.out.println("Q is NaN");
		}
		if (year == 0) {
			return getPrice(quantity, year);
		}
		int yearIndex = year - 1981;
		DemandObjectiveFunction obj = new DemandObjectiveFunction(quantity,
				EPAMarketAggregateInterceptYear[stateIndex][yearIndex],
				EPAMarketAggregateElasticity[stateIndex],
				EPAMarketImportInterceptYear[stateIndex][yearIndex],
				EPAMarketImportElasticity[stateIndex]);
		return Fmin.fmin(0, 200, obj, 1E-10);
	}

	public double getPrice(double quantity, int stateIndex) {

		if (Double.isInfinite(quantity)) {
			return 0;
		}
		if (Double.isNaN(quantity)) {
			System.out.println("Q is NaN");
		}

		DemandObjectiveFunction obj = new DemandObjectiveFunction(quantity,
				EPAMarketAggregateIntercept[stateIndex],
				EPAMarketAggregateElasticity[stateIndex],
				EPAMarketImportIntercept[stateIndex],
				EPAMarketImportElasticity[stateIndex]);
		return Fmin.fmin(0, 200, obj, 1E-10);
	}


	public double getPricePrime(double qAll, int state) {
		double slope = 0;
		double h = 1.0E-3;
		slope = (getPrice(qAll + h, state) - getPrice(qAll - h, state))
				/ (2.0 * h);
		return slope;
	}

	public double getPricePrime(double qAll, int state, int year) {
		if (year == 0) {
			return getPricePrime(qAll, state);
		}
		double slope = 0;
		double h = 1.0;
		slope = (getPrice(qAll + h, state, year) - getPrice(qAll - h, state,
				year)) / (2.0 * h);
		return slope;
	}
	
	public void initializeMeredithEPA() {
		try {
			String file = "data/regional_list/regionalList_nocustom.raw";
			if (!ELAS.contentEquals("2")) {
				file = "data/regional_list/regionalList_nocustom_" + ELAS + ".raw";
			}
			if (!ELAS_IMPORT.contentEquals("2.5")) {
				file = "data/regional_list/regionalList_nocustom_import_"
						+ ELAS_IMPORT + ".raw";
			}
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine(); // headers
			for (int i = 0; i < 20; i++) {
				line = in.readLine();
				int a = 0;
				int b = line.indexOf(",", a);
				// market name
				System.out.println("\nMarket: " + line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// average price
				System.out.println("Avg Market Price: " + line.substring(a, b));
				averagePrice[i] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// average quantity
				System.out.println("Avg Market Quantity: " + line.substring(a, b));
				averageQuantity[i] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// aggregate elasticity
				System.out.println("Aggregate Elasticity: " + line.substring(a, b));
				EPAMarketAggregateElasticity[i] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// aggregate intercept
				System.out.println("Aggregate Intercept: " + line.substring(a, b));
				EPAMarketAggregateIntercept[i] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// import elasticity
				System.out.println("Import Elasticity: " + line.substring(a, b));
				EPAMarketImportElasticity[i] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// import intercept
				System.out.println("Import Intercept: " + line.substring(a, b));
				EPAMarketImportIntercept[i] = Double.valueOf(line.substring(a, b));
			}
			in.close();

			file = "data/regional_list/regionalList_nocustom_yearly.raw";
			if (!ELAS.contentEquals("2")) {
				file = "data/regional_list/regionalList_nocustom_yearly_" + ELAS + ".raw";
			}
			if (!ELAS_IMPORT.contentEquals("2.5")) {
				file = "data/regional_list/regionalList_nocustom_import_yearly_" + ELAS_IMPORT + ".raw";
			}
			in = new BufferedReader(new FileReader(file));
			line = in.readLine(); // headers
			for (int i = 0; i < 500; i++) {
				line = in.readLine();
				int a = 0;
				int b = line.indexOf(",", a);
				// market name
				System.out.println("\nMarket: " + line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				int market = Integer.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				int year = Integer.valueOf(line.substring(a, b)) - 1981;
				a = b + 1;
				b = line.indexOf(",", a);
				// average price
				System.out.println("Aggregate Q Year: " + line.substring(a, b));
				EPAMarketQuantity[market][year] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// average quantity
				System.out.println("Imports Year: " + line.substring(a, b));
				EPAMarketImports[market][year] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// average quantity
				System.out.println("Price Year: " + line.substring(a, b));
				EPAMarketPrices[market][year] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				b = line.indexOf(",", a);
				// aggregate elasticity
				System.out.println("Aggregate Intercept Year: " + line.substring(a, b));
				EPAMarketAggregateInterceptYear[market][year] = Double.valueOf(line.substring(a, b));
				a = b + 1;
				// aggregate intercept
				System.out.println("Import Intercept Year: " + line.substring(a));
				EPAMarketImportInterceptYear[market][year] = Double.valueOf(line.substring(a));
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		/*
		 * Testing
		 */
		NumberFormat nf = NumberFormat.getInstance();
		System.out.println("******************************** Testing Demand ********************************");
		for (int i = 0; i < 20; i++) {
			System.out.println(String.format("%15s", EPAMarketList[i]) + "\t"
					+ nf.format(averagePrice[i]) + "\t"
					+ nf.format(averageQuantity[i]) + "\t"
					+ nf.format(getPrice(averageQuantity[i], i)) + "\t"
					+ nf.format(EPAMarketAggregateElasticity[i]) + "\t"
					+ nf.format(EPAMarketAggregateIntercept[i]) + "\t"
					+ nf.format(EPAMarketImportElasticity[i]) + "\t"
					+ nf.format(EPAMarketImportIntercept[i]));
		}
		System.out.println("********************************************************************************");

	}

}
