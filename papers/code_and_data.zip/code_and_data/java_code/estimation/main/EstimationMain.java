/**
 * EstimationMain.java
 * 
 * This is the main estimation file. It calls the other programs.
 * It first prepares the data, estimates static parameters, and 
 * finally dynamic parameters.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.main;

import estimation.dataManipulation.PCADataIDProcessor;
import estimation.entry.*;
import estimation.exit.*;
import estimation.production.estimateMarginalCost;
import estimation.simulateW.*;
import estimation.ssrulesLikelihood.*;
import estimation.utility.demandCurve;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Random;


public class EstimationMain {

	public static void main(String[] args) {

		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(5);

		/**
		 * Bootstrapping parameters
		 */
		int thisrun = 0;
		int numBoots = 1;
		if (args.length > 0) {
			thisrun = Integer.valueOf(args[0]);
		}
		if (!EstimationConstants.SUBSAMPLE_PARAMETERS) {
			numBoots = 1;
		}
		if (args.length > 3) {
			numBoots = 1;
			EstimationConstants.ELASTICITY = args[2];
			EstimationConstants.ELASTICITY_IMPORTS = args[3];
		}
		
		boolean prepareData = true;
		boolean firstStageCosts = true;
		boolean firstStageDynamic = true;
		boolean secondStage = true;
		
		/*
		 * Main estimation
		 */
		demandCurve priceData = new demandCurve(EstimationConstants.ELASTICITY, EstimationConstants.ELASTICITY_IMPORTS);
		priceData.initializeMeredithEPA();
		
		// PREPARE DATA --already generated
		if (prepareData) {
			Random rngMaster = new Random(7478);
			for (int r = 0; r < numBoots; r++) {
	
				// get data
				System.out.print("***** Preparing Data *****\n");
				PCADataIDProcessor dataPreparation = new PCADataIDProcessor(rngMaster.nextLong());
				dataPreparation.prepareData(r);
	
			}
		}

		// FIRST STAGE - Marginal Costs
		if (firstStageCosts) {
		
			Jama.Matrix productionCosts = new Jama.Matrix(numBoots, 4);
			
			for (int r = 0; r < numBoots; r++) {

				// returns the parameters mu and mc from the stage game
				System.out.print("\n***** Stage Estimation *****\n");
				estimateMarginalCost stage = new estimateMarginalCost(priceData, r);
				double[] estimatedCosts = stage.getParameters();
				for (int i = 0; i < estimatedCosts.length - 1; i++) {
					productionCosts.set(r, i, estimatedCosts[i + 1]);
				}
				
				// print
				try {
					String file = "data/estimation/mgcost"+r+".csv";
					if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
						file = "data/estimation/mgcost_het_"+r+".csv";
					}
					if (!EstimationConstants.ELASTICITY.contentEquals("2")) {
						file = "data/estimation/mgcost"+r+"_elasticity_"+args[2]+".csv";
					}
					if (!EstimationConstants.ELASTICITY_IMPORTS.contentEquals("2.5")) {
						file = "data/estimation/mgcost"+r+"_imports_"+args[3]+".csv";
					}
					BufferedWriter outMg = new BufferedWriter(new FileWriter(file));
					for (int j = 0; j < productionCosts.getColumnDimension(); j++) {
						outMg.write(productionCosts.get(r,j)+",");
					}
					outMg.write("\n");					
					outMg.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
		}
		

		// FIRST STAGE - Dynamic Costs		
		if (firstStageDynamic) {

			Jama.Matrix exitPolicy = new Jama.Matrix(numBoots, 3);
			Jama.Matrix entryPolicy = new Jama.Matrix(numBoots, 2);
			Jama.Matrix investmentPolicy = new Jama.Matrix(numBoots, 9); // 3+1 and 4+1
			
			for (int r = 0; r < numBoots; r++) {
				
				// (s,S) rule policy estimation
				System.out.print("\n***** Policy Estimation *****\n");
				ssrulesMain policy = new ssrulesMain(r);
				Jama.Matrix estimatedBand = policy.getParameters().getBetaBand();
				Jama.Matrix estimatedTarget = policy.getParameters().getBetaTarget();
				for (int i = 0; i < estimatedBand.getRowDimension(); i++) {
					investmentPolicy.set(r, i, estimatedBand.get(i,0));
				}
				investmentPolicy.set(r, estimatedBand.getRowDimension(), policy.getParameters().getVarianceBandEquation());
				for (int i = 0; i < estimatedTarget.getRowDimension(); i++) {
					investmentPolicy.set(r, estimatedBand.getRowDimension() + 1 + i, estimatedTarget.get(i,0));
				}
				investmentPolicy.set(r, estimatedBand.getRowDimension() + estimatedTarget.getRowDimension() + 1, 
										policy.getParameters().getVarianceTargetEquation());

				// exit and entry policy functions
				System.out.println("Estimating exit policy");
				estimateExitPolicy exit = new estimateExitPolicy(r);
				exit.execute();
				double[] estimatedExit = exit.getExitParameters();
				for (int i = 0; i < estimatedExit.length-1; i++) {
					exitPolicy.set(r, i, estimatedExit[i+1]);
				}
				
				System.out.println("Estimating entry policy");
				estimateEntryPolicy entry = new estimateEntryPolicy(r);
				entry.execute();
				double[] estimatedEntry = entry.getEntryParameters();
				for (int i = 0; i < estimatedEntry.length-1; i++) {
					entryPolicy.set(r, i, estimatedEntry[i+1]);
				}
				
				// print
				try {
					BufferedWriter outInv = new BufferedWriter(new FileWriter("data/estimation/investmentParams"+r+".csv"));
					BufferedWriter outExit = new BufferedWriter(new FileWriter("data/estimation/exitParams"+r+".csv"));
					BufferedWriter outEntry = new BufferedWriter(new FileWriter("data/estimation/entryParams"+r+".csv"));
					for (int j = 0; j < investmentPolicy.getColumnDimension(); j++) {
						outInv.write(investmentPolicy.get(r,j)+",");
					}
					outInv.write("\n");					
					for (int j = 0; j < exitPolicy.getColumnDimension(); j++) {
						outExit.write(exitPolicy.get(r,j)+",");
					}
					outExit.write("\n");
					
					for (int j = 0; j < entryPolicy.getColumnDimension(); j++) {
						outEntry.write(entryPolicy.get(r,j)+",");
					}
					outEntry.write("\n");
										
					outInv.close();
					outExit.close();
					outEntry.close();
				} catch (Exception e) {
					e.printStackTrace();
				}				
				
			}
		
		}

		
		// SECOND STAGE - Dynamic Parameter Estimation
		// needs the other parameters in the profit function to calculate profits
		// and policy to determine the transition between states
		if (secondStage) {

			Random rngMaster = new Random(12345);
			long draw = rngMaster.nextLong();
			
			double beta = 0.9;
			if (args.length > 1) {
				beta = Double.valueOf(args[1]);
			}			
			
			for (int r = 0; r < 100; r++) {
				draw = rngMaster.nextLong();
				if (r == thisrun) {
					// read parameters from first stage estimation
					double[] estimatedCosts = readMgParam(r);
					investmentParametersContainer policy = readInvParam(r);
					double[] exit = readExitParam(r);
					double[] entry = readEntryParam(r);
					try {
						String filename = "data/estimation/dynamicParams"+r+".csv";
						if (beta != 0.9) {
							filename = "data/estimation/dynamicParams_beta_"+beta+".csv";
							EstimationConstants.DISCOUNT_FACTOR = beta;
						}
						if (!EstimationConstants.ELASTICITY.contentEquals("2")) {
							filename = "data/estimation/dynamicParams_elasticity_"+args[2]+".csv";
						}
						if (!EstimationConstants.ELASTICITY_IMPORTS.contentEquals("2.5")) {
							filename = "data/estimation/dynamicParams_imports_"+args[3]+".csv";
						}
						BufferedWriter outDynamic = new BufferedWriter(new FileWriter(filename));

						System.out.print("\n***** Dynamic Parameter Estimation *****\n");
						simulateW dynamic = new simulateW(draw, r, 
								priceData, EstimationConstants.BASE_MARKET, estimatedCosts, policy, exit, entry);
						System.out.println("Estimation finished.");

						// print
						double[] dynamicParametersResultD = dynamic.getEstimatesD();

						outDynamic.write("dtwostep,");
						for (int j = 0; j < dynamicParametersResultD.length; j++) {
							outDynamic.write(dynamicParametersResultD[j]+",");
						}
						outDynamic.write("\n");
						outDynamic.close();
					} catch (Exception e) {
						e.printStackTrace();
					}

				}	
			}

		}

	}

	private static double[] readEntryParam(int r) {
		
		String csvFile = "data/estimation/entryParams"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] entry = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				entry = new double[read.length+1];
				for (int i = 0; i < read.length; i++) {
					entry[i+1] = Double.valueOf(read[i]);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return entry;
		
	}

	private static double[] readExitParam(int r) {

		String csvFile = "data/estimation/exitParams"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] exit = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				exit = new double[read.length+1];
				for (int i = 0; i < read.length; i++) {
					exit[i+1] = Double.valueOf(read[i]);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return exit;
		
	}

	private static investmentParametersContainer readInvParam(int r) {
		
		String csvFile = "data/estimation/investmentParams"+r+".csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] invest = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				invest = new double[read.length];
				for (int i = 0; i < read.length; i++) {
					invest[i] = Double.valueOf(read[i]);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Jama.Matrix band = new Jama.Matrix(3,1);
		for (int i = 0; i < 3; i++) {
			band.set(i, 0, invest[i]);
		}
		double varband = invest[3];
		Jama.Matrix target = new Jama.Matrix(4,1);
		for (int i = 0; i < 4; i++) {
			target.set(i, 0, invest[4+i]);
		}		
		double vartarget = invest[8];

		investmentParametersContainer policy = new investmentParametersContainer(band,target,varband,vartarget);
		return policy;
		
	}

	private static double[] readMgParam(int r) {

		String csvFile = "data/estimation/mgcost"+r+".csv";
		if (!EstimationConstants.ELASTICITY.contentEquals("2")) {
			csvFile = "data/estimation/mgcost"+r+"_elasticity_"+EstimationConstants.ELASTICITY+".csv";
		}
		if (!EstimationConstants.ELASTICITY_IMPORTS.contentEquals("2.5")) {
			csvFile = "data/estimation/mgcost"+r+"_imports_"+EstimationConstants.ELASTICITY_IMPORTS+".csv";
		}
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		double[] mgcost = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {			        
				String[] read = line.split(cvsSplitBy);
				mgcost = new double[read.length + 1];
				for (int i = 0; i < read.length; i++) {
					mgcost[i + 1] = Double.valueOf(read[i]);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mgcost;
		
	}

}
