/**
 * EstimationConstants.java
 *
 * This file sets some important parameters for the estimation. 
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.main;

public class EstimationConstants {


	public static double DISCOUNT_FACTOR = 0.9; // positive discount rate for
												// future periods
	public static int NUM_THREADS = 20; // for parallel computing

	public static double INVESTMENT_CUTOFF_LEVEL = 0.1; // to clean measurment error
	public static boolean SUBSAMPLE_PARAMETERS = false;
	
	public static double MIN_CAPACITY = 200.0; // 0.10
	public static double MAX_CAPACITY = 3500.0;	

	/**
	 * Elasticities to read demand files
	 */
	public static String ELASTICITY = "2";
	public static String ELASTICITY_IMPORTS = "2.5";

	/**
	 * Dynamic settings
	 */
	// 2nd-stage simulation parameters
	public static int BASE_YEAR = 2000;
	public static int BASE_MARKET = 20;
	public static int NUM_SIMW = 200;
	public static int NUM_SIMW_ITER = 1;
	public static int NUM_SIMWTASK = 1000;
	
	// estimation options
	public static boolean DEV_SQUARE = true;
	public static boolean DIVESTMENT_ZERO = true;
	public static boolean NO_QUADRATIC_COSTS = true;
	public static boolean ADJUST_EQUAL = true;
	
	public static boolean BAND = true;
	public static boolean DIVEST_UPON_EXIT = true;
	public static boolean NON_ZERO_DEVS = true;
	public static boolean EXIT_DEVS = true;
	public static boolean FORCE_DEVS = false;
	public static boolean POSITIVE_ADJ_COST = true;
	public static boolean SET_ONE_OUT = false;
	public static double  SHOCK_DEV = 150.0;
	
	public static boolean PROFIT_APPROX = true;
	public static double ROUND = 50.0;

	/**
	 * Years to use data
	 */
	public static int START_YEAR = 1981; // MINIMUM YEAR IS *1981*
	public static int END_YEAR = 2005; // 2005; // 1998;
	/*
	 * Production technology types
	 */
	public static boolean DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC = false;
	public static int TECH_DRY = 1;
	public static int TECH_DRY_C = 2;
	public static int TECH_DRY_X = 3;
	public static int TECH_WET = 4;

}
