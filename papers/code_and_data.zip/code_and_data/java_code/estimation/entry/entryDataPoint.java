/**
 * entryDataPoint.java
* 
 * This function returns the likelihood function for the
 * estimation of entry parameters.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.entry;

import JSci.maths.statistics.NormalDistribution;

public class entryDataPoint {

	private boolean entry;
	private double marketCapacity;
	static NormalDistribution standardNormal = new NormalDistribution();

	public entryDataPoint(boolean entry, double marketCapacity) {
		this.entry = entry;
		this.marketCapacity = marketCapacity;
	}

	public double getLikelihood(double[] x) {
		if (entry) {
			return standardNormal.cumulative(x[1] + x[2] * marketCapacity);			
		} else {
			return 1.0 - standardNormal.cumulative(x[1] + x[2]	* marketCapacity);
		}
	}
}
