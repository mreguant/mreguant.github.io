/**
 * PCADataIDProcessor.java
 * 
 * This function processes the PCA id files provided in the
 * data folder and output the information in data sets that are
 * ready for the estimation.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.dataManipulation;

import estimation.main.EstimationConstants;

import java.io.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.TreeSet;

public class PCADataIDProcessor {

	private ArrayList<String> firmIDYearList = new ArrayList<String>();
	private ArrayList<plantRecordID> plantRecordIDList = new ArrayList<plantRecordID>();
	private Random rng;

	public PCADataIDProcessor(long seed) {
		rng = new Random(seed);
	}

	public void prepareData(int sim) {
		TreeSet<String> marketList = new TreeSet<String>();
		try {
			for (int dataYear = EstimationConstants.START_YEAR; dataYear <= EstimationConstants.END_YEAR; dataYear++) {
				TreeSet<String> stateSet = new TreeSet<String>();
				TreeSet<Integer> plantIDSet = new TreeSet<Integer>();

				BufferedReader in = new BufferedReader(new FileReader(new File(
						"data/pcaID/pca" + dataYear + "_id.csv")));
				// headers
				String line = in.readLine();
				System.out.println("Processing: " + dataYear);

				line = in.readLine();
				while (line != null) {
					if (line != null) {
						// System.out.println(line);
						int a = 0;
						int b = line.indexOf(",");
						// company,plantlocation,state,zipcode,numberkilns,finishgrindingcapacity,year,fuel,Process,ClinkerCapacityTonsDay,ClinkerCapacityTonsYear,id
						String companyName = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						// in later years, sometimes have a ", Inc." which
						// throws off the counter
						// just update one step, and we should be OK
						if (line.contains(", Inc.") || line.contains(", Ltd.")
								|| line.contains(", L.P.")) {
							a = b + 1;
							b = line.indexOf(",", a);
						}

						String plantLocation = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						String state = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						String zipCode = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						int numKilns = new Integer(cleanString(line.substring(a, b)));
						a = b + 1;
						b = line.indexOf(",", a);

						double grindingCapacity = new Double(cleanString(line.substring(a, b)));
						a = b + 1;
						b = line.indexOf(",", a);

						int yearKilnBuilt = new Integer(cleanString(line.substring(a, b)));
						a = b + 1;
						b = line.indexOf(",", a);

						String fuel = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						String process = cleanString(line.substring(a, b));
						a = b + 1;
						b = line.indexOf(",", a);

						double clinkerCapacityTonsPerDay = new Double(cleanString(line.substring(a, b)));
						a = b + 1;
						b = line.indexOf(",", a);

						double clinkerCapacityTonsPerYear = new Double(cleanString(line.substring(a, b)));
						a = b + 1;
						b = line.indexOf(",", a);

						int id = new Integer(cleanString(line.substring(a)));
						// System.out.println(companyName + " " + id);

						if (firmIDYearList.contains(id + "/" + dataYear)) {
							// System.out.println("Existing");
							plantRecordID p = plantRecordIDList.get(firmIDYearList.indexOf(id + "/" + dataYear));
							kilnData nextKiln = new kilnData(dataYear,yearKilnBuilt, fuel, process,
									clinkerCapacityTonsPerDay,clinkerCapacityTonsPerYear);
							p.addKiln(nextKiln);
						} else {
							if (clinkerCapacityTonsPerDay > 0) {
								plantRecordIDList.add(new plantRecordID(companyName,plantLocation,
												state, Integer.valueOf(state),zipCode,numKilns,grindingCapacity,
												new kilnData(dataYear,yearKilnBuilt,fuel,process,
														clinkerCapacityTonsPerDay,
														clinkerCapacityTonsPerYear),id));
								firmIDYearList.add(id + "/" + dataYear);
							} else {
								System.out.println("\tDiscarding "+ companyName + " at "
												+ plantLocation + " in "
												+ state	+ " with a clinker capacity of "
												+ clinkerCapacityTonsPerDay
												+ " tpd for not belonging to an EPA market or not having positive capacity.");
							}
						}
						if (!state.equalsIgnoreCase("-1")) {
							stateSet.add(state);
							marketList.add(state);
						}
						plantIDSet.add(id);

						line = in.readLine();
					}
				}

				in.close();
				System.out.print(dataYear + " markets: " + stateSet.size()
						+ " plants: " + plantIDSet.size() + "\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("marketList contains:");
		for (String s : marketList) {
			System.out.print(s + " ");
		}
		System.out.println();
		// System.exit(0);

		/**
		 * Tabulate market-wide capacities and quantities for each market in
		 * each year.
		 * 
		 */
		NumberFormat nf = NumberFormat.getInstance();
		boolean firstDebug = false;

		/**
		 * Add in competitor capacities and quantities
		 */
		for (int year = EstimationConstants.START_YEAR; year <= EstimationConstants.END_YEAR; year++) {
			for (plantRecordID p1 : plantRecordIDList) {
				int numberFirms = 1;
				ArrayList<Double> marketCapacities = new ArrayList<Double>();
				ArrayList<Double> marketQuantities = new ArrayList<Double>();
				ArrayList<Integer> marketTechnologies = new ArrayList<Integer>();
				marketQuantities.add(p1.getPlantQuantityProduced());
				marketCapacities.add(p1.getPlantCapacity());
				marketTechnologies.add(p1.getTechnologyType());
				if (p1.getYear() == year) {
					double competitorsCapacity = 0;
					double competitorsQuantity = 0;
					for (plantRecordID p2 : plantRecordIDList) {
						if (p2.getYear() == year) {
							if (firstDebug) {
								System.out.println(p1.getPlantID() + "\t" + p2.getPlantID());
							}
							if (p1.getPlantID() != p2.getPlantID()) {
								if (firstDebug) {
									System.out.println(p1.getYear() + "\t" + p2.getYear());
								}
								if (firstDebug) {
									System.out.println(p1.getBootstrapId() + "\t" + p2.getBootstrapId());
								}
								/**
								 * Grouping firms based on State and year
								 */
								if (p1.getBootstrapId().equals(p2.getBootstrapId())) {
									if (firstDebug) {
										System.out.println("Adding capacity: "
											+ p2.getPlantCapacity() + " quantity: "
											+ p2.getPlantQuantityProduced());
									}
									competitorsQuantity += p2.getPlantQuantityProduced();
									competitorsCapacity += p2.getPlantCapacity();
									numberFirms++;
									marketQuantities.add(p2.getPlantQuantityProduced());
									marketCapacities.add(p2.getPlantCapacity());
									marketTechnologies.add(p2.getTechnologyType());
								}
							}
						}
					}
					System.out.println(year + "\t" + p1.getBootstrapId() + "\t"
							+ p1.getZipCode() + "\t" + p1.getPlantID() + "\t"
							+ nf.format(competitorsCapacity) + "\t"
							+ nf.format(competitorsQuantity));
					p1.setCompetitorsCapacity(competitorsCapacity);
					p1.setCompetitorsQuantity(competitorsQuantity);
					p1.setNumFirms(numberFirms);
					p1.setMarketCapacities(marketCapacities);
					p1.setMarketQuantities(marketQuantities);
					p1.setMarketTechnologies(marketTechnologies);
				}
				firstDebug = false;
			}
		}

		/**
		 * Select markets for subsampling
		 */
		Collections.sort(plantRecordIDList);

		ArrayList<String> bootMarketNames = new ArrayList<String>(marketList);
		if (sim != 0 && EstimationConstants.SUBSAMPLE_PARAMETERS) {
			ArrayList<plantRecordID> subsampleList = new ArrayList<plantRecordID>();
			ArrayList<String> marketNameList = new ArrayList<String>(marketList);
			// draw with replacement the n-out-n bootstrap
			for (int i = 0; i < marketNameList.size(); i++) {
				int index = (int) Math.floor(marketNameList.size() * rng.nextDouble());
				for (plantRecordID p : plantRecordIDList) {
					if (p.getMarketIndex()==index) {
						plantRecordID q = p.deepCopy();
						q.setBootstrapId(index+"_"+i);
						q.setPlantID(p.getPlantID()*100 + i);
						subsampleList.add(q);
					}
				}
			}
			System.out.println(".");
			plantRecordIDList = subsampleList;
		}
		Collections.sort(bootMarketNames);

		System.out.print("Writing estimation data...");
		try {
			String filename = "data/estimation/dataEstimation"+sim+".dat";
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(new File(filename)));
			out.writeObject(new Integer(plantRecordIDList.size()));
			for (int i = 0; i < plantRecordIDList.size(); i++) {
				out.writeObject(plantRecordIDList.get(i));
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("done.");
	}

	/**
	 * Remove quotation marks from string (leading and trailing)
	 * 
	 */
	private String cleanString(String s) {
		String processed = "";
		for (int i = 0; i < s.length(); i++) {
			if (!s.substring(i, i + 1).equals("\"")) {
				processed = processed.concat(s.substring(i, i + 1));
			}
		}

		if (processed.length() == 0) {
			processed = "-1";
		}

		if (processed.contains("Exited")) {
			processed = "-1";
		}
		if (processed.contains("Changed to grinding only")) {
			processed = "-1";
		}
		return processed;
	}
	
}
