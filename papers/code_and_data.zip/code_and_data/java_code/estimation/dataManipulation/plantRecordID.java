/**
 * plantRecordID.java
 * 
 * This function creates a record for a given plant.
 * Each plant can contain several kilns, so it aggregates up
 * the kiln data at the plant level.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.dataManipulation;

import Jama.Matrix;

import java.io.Serializable;
import java.util.ArrayList;

public class plantRecordID implements Serializable, Comparable<plantRecordID> {

	// company,plantlocation,state,zipcode,numberkilns,finishgrindingcapacity,year,fuel,Process,ClinkerCapacityTonsDay,ClinkerCapacityTonsYear,id,year
	private String companyName;
	private String plantLocation;
	private String bootstrapId;
	private String zipCode;
	private int numberKilns;
	private double finishGridingCapacity;
	private ArrayList<kilnData> kilnList = new ArrayList<kilnData>();
	private double plantDailyCapacity = 0;
	private double plantAnnualCapacity = 0;
	private int plantID;
	private int minYear;
	private int maxYear;
	private int year;
	private double competitorsCapacity = 0;
	private double competitorsQuantity = 0;
	private int numFirms;
	private int marketIndex;
	private ArrayList<Double> marketCapacities;
	private ArrayList<Double> marketQuantities;
	private ArrayList<Integer> marketTechnologies;
	private int technologyType;

	public plantRecordID(String companyName, String plantLocation,
			String bootId, int market, String zipCode, int numberKilns,
			double finishGridingCapacity, kilnData firstKiln, int plantID) {
		this.companyName = companyName;
		this.plantLocation = plantLocation;
		this.bootstrapId = bootId;
		this.zipCode = zipCode;
		this.numberKilns = numberKilns;
		this.finishGridingCapacity = finishGridingCapacity;
		this.plantID = plantID;
		kilnList.add(firstKiln);
		plantDailyCapacity += firstKiln.getClinkerCapacityTonsDay();
		plantAnnualCapacity += firstKiln.getClinkerCapacityTonsYear();
		minYear = firstKiln.getDataYear();
		maxYear = firstKiln.getDataYear();
		this.year = firstKiln.getDataYear();
		this.technologyType = firstKiln.getTechnologyType();
		this.marketIndex = Integer.valueOf(market);
	}

	public plantRecordID deepCopy() {
		plantRecordID copy = new plantRecordID(companyName, plantLocation,
				bootstrapId, marketIndex, zipCode, numberKilns, finishGridingCapacity,
				kilnList.get(0), getPlantID());
		for (int k = 1; k < kilnList.size(); k++) {
			copy.addKiln(kilnList.get(k));
		}
		copy.setPlantAnnualCapacity(plantAnnualCapacity);
		copy.setPlantDailyCapacity(plantDailyCapacity);
		copy.setCompetitorsCapacity(competitorsCapacity);
		copy.setCompetitorsQuantity(competitorsQuantity);
		copy.setMinYear(minYear);
		copy.setMaxYear(maxYear);
		copy.setYear(year);
		copy.setTechnologyType(technologyType);
		copy.setMarketIndex(marketIndex);
		copy.setMarketCapacities(new ArrayList<Double>(marketCapacities));
		copy.setMarketQuantities(new ArrayList<Double>(marketQuantities));
		copy.setMarketTechnologies(new ArrayList<Integer>(marketTechnologies));
		copy.setNumFirms(numFirms);
		copy.setBootstrapId(bootstrapId);
		copy.setPlantID(plantID);
		return copy;
	}

	public double getCapacity(int index) {
		return marketCapacities.get(index);
	}

	public double getQuantity(int index) {
		return marketQuantities.get(index);
	}

	public double getMarketQ() {
		return competitorsQuantity + plantAnnualCapacity;
	}

	public void setCompetitorsCapacity(double competitorsCapacity) {
		this.competitorsCapacity = competitorsCapacity;
	}

	public void setCompetitorsQuantity(double competitorsQuantity) {
		this.competitorsQuantity = competitorsQuantity;
	}

	public double getCompetitorsCapacity() {
		return competitorsCapacity;
	}

	public double getCompetitorsQuantity() {
		return competitorsQuantity;
	}

	public String toStringEntryExit() {
		double investment = 0;
		double marketQ = 0;
		return getPlantID() + "," + companyName + "," + marketIndex + ","
				+ bootstrapId + "," + year + ","
				+ plantDailyCapacity + "," + numFirms + "," + investment + ","
				+ marketQ + "," + getPlantQuantityProduced() + ","
				+ getCompetitorsCapacity();
	}

	@Override
	public String toString() {
		return year + "," + getPlantID() + "," + companyName + ","
				+ plantLocation + "," + bootstrapId + "," + zipCode + ","
				+ numberKilns + "," + finishGridingCapacity + ","
				+ getPlantCapacity() + "," + getPlantQuantityProduced();
	}

	public void addKiln(kilnData nextKiln) {
		kilnList.add(nextKiln);
		setPlantDailyCapacity(getPlantCapacity()
				+ nextKiln.getClinkerCapacityTonsDay());
		setPlantAnnualCapacity(getPlantQuantityProduced()
				+ nextKiln.getClinkerCapacityTonsYear());
		if (nextKiln.getDataYear() < getMinYear()) {
			setMinYear(nextKiln.getDataYear());
		}
		if (nextKiln.getDataYear() > getMaxYear()) {
			setMaxYear(nextKiln.getDataYear());
		}
	}

	public int getYear() {
		return year;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @return the plantLocation
	 */
	public String getPlantLocation() {
		return plantLocation;
	}

	/**
	 * @return the state
	 */
	public String getBootstrapId() {
		return bootstrapId;
	}
	
	/**
	 * @return the state
	 */
	public void setBootstrapId(String id) {
		this.bootstrapId = id;
	}
	
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @return the numberKilns
	 */
	public int getNumberKilns() {
		return numberKilns;
	}

	/**
	 * @return the finishGridingCapacity
	 */
	public double getFinishGridingCapacity() {
		return finishGridingCapacity;
	}

	/**
	 * Plant's capacity.
	 * 
	 * @return the plantDailyCapacity
	 */
	public double getPlantCapacity() {
		return plantDailyCapacity;
	}

	/**
	 * Plant's production.
	 * 
	 * @return the plantAnnualCapacity
	 */
	public double getPlantQuantityProduced() {
		return plantAnnualCapacity;
	}

	public double getPlantCapacityPerKiln() {
		return getPlantCapacity() / kilnList.size();
	}

	public double getPlantQuantityProducedPerKiln() {
		return getPlantQuantityProduced() / kilnList.size();
	}

	/**
	 * @return the plantID
	 */
	public int getPlantID() {
		return plantID;
	}

	public int getMinimumYear() {
		return getMinYear();
	}

	public int getMaximumYear() {
		return getMaxYear();
	}

	@Override
	public int compareTo(plantRecordID comp) {
		int c = -1 * comp.getBootstrapId().compareTo(getBootstrapId());
		if (c == 0) {
			if (comp.getYear() < getYear()) {
				return 1;
			}
			if (comp.getYear() > getYear()) {
				return -1;
			}
			return 0;
		} else {
			return c;
		}
	}

	/**
	 * @param plantID
	 *            the plantID to set
	 */
	public void setPlantID(int plantID) {
		this.plantID = plantID;
	}

	/**
	 * @return the minYear
	 */
	public int getMinYear() {
		return minYear;
	}

	/**
	 * @param minYear
	 *            the minYear to set
	 */
	public void setMinYear(int minYear) {
		this.minYear = minYear;
	}

	/**
	 * @return the maxYear
	 */
	public int getMaxYear() {
		return maxYear;
	}

	/**
	 * @param maxYear
	 *            the maxYear to set
	 */
	public void setMaxYear(int maxYear) {
		this.maxYear = maxYear;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * @param plantDailyCapacity
	 *            the plantDailyCapacity to set
	 */
	public void setPlantDailyCapacity(double plantDailyCapacity) {
		this.plantDailyCapacity = plantDailyCapacity;
	}

	/**
	 * @param plantAnnualCapacity
	 *            the plantAnnualCapacity to set
	 */
	public void setPlantAnnualCapacity(double plantAnnualCapacity) {
		this.plantAnnualCapacity = plantAnnualCapacity;
	}

	/**
	 * @return the numFirms
	 */
	public int getNumFirms() {
		return numFirms;
	}

	/**
	 * @param numFirms
	 *            the numFirms to set
	 */
	public void setNumFirms(int numFirms) {
		this.numFirms = numFirms;
	}

	/**
	 * @return the marketIndex
	 */
	public int getMarketIndex() {
		return marketIndex;
	}

	/**
	 * @param marketIndex to set
	 */
	public void setMarketIndex(int marketIndex) {
		this.marketIndex = marketIndex;
	}

	/**
	 * @return the marketCapacities
	 */
	public ArrayList<Double> getMarketCapacities() {
		return marketCapacities;
	}

	/**
	 * @param marketCapacities
	 *            the marketCapacities to set
	 */
	public void setMarketCapacities(ArrayList<Double> marketCapacities) {
		this.marketCapacities = marketCapacities;
	}

	/**
	 * @return the marketQuantities
	 */
	public ArrayList<Double> getMarketQuantities() {
		return marketQuantities;
	}

	/**
	 * @param marketQuantities
	 *            the marketQuantities to set
	 */
	public void setMarketQuantities(ArrayList<Double> marketQuantities) {
		this.marketQuantities = marketQuantities;
	}

	public Matrix getMarketQuantityVector() {
		Jama.Matrix marketQuantityVector = new Jama.Matrix(numFirms, 1);
		marketQuantityVector.set(0, 0, plantAnnualCapacity);
		for (int i = 1; i < numFirms; i++) {
			marketQuantityVector.set(i, 0, marketQuantities.get(i));
		}
		return marketQuantityVector;
	}

	public Matrix getMarketCapacityMatrix() {
		Jama.Matrix marketQuantityVector = new Jama.Matrix(numFirms, 1);
		marketQuantityVector.set(0, 0, plantDailyCapacity);
		for (int i = 1; i < numFirms; i++) {
			marketQuantityVector.set(i, 0, marketCapacities.get(i));
		}
		return marketQuantityVector;
	}

	public int[] getMarketTechnologyArray() {
		int[] technologyArray = new int[numFirms];
		technologyArray[0] = technologyType;
		for (int i = 1; i < numFirms; i++) {
			technologyArray[i] = marketTechnologies.get(i);
		}
		return technologyArray;
	}

	/**
	 * @return the technologyType
	 */
	public int getTechnologyType() {
		return technologyType;
	}

	/**
	 * @param technologyType
	 *            the technologyType to set
	 */
	public void setTechnologyType(int technologyType) {
		this.technologyType = technologyType;
	}

	/**
	 * @return the marketTechnologies
	 */
	public ArrayList<Integer> getMarketTechnologies() {
		return marketTechnologies;
	}

	/**
	 * @param marketTechnologies
	 *            the marketTechnologies to set
	 */
	public void setMarketTechnologies(ArrayList<Integer> marketTechnologies) {
		this.marketTechnologies = marketTechnologies;
	}
}
