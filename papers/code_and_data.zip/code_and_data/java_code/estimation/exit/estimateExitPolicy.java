/**
 * estimateExitPolicy.java
 * 
 * This function performs the estimation of exit parameters 
 * by minimizing the Normal likelihood function.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.exit;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import estimation.utility.demandCurve;
import optimization.Uncmin_f77;
import optimization.Uncmin_methods;
import utility.pmUtility;


public class estimateExitPolicy implements Uncmin_methods {

	ArrayList<exitDataPoint> data = new ArrayList<exitDataPoint>();
	private double[] exitParameters;
	private int sim;
	
	public estimateExitPolicy(int simnum) {
		sim = simnum;
	}

	public void execute() {
		prepareData();

		double[] guess = { 0, 2.0, -1.0, 1.0 };

		int numParams = 3;
		Uncmin_f77 minimizer = new Uncmin_f77(false);

		double[] xpls = new double[numParams + 1];
		double[] fpls = new double[2];
		double[] gpls = new double[numParams + 1];
		int[] itrmcd = new int[2];
		double[][] a = new double[numParams + 1][numParams + 1];
		double[] udiag = new double[numParams + 1];
		double[] typsiz = new double[numParams + 1];
		double[] fscale = { 0, 1E-16 };
		int[] method = { 0, 1 };
		int[] iexp = { 0, 0 };
		int[] msg = { 0, 1 };
		int[] ndigit = { 0, 15 };
		int[] itnlim = { 0, 150 };
		int[] iagflg = { 0, 0 };
		int[] iahflg = { 0, 0 };
		double[] dlt = { 0, 1 };
		double[] gradtl = { 0, 1E-8 };
		double[] stepmx = { 0, 1E8 };
		double[] steptl = { 0, 1E-8 };

		pmUtility.prettyPrint(new Jama.Matrix(guess, 1));
		minimizer.optif9_f77(numParams, guess, this, typsiz, fscale, method,
				iexp, msg, ndigit, itnlim, iagflg, iahflg, dlt, gradtl, stepmx,
				steptl, xpls, fpls, gpls, itrmcd, a, udiag);
		pmUtility.prettyPrint(new Jama.Matrix(guess, 1));

		System.out.println("**** Estimated Exit Policy ****");
		String[] names = { "Intercept", "Own Capacity",	"Competitor's Capacity" };
		for (int i = 1; i < guess.length; i++) {
			System.out.println("\t" + names[i - 1] + "\t" + guess[i]);
		}

		setExitParameters(new double[4]);
		System.arraycopy(guess, 0, getExitParameters(), 0, 4);
	}

	@Override
	public double f_to_minimize(double[] x) {
		boolean imposeSignRestrictions = false;
		if (imposeSignRestrictions) {
			x[2] = Math.min(0, x[2]); // own capacity
			x[3] = Math.max(0, x[3]); // competitor's capacity
		}
		double llh = 0;
		for (exitDataPoint p : data) {
			llh -= Math.log(p.getLikelihood(x));
		}
		return llh;
	}

	@Override
	public void gradient(double[] x, double[] g) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void hessian(double[] x, double[][] h) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	private void prepareData() {
		try {
			BufferedReader in = new BufferedReader(new FileReader("data/estimation/exit"+sim+".csv"));
			String line = in.readLine(); // headers
			line = in.readLine(); // first line of data
			while (line != null) {
				if (line != null) {
					// exit,id,name,state,annualCapacity,year,quantity,numFirms,investment,shock,marketQ,dailyCapacity,getCapOtherDouble
					int a = 0;
					int b = line.indexOf(",", a);
					boolean exit = false;
					if (line.substring(a, b).contentEquals("1")) {
						exit = true;
					}
					a = b + 1;
					b = line.indexOf(",", a);
					// id here
					a = b + 1;
					b = line.indexOf(",", a);
					// name
					//String name = line.substring(a, b);
					a = b + 1;
					b = line.indexOf(",", a);
					int market = new Integer(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					a = b + 1;
					b = line.indexOf(",", a);
					//int year = new Integer(line.substring(a, b));
					a = b + 1;
					b = line.indexOf(",", a);
					double ownCapacity = new Double(line.substring(a, b));
					// capacity
					a = b + 1;
					b = line.indexOf(",", a);
					// numFirms
					a = b + 1;
					b = line.indexOf(",", a);
					// investment
					a = b + 1;
					b = line.indexOf(",", a);
					// marketq
					a = b + 1;
					b = line.indexOf(",", a);
					// dailycapacity
					a = b + 1;
					b = line.indexOf(",", a);
					double competitorCapacity = new Double(line.substring(a))/demandCurve.maxCapacityMarket[market];					
					data.add(new exitDataPoint(exit, ownCapacity, competitorCapacity));
					line = in.readLine();
				}
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @return the exitParameters
	 */
	public double[] getExitParameters() {
		return exitParameters;
	}

	/**
	 * @param exitParameters
	 *            the exitParameters to set
	 */
	public void setExitParameters(double[] exitParameters) {
		this.exitParameters = exitParameters;
	}
}
