/**
 * estimateMarginalCost.java
 *
 * This file estimates the marginal costs of the production function,
 * which are estimated based on static moments of the stage game.
 * The program calls CournotTask.java at each data point to calculate
 * the sum of squares of the objective function.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.production;

import estimation.dataManipulation.plantRecordID;
import estimation.main.EstimationConstants;
import estimation.utility.demandCurve;

import java.io.*;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import optimization.Uncmin_methods;
import simulation.solve.gibbsLTEGeneralized;
import utility.pmUtility;

public class estimateMarginalCost implements Uncmin_methods, simulation.solve.mcmcFunction {

	private int numParameters = 3;
	private double[] bestStart;
	private ArrayList<plantRecordID> dataMaster = new ArrayList<plantRecordID>();
	private ArrayList<plantRecordID> data = new ArrayList<plantRecordID>();
	private double[] stageGameParameters;
	private ExecutorService tpes;
	private demandCurve priceData;

	/**
	 * Creates a new instance of stageGameCED
	 */
	public estimateMarginalCost(demandCurve priceData, int sim) {
		this.priceData = priceData;
		tpes = Executors.newFixedThreadPool(EstimationConstants.NUM_THREADS);
		if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
			numParameters = 4;
		}

		stageGameParameters = new double[numParameters + 1];
		bestStart = new double[numParameters + 1];

		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(
					new File("data/estimation/dataEstimation"+sim+".dat")));
			int numObs = (Integer) in.readObject();

			for (int i = 0; i < numObs; i++) {
				dataMaster.add((plantRecordID) in.readObject());
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		data = new ArrayList<plantRecordID>();
		TreeSet<String> tree = new TreeSet<String>();
		for (int i = 0; i < dataMaster.size(); i++) {
			plantRecordID plant = dataMaster.get(i);
			if (!tree.contains(plant.getYear() + "/" + plant.getBootstrapId())) {
				data.add(dataMaster.get(i));
				tree.add(plant.getYear() + "/" + plant.getBootstrapId());
			}
		}
		
		double[] guess = new double[numParameters + 1];
		for (int i = 0; i <= numParameters; i++) {
			bestStart[i] = 0;
			guess[i] = bestStart[i];
		}

		System.out.print("Determining starting values...");
		guess[0] = 0;
		guess[1] = 800.0;
		guess[2] = 1.86;
		guess[3] = 46.00;
		if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
			guess[4] = -0.0;
		}
		
		for (int i = 0; i < numParameters; i++) {
			stageGameParameters[i + 1] = guess[i + 1];
		}

		int numParams = numParameters;

		System.out.println("f: " + f_to_minimize(guess));

		// calling the estimator
		boolean performEstimation = true;
		if (performEstimation) {
			System.out.println(f_to_minimize(guess)	+ " "
					+ pmUtility.stringPrettyPrint(new Jama.Matrix(guess, 1)));
			System.out.print("Calling CH minimizer\n");
			gibbsLTEGeneralized lte = new gibbsLTEGeneralized(this, 25000, 0, guess);
			guess = lte.getLowestPoint();
			System.out.println(f_to_minimize(guess) + " " + pmUtility.stringPrettyPrint(new Jama.Matrix(guess, 1)));
		}
		

		System.out.print("Writing stage game parameters to vector...\n");
		stageGameParameters = new double[guess.length];
		for (int i = 0; i < guess.length; i++) {
			stageGameParameters[i] = guess[i];
		}
		System.out.print(pmUtility.stringPrettyPrint(new Jama.Matrix(stageGameParameters, 1)) + "\n");

		System.out.println("Cournot f: " + f_to_minimize(guess));
		double[] guess2 = new double[numParams + 1];
		for (int k = 0; k < numParams; k++) {
			guess2[k + 1] = guess[k + 1];
		}

		data = dataMaster;
		tpes.shutdown();

	}

	public ArrayList<plantRecordID> getData() {
		return data;
	}

	public double[] getParameters() {
		return stageGameParameters;
	}

	@Override
	public double f_to_minimize(double[] x) {

		double sumError = 0;
		TreeSet<String> tree = new TreeSet<String>();

		ArrayList<Future<Double>> futureList = new ArrayList<Future<Double>>();

		for (int i = 0; i < data.size(); i++) {
			plantRecordID plant = data.get(i);
			String nextMarket = plant.getBootstrapId() + plant.getYear();
			if (!tree.contains(nextMarket)) {
				futureList.add(tpes.submit(new cournotTask(plant, x,
						priceData, plant.getMarketIndex(), plant.getYear())));
				tree.add(nextMarket);
			}
		}

		try {
			for (int ik = 0; ik < futureList.size(); ik++) {
				sumError += futureList.get(ik).get();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		sumError /= (2.0 * data.size());

		return sumError;
	}

	@Override
	public void gradient(double[] x, double[] g) {
	}

	@Override
	public void hessian(double[] x, double[][] h) {
	}

	@Override
	public double objectiveFunction(double[] x) {
		return -f_to_minimize(x);
	}

	@Override
	public double pi(double[] x) {
		return 1;
	}
	
}
