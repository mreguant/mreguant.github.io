/**
 * cournotSolve.java
 *
 * This function computes the equilibrium of the static
 * capacity-constrained Cournot stage game at given capacities,
 * market characteristics and at a given guess for the production
 * cost parameters.
 * It has functions to obtain the equilibrium outcomes, e.g., price,
 * quantities, revenues, etc.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.production;

import estimation.dataManipulation.plantRecordID;
import estimation.main.EstimationConstants;
import estimation.utility.demandCurve;
import simulation.solve.gibbsLTEGeneralized;
import simulation.solve.mcmcFunction;
import utility.pmUtility;

public class cournotSolve implements mcmcFunction,
		optimization.Uncmin_methods {

	private double[] capacity;
	private int market;
	private Jama.Matrix qVector = new Jama.Matrix(1, 1);	
	private int numFirms;
	private int year;
	private double capacityCost;
	private double marginalCost;
	private double marginalCostDryShifter;
	private double nu;
	private Jama.Matrix profitVector = null;
	private Jama.Matrix revenues = null;
	private Jama.Matrix costs = null;
	private Jama.Matrix profitMargins = null;
	private double price;
	private demandCurve priceData;
	private int[] technologyTypes;
	private plantRecordID currentPlant = null;

	public static void main(String[] args) {
		demandCurve dc = new demandCurve("2", "2.5");
		dc.initializeMeredithEPA();
		cournotSolve qsolver = new cournotSolve(dc);
		
		double[] capacities = { 331.122500, 278.143000, 314.566400, 529.796000,
				612.576700, 827.806300, 794.694000, 355.956700, 456.949100,
				562.908300, 910.586900 };
		int[] technologyTypes = { EstimationConstants.TECH_WET,
				EstimationConstants.TECH_WET, EstimationConstants.TECH_WET,
				EstimationConstants.TECH_WET, EstimationConstants.TECH_WET,
				EstimationConstants.TECH_WET, EstimationConstants.TECH_WET,
				EstimationConstants.TECH_WET, EstimationConstants.TECH_WET,
				EstimationConstants.TECH_WET, EstimationConstants.TECH_DRY };
		
		double[] productionParameters = { 0, 800.0, 1.86, 46.5, 0.0 };

		boolean monopolyTest = false;
		if (monopolyTest) {
			double[] c2 = { 7000 };
			int[] t2 = { EstimationConstants.TECH_DRY };
			capacities = c2;
			technologyTypes = t2;
		}

		boolean duopolyTest = true;
		if (duopolyTest) {
			double[] c2 = { 800, 950 };
			int[] t2 = { EstimationConstants.TECH_DRY, EstimationConstants.TECH_DRY };
			capacities = c2;
			technologyTypes = t2;
		}
		int market = 18;
		qsolver.year = 2000;
		System.out.println(qsolver.priceData.getPrice(3000.0, market,qsolver.year));
		for (productionParameters[3] = 25.0; productionParameters[3] <= 75.0; productionParameters[3] += 5.0) {
			System.out.println("\nMarginal cost = " + productionParameters[3]);
			qsolver.getQ(capacities, productionParameters, qsolver.year, market, technologyTypes);
			System.out.print("Quantities: ");
			pmUtility.prettyPrintVector(qsolver.getQVector());
			System.out.print("Profits: ");
			pmUtility.prettyPrintVector(qsolver.getProfitVector());
			System.out.print("Margins: ");
			pmUtility.prettyPrintVector(qsolver.getProfitMargins());
			System.out.println("Price: " + qsolver.getPrice());
		}
	}

	/**
	 * Creates a new instance of cournotTestbed
	 */
	public cournotSolve(demandCurve priceData) {
		this.priceData = priceData;
	}

	public double getQ(double[] capacities, double[] productionParams,
			int year, int stateIndex, int[] technologyTypes) {
		this.year = year;
		this.market = stateIndex;
		this.technologyTypes = technologyTypes;

		capacityCost = Math.max(1E-10, productionParams[1]);
		double bindingLevel = productionParams[2];
		marginalCost = productionParams[3];
		if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
			marginalCostDryShifter = productionParams[4];
		}
		nu = Math.exp(bindingLevel) / (1.0 + Math.exp(bindingLevel));

		numFirms = capacities.length;
		capacity = new double[numFirms + 1];

		for (int i = 0; i < numFirms; i++) {
			capacity[i + 1] = capacities[i];
		}
		return execute();
	}

	public double getQ(plantRecordID plant, double[] productionParams) {
		this.market = plant.getMarketIndex();
		this.currentPlant = plant;
		this.year = plant.getYear();

		capacityCost = Math.max(1E-10, productionParams[1]);
		double bindingLevel = productionParams[2];
		marginalCost = productionParams[3];
		if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
			marginalCostDryShifter = productionParams[4];
		}
		nu = Math.exp(bindingLevel) / (1.0 + Math.exp(bindingLevel));

		numFirms = plant.getNumFirms();
		capacity = new double[numFirms + 1];
		this.technologyTypes = plant.getMarketTechnologyArray();

		for (int i = 0; i < numFirms; i++) {
			capacity[i + 1] = plant.getCapacity(i);
		}
		return execute();
	}

	private double execute() {
		boolean debug = false;

		optimization.Uncmin_f77 minimizer = new optimization.Uncmin_f77(false);
		int numParams = numFirms;
		double[] guess = new double[numParams + 1];
		double[] xpls = new double[numParams + 1];
		double[] fpls = new double[2];
		double[] gpls = new double[numParams + 1];
		int[] itrmcd = new int[2];
		double[][] a = new double[numParams + 1][numParams + 1];
		double[] udiag = new double[numParams + 1];
		double[] typsiz = new double[numParams + 1];
		for (int i = 0; i < numFirms; i++) {
			typsiz[i + 1] = 1;
			guess[i + 1] = 0.7 * capacity[i+1];
		}
		double[] fscale = { 0, 1E-16 };
		int[] method = { 0, 1 };
		int[] iexp = { 0, 0 };
		int[] msg = { 0, 1 };
		int[] ndigit = { 0, 15 };
		int[] itnlim = { 0, 150 };
		int[] iagflg = { 0, 0 };
		int[] iahflg = { 0, 0 };
		double[] dlt = { 0, 1 };
		double[] gradtl = { 0, 1E-8 };
		double[] stepmx = { 0, 1E8 };
		double[] steptl = { 0, 1E-8 };

		boolean useLTE = false;
		if (useLTE) {
			gibbsLTEGeneralized lte = new gibbsLTEGeneralized(this, 150, 0, guess);
			guess = lte.getLowestPoint();
		}

		minimizer.optif9_f77(numParams, guess, this, typsiz, fscale,
				method, iexp, msg, ndigit, itnlim, iagflg, iahflg, dlt,
				gradtl, stepmx, steptl, xpls, fpls, gpls, itrmcd, a, udiag);
		
		double marketQ = 0;
		for (int i = 1; i < guess.length; i++) {
			marketQ += guess[i];
		}

		if (debug) {
			System.out.println("Computing price");
		}
		price = priceData.getPrice(marketQ, market, year);
		if (Double.isInfinite(price)) {
			price = 0;
		}
		if (debug) {
			System.out.println("Price should be " + price);
		}
		setPrice(price);

		double penalty = 0;
		qVector = new Jama.Matrix(numFirms, 1);
		profitVector = new Jama.Matrix(numFirms, 1);
		costs = new Jama.Matrix(numFirms, 1);
		revenues = new Jama.Matrix(numFirms, 1);
		profitMargins = new Jama.Matrix(numFirms, 1);

		for (int j = 0; j < numFirms; j++) {
			if (guess[j] > capacity[j] * nu) {
				penalty = capacityCost
						* Math.pow((guess[j] / capacity[j]) - nu, 2);
			}
			double mc_j = marginalCost;
			if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC
					&& technologyTypes[j] == EstimationConstants.TECH_DRY) {
				mc_j += marginalCostDryShifter;
			}
			profitVector.set(j, 0, guess[j + 1] * (price - mc_j) - penalty);
			revenues.set(j, 0, guess[j + 1] * price);
			costs.set(j, 0, guess[j + 1] * mc_j + penalty);
			profitMargins.set(j, 0, profitVector.get(j, 0) / revenues.get(j, 0));
			qVector.set(j, 0, guess[j + 1]);
		}

		if (debug) {
			System.out.println("MarketQ: " + marketQ + " Price: " + price
					+ " Revenue: " + revenues.get(0, 0) + " Costs: " + costs.get(0, 0));
			System.out.print("Profit vector: ");
			pmUtility.prettyPrintVector(profitVector);
		}

		return guess[1];
	}

	public Jama.Matrix getQVector() {
		return qVector;
	}

	public Jama.Matrix getProfitVector() {
		return profitVector;
	}

	public void setProfitVector(Jama.Matrix profitVector) {
		this.profitVector = profitVector;
	}

	public Jama.Matrix getProfitMargins() {
		return profitMargins;
	}

	public void setProfitMargins(Jama.Matrix profitMargins) {
		this.profitMargins = profitMargins;
	}

	public Jama.Matrix getCosts() {
		return costs;
	}

	public void setCosts(Jama.Matrix costs) {
		this.costs = costs;
	}

	public Jama.Matrix getRevenues() {
		return revenues;
	}

	public void setRevenues(Jama.Matrix revenues) {
		this.revenues = revenues;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public double f_to_minimize(double[] x) {
		boolean debug = !true;
		for (int i = 1; i < x.length; i++) {
			if (Double.isNaN(x[i])) {
				System.out.println(currentPlant);
				System.out.println(x[i]);
				System.exit(0);
				return 1E10;
			}
		}
		for (int i = 1; i < x.length; i++) {
			x[i] = Math.max(1E-16, x[i]); // need to bound quantities to be
											// positive
			x[i] = Math.min(x[i], capacity[i]);
		}

		double error = 0;
		double qAll = 0;
		if (debug) {
			System.out.println("----");
			System.out.print("  x:\t");
			pmUtility.prettyPrint(new Jama.Matrix(x, 1));
			System.out.print("cap:\t");
			pmUtility.prettyPrint(new Jama.Matrix(capacity, 1));
		}

		double[] vecMR = new double[capacity.length];
		double[] vecMC = new double[capacity.length];
		double[] vecNu = new double[capacity.length];
		for (int i = 1; i < x.length; i++) {
			qAll += x[i];
		}
		double priceInside = priceData.getPrice(qAll, market, year);
		double pricePrime = priceData.getPricePrime(qAll, market, year);

		if (debug) {
			System.out.println("Domestic q: " + qAll);
			System.out.println("Market price: " + priceInside);
			System.out.println("Price prime: " + pricePrime);
		}

		for (int i = 1; i < x.length; i++) {

			double marginalRevenue = priceInside + x[i] * pricePrime;

			double mcp = 0;
			double capacityUtilizationRate = x[i] / capacity[i];
			if (capacityUtilizationRate > nu) {
				mcp = Math.min(2.0 * capacityCost
						* ((x[i] / capacity[i]) - (nu)), 2000.0);
			}

			double mc_i = marginalCost;
			if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC
					&& technologyTypes[i - 1] == EstimationConstants.TECH_DRY) {
				mc_i += marginalCostDryShifter;
			}

			if (capacity[i] > 0) {
				error += Math.pow(marginalRevenue - (mc_i + mcp), 2);
			}
			vecMR[i] = marginalRevenue;
			vecMC[i] = mc_i + mcp;
			vecNu[i] = nu * capacity[i];
		}
		if (debug) {
			System.out.print(" nu:\t");
			pmUtility.prettyPrint(new Jama.Matrix(vecNu, 1));
			System.out.print(" MR:\t");
			pmUtility.prettyPrint(new Jama.Matrix(vecMR, 1));
			System.out.print(" MC:\t");
			pmUtility.prettyPrint(new Jama.Matrix(vecMC, 1));
			System.out.println("f: " + error);
		}
		return error;
	}

	@Override
	public double objectiveFunction(double[] x) {
		return -f_to_minimize(x);
	}

	@Override
	public double pi(double[] x) {
		return 1;
	}

	@Override
	public void gradient(double[] x, double[] g) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void hessian(double[] x, double[][] h) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
}