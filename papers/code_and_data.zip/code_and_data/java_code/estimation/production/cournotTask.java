/**
 * cournotTask.java
 * 
 * This file gives back the error term of a particular
 * observation of the moment conditions used in the estimation
 * of marginal costs at a given guess of parameters.
 * Predicted quantities and first-order condition moments are
 * used in the estimation.
 * The code calls cournotSolve.java to actually solve for the
 * equilibrium of the stage game.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.production;

import estimation.dataManipulation.plantRecordID;
import estimation.main.EstimationConstants;
import estimation.utility.demandCurve;

import java.util.ArrayList;
import java.util.concurrent.Callable;

class cournotTask implements Callable<Double> {

	private plantRecordID plant = null;
	private double[] productionCostParameters;
	private demandCurve priceData;
	private int state;
	private int year;

	public cournotTask(plantRecordID plant, double[] productionCostParameters,
			demandCurve priceData, int state, int year) {
		this.plant = plant;
		this.priceData = priceData;
		this.productionCostParameters = productionCostParameters;
		this.state = state;
		this.year = year;
	}

	@Override
	public Double call() {

		double error = 0;

		// Quantity moments
		cournotSolve sc = new cournotSolve(priceData);
		sc.getQ(plant, productionCostParameters);
		Jama.Matrix qhat = sc.getQVector();
		Jama.Matrix actual = plant.getMarketQuantityVector();
		for (int j = 0; j < plant.getNumFirms(); j++) {
			error += Math.pow(qhat.get(j, 0) - actual.get(j, 0), 2);
		}

		// Price moments (FOC)		
		double qAll = 0;
		double capacityCost = Math.max(1E-10, productionCostParameters[1]);
		double bindingLevel = productionCostParameters[2];
		double marginalCost = productionCostParameters[3];
		double marginalCostShifter = 0.0;
		if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC) {
			marginalCostShifter = productionCostParameters[4];
		}
		double nu = Math.exp(bindingLevel) / (1.0 + Math.exp(bindingLevel));

		int[] technologyTypes = plant.getMarketTechnologyArray();
		ArrayList<Double> quantities = plant.getMarketQuantities();
		int numFirms = plant.getNumFirms();

		double[] capacity = new double[numFirms + 1];
		double[] x = new double[numFirms + 1];
		for (int i = 0; i < numFirms; i++) {
			capacity[i + 1] = plant.getCapacity(i);
			x[i + 1] = quantities.get(i);
		}
		for (int i = 1; i < x.length; i++) {
			qAll += x[i];
		}

		double priceInside = priceData.getPrice(qAll, state, year);
		double pricePrime = priceData.getPricePrime(qAll, state, year);

		for (int i = 1; i < x.length; i++) {
			double mcp = 0;
			double capacityUtilizationRate = x[i] / capacity[i];

			double marginalRevenue = priceInside + x[i] * pricePrime;

			if (capacityUtilizationRate > nu) {
				mcp = 2.0 * capacityCost * (capacityUtilizationRate - nu);
			}

			double mc_i = marginalCost;
			if (EstimationConstants.DIFFERENTIATE_PRODUCTION_TECHNOLOGY_MC
					&& technologyTypes[i - 1] == EstimationConstants.TECH_DRY) {
				mc_i += marginalCostShifter;
			}

			if (capacity[i] > 0) {
				error += .1*Math.pow(marginalRevenue - (mc_i + mcp), 2);
			}
		}
		
		return error;
	}
}
