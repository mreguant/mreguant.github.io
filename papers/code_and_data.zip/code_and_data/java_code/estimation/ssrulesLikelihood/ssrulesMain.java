/**
 * ssrulesMain.java
 *
 * Estimates the investment parameters.
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.ssrulesLikelihood;

import estimation.dataManipulation.plantRecordID;
import estimation.main.EstimationConstants;
import estimation.utility.demandCurve;

import java.io.*;
import java.util.ArrayList;
import java.util.TreeSet;

import JSci.maths.statistics.NormalDistribution;
import optimization.Uncmin_methods;
import utility.pmUtility;

public class ssrulesMain implements Uncmin_methods {

	private int numPeriods = EstimationConstants.END_YEAR - EstimationConstants.START_YEAR + 1;
	private ArrayList<plantRecordID> data;
	private ArrayList<ArrayList<plantRecordID>> properData = new ArrayList<ArrayList<plantRecordID>>();
	private investmentParametersContainer policyParams;
	private Jama.Matrix betaTarget, betaBand;
	static NormalDistribution standardNormal = new NormalDistribution();
	private double cutoff = 0.0;
	private int sim;

	public investmentParametersContainer getParameters() {
		return policyParams;
	}

	public ssrulesMain(int simnum) {

		sim = simnum;
		
		System.out.println("Entering ssruleMain");
		data = new ArrayList<plantRecordID>();
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(
					new File("data/estimation/dataEstimation"+sim+".dat")));
			int numObs = (Integer) in.readObject();

			for (int i = 0; i < numObs; i++) {
				data.add((plantRecordID) in.readObject());
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		processData();
		System.out.println("Data processed.");

		cutoff = EstimationConstants.INVESTMENT_CUTOFF_LEVEL;
		
		int change = 0;
		int entryCount = 0;
		int exitCount = 0;

		double numInvestments = 0;
		double averageDivestmentSize = 0;
		double averageDivestmentPercentage = 0;
		double averageInvestmentSize = 0;
		double averageInvestmentPercentage = 0;
		double numDivestments = 0;

		for (ArrayList<plantRecordID> subdata : properData) {
			for (int j = 1; j < subdata.size(); j++) {
				plantRecordID p2 = subdata.get(j);
				plantRecordID p1 = subdata.get(j - 1);
				double pct_change = (p2.getPlantCapacity() - p1.getPlantCapacity()) / p1.getPlantCapacity();

				if (Math.abs(pct_change) > cutoff && p2.getYear() == p1.getYear() + 1) {
					change++;
					if (pct_change < 0) {
						averageDivestmentSize += (p2.getPlantCapacity() - p1.getPlantCapacity());
						averageDivestmentPercentage += pct_change;
						numDivestments++;
					} else {
						numInvestments++;
						averageInvestmentSize += (p2.getPlantCapacity() - p1.getPlantCapacity());
						averageInvestmentPercentage += pct_change;
					}
				}
				if (j == 1 && subdata.get(0).getYear() > EstimationConstants.START_YEAR) { 
					// this guy enters some time during the sample
					change++;
					entryCount++;
					System.out.println("Counting entry for plant ID: " + p1.getPlantID() + " year: " + p1.getYear());					
				}
				if (j == (subdata.size() - 1) && p2.getYear() < EstimationConstants.END_YEAR) {
					exitCount++;
					System.out.println("Counting exit for plant ID: " + p2.getPlantID() + " year: " + p2.getYear());
				}
			}
		}

		averageDivestmentSize /= numDivestments;
		averageDivestmentPercentage /= numDivestments;
		averageInvestmentSize /= numInvestments;
		averageInvestmentPercentage /= numInvestments;

		System.out.println("Tabulated " + entryCount + " entries.");
		System.out.println("Tabulated " + exitCount + " exits.");

		System.out.println("Cutoff: " + cutoff + " Number of capacity changes: " + change);
		System.out.println("\tNumber Investments: " + numInvestments);
		System.out.println("\tAverage Investment: " + averageInvestmentSize);
		System.out.println("\tAverage Investment Pct Change: " + averageInvestmentPercentage);
		System.out.println("\tNumber Divestments: " + numDivestments);
		System.out.println("\tAverage Divestment: " + averageDivestmentSize);
		System.out.println("\tAverage Divestment Pct Change: " + averageDivestmentPercentage);

		int numExplanatoryVariables = 2;

		Jama.Matrix stackedTarget = new Jama.Matrix(change, 1);
		Jama.Matrix stackedExplanatory = new Jama.Matrix(change,numExplanatoryVariables+2);
		Jama.Matrix stackedBand = new Jama.Matrix(change-entryCount, 1);
		Jama.Matrix stackedExplanatoryBand = new Jama.Matrix(change-entryCount,numExplanatoryVariables+1);		

		int stackCount = 0;
		int stackCountBand = 0;
		entryCount = 0;
		/**
		 * Now recall that properData contains lists of plantRecordIDs in runs
		 * that accord with a specific plant state-zip identifier.
		 */
		for (int i = 0; i < properData.size(); i++) {
			ArrayList<plantRecordID> subdata = properData.get(i);
			/**
			 * Loop through the list of plantRecordIDs, starting at t=1 because
			 * we have to get t-1 in order to figure out how much the capacity
			 * changed.
			 */
			
			for (int j = 1; j < subdata.size(); j++) {
				plantRecordID p2 = subdata.get(j);
				plantRecordID p1 = subdata.get(j - 1);
				double pct_change = (p2.getPlantCapacity() - p1.getPlantCapacity()) / p1.getPlantCapacity();
				if (Math.abs(pct_change) > cutoff && p2.getYear() == p1.getYear() + 1) {
					stackedExplanatory.set(stackCount, 0, (p1.getPlantCapacity() + p1.getCompetitorsCapacity())
							/demandCurve.maxCapacityMarket[p1.getMarketIndex()]);
					stackedExplanatory.set(stackCount, 1, Math.log(p1.getPlantCapacity() + 1.0));
					stackedExplanatory.set(stackCount, 2, 0.0);
					stackedExplanatory.set(stackCount, 3, 1.0);
					stackedTarget.set(stackCount, 0, Math.log(p2.getPlantCapacity() + 1.0));
					
					stackedExplanatoryBand.set(stackCountBand, 0, (p1.getPlantCapacity() + p1.getCompetitorsCapacity())
							/demandCurve.maxCapacityMarket[p1.getMarketIndex()]);
					stackedExplanatoryBand.set(stackCountBand, 1, Math.log(p1.getPlantCapacity() + 1.0));
					stackedExplanatoryBand.set(stackCountBand, 2, 1.0);
					stackedBand.set(stackCountBand, 0, Math.log(Math.abs(p2.getPlantCapacity() - p1.getPlantCapacity()) + 1.0));
					stackCount++;
					stackCountBand++;
				}
				if (j == 1 && p1.getYear() > EstimationConstants.START_YEAR) {
					// this is considered an entrant in the data
					stackedExplanatory.set(stackCount, 0, p1.getCompetitorsCapacity()/demandCurve.maxCapacityMarket[p1.getMarketIndex()]);		
					stackedExplanatory.set(stackCount, 1, 0.0);
					stackedExplanatory.set(stackCount, 2, 1.0);
					stackedExplanatory.set(stackCount, 3, 1.0);
					stackedTarget.set(stackCount, 0, Math.log(p1.getPlantCapacity()));
					
					entryCount++;
					stackCount++;
				}
			}
		}

		// run regressions
		Jama.Matrix basisX = stackedExplanatory;
		Jama.Matrix basisXband = stackedExplanatoryBand;

		// BAND
		betaBand = pmUtility.OLSsvd(basisXband, stackedBand, false);
		System.out.println("OLS estimate for band equation:");
		pmUtility.prettyPrintVector(betaBand);
		System.out.println(pmUtility.mean(stackedTarget,0) + " " + pmUtility.min(stackedExplanatory,0) + " "+ pmUtility.mean(stackedExplanatory,1));
		System.out.println(pmUtility.mean(stackedBand,0) + " " + pmUtility.min(stackedExplanatoryBand,0)+ " "+ pmUtility.mean(stackedExplanatoryBand,1));
		
		Jama.Matrix bandFit = basisXband.times(betaBand);
		Jama.Matrix bandError = stackedBand.minus(bandFit);
		double varianceBandEquation = 0;
		for (int i = 0; i < bandFit.getRowDimension(); i++) {
			varianceBandEquation += bandError.get(i, 0) * bandError.get(i, 0);
		}
		varianceBandEquation /= (bandFit.getRowDimension() - betaBand.getColumnDimension());
		System.out.println("Estimated variance of error term in band: " + varianceBandEquation);

		// TARGET
		betaTarget = pmUtility.OLSsvd(basisX, stackedTarget, false);	
		System.out.println("OLS estimate for target equation:");
		pmUtility.prettyPrintVector(betaTarget);
		
		Jama.Matrix targetFit = basisX.times(betaTarget);
		Jama.Matrix targetError = stackedTarget.minus(targetFit);
		double varianceTargetEquation = 0;
		for (int i = 0; i < targetFit.getRowDimension(); i++) {
			varianceTargetEquation += targetError.get(i, 0) * targetError.get(i, 0);
		}
		varianceTargetEquation /= (targetFit.getRowDimension() - betaTarget.getColumnDimension());
		System.out.println("Estimated variance of error term in target: " + varianceTargetEquation);		
		
		boolean test = false;
		if (test) {
			System.out.println("Examples of predictions");
			double[] cap1 = {0, 0, 250, 250, 1250, 1250, 2500, 2500, 2500};
			double[] otherscap = {0.2, 0.8, 0.5, 0.8, 0.5, 0.8, 0.5, 0.8, 1.2};
			for (int c = 0; c < cap1.length; c++) {
				double entry = 0.0;
				if (cap1[c] == 0) {
					entry = 1.0;					
				}
				double target0_0 = otherscap[c] * betaTarget.get(0,0) + Math.log(cap1[c]+1) * betaTarget.get(1, 0)
									+ entry * betaTarget.get(2,0) + betaTarget.get(3, 0);
				double band0_0 =  otherscap[c] * betaBand.get(0,0) + Math.log(cap1[c]+1) * betaBand.get(1, 0)
									+ betaBand.get(2, 0);	
				System.out.println("Target for ("+cap1[c]+","+otherscap[c]+"): " + target0_0
						+ " exp(target): " + Math.exp(target0_0) + " change: " + (Math.exp(target0_0)-cap1[c]));
				System.out.println("Band Size for ("+cap1[c]+","+otherscap[c]+"): " + band0_0
						+ " exp(band): " + Math.exp(band0_0));
				System.out.println();
			}
		}

		/**
		 * Store results in container object.
		 */
		policyParams = new investmentParametersContainer(betaBand, betaTarget, varianceBandEquation, varianceTargetEquation);

		System.out.println("Finished running ssrule estimation.");
	}

	public void processData() {
		try {

			BufferedWriter outExit = new BufferedWriter(new FileWriter("data/estimation/exit"+sim+".csv"));
			BufferedWriter outEntry = new BufferedWriter(new FileWriter("data/estimation/entry"+sim+".csv"));
			BufferedWriter outAll = new BufferedWriter(new FileWriter("data/estimation/alldata"+sim+".csv"));
			outAll.write("id,name,market,bootid,year,capacity,numFirms,blank,blank,dailyCapacity,CompetitorsCapacity\n");
			outExit.write("exit,id,name,market,bootid,quantity,year,capacity,numFirms,blank,blank,dailyCapacity,CompetitorsCapacity\n");
			outEntry.write("market,year,entry,marketCapacity,blank\n");
			TreeSet<Integer> tree = new TreeSet<Integer>();
			
			/**
			 * Q. What does the plant ID look like? A. Now hand-coded identifier
			 */
			for (plantRecordID p : data) {
				tree.add(p.getPlantID());
			}
			ArrayList<marketYearData> marketYearList = new ArrayList<marketYearData>();
			for (plantRecordID p : data) {
				int index = marketYearList.indexOf(new marketYearData(p));
				if (index < 0) {
					// new market-year combination
					marketYearList.add(new marketYearData(p));
				} else {
					marketYearList.get(index).add(p);
				}
			}
			
			/**
			 * Now go through every plant again, check to see if it was an
			 * entrant at any point, and if so, add that information to the
			 * relevant marketYearData.
			 */

			/*
			 * Keep track of exit counts
			 */
			ArrayList<Integer> idlist = new ArrayList<Integer>(tree);
			for (int i = 0; i < idlist.size(); i++) {
				Integer matchID = idlist.get(i);
				/**
				 * Firm array is going to hold copies of all records of each
				 * plant, as defined by the state-zip identifier.
				 */
				ArrayList<plantRecordID> firmArray = new ArrayList<plantRecordID>();
				for (plantRecordID p : data) {
					if (p.getPlantID() == matchID) {
						firmArray.add(p.deepCopy());
					}
				}
				if (firmArray.size() > 25) {
					System.out.println("More than one entry per company and market!!!: " + firmArray.size());
				}
				/**
				 * properData is a list that holds all of these records
				 * together.
				 */				
				properData.add(firmArray);
				for (int c = 0; c < firmArray.size(); c++) {
					outAll.write(firmArray.get(c).toStringEntryExit() + "\n");
				}
				if (firmArray.size() == numPeriods) {
					for (int c = 0; c < firmArray.size(); c++) {
						outExit.write(0 + ","+ firmArray.get(c).toStringEntryExit() + "\n");
					}
				} else {
					for (int c = 0; c < firmArray.size() - 1; c++) {
						int year = (firmArray.get(c)).getYear();
						int nextYear = (firmArray.get(c + 1)).getYear();
						if ((nextYear - year) == 1) {
							outExit.write(0 + "," + firmArray.get(c).toStringEntryExit() + "\n");
						} else {
							outExit.write(1 + "," + firmArray.get(c).toStringEntryExit() + "\n");
						}
					}
					int year = (firmArray.get(firmArray.size() - 1)).getYear();
					if (year != EstimationConstants.END_YEAR) {
						outExit.write(1 + "," + firmArray.get(firmArray.size() - 1).toStringEntryExit() + "\n");
					} else {
						outExit.write(0 + "," + firmArray.get(firmArray.size() - 1).toStringEntryExit() + "\n");
					}
					plantRecordID p0 = firmArray.get(0);
					if (p0.getYear() != EstimationConstants.START_YEAR) {
						// add to the relevant marketYearData
						for (marketYearData m : marketYearList) {
							if (m.getYear() == p0.getYear() - 1) {
								if (m.getState().equalsIgnoreCase(p0.getBootstrapId())) {
									// this would be the market one year earlier
									m.setEntry(true);
								}
							}
						}
					}
				}
			}

			/**
			 * Now go through all the marketYearData and output relevant entry
			 * information
			 */
			for (marketYearData m : marketYearList) {
				outEntry.write(m.outputEntryInformation());
			}

			outExit.close();
			outEntry.close();
			outAll.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("size of investment data: " + properData.size());
	}
	
	@Override
	public double f_to_minimize(double[] x) {
		double llh = 0.0;		
		//llh -= Math.log(getLikelihood(x, v));		
		return llh;
	}

	@Override
	public void gradient(double[] x, double[] g) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void hessian(double[] x, double[][] h) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
	public double getLikelihood(double[] x, double[] v) {
		if (v[0] == 1) {
			return standardNormal.cumulative(x[1] + x[2]
					* Math.log(v[1] + 1.0) + x[3] * v[2]);
		} else {
			return 1.0 - standardNormal.cumulative(x[1] + x[2]
					* Math.log(v[1] + 1.0) + x[3] * v[2]);
		}
	}
}
