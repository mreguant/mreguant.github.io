/**
 * marketYearData.java
 * 
 * Calculates and stores information at the market-year level. 
 * 
 * Copyright (c) 2014 Meredith Fowlie, Mar Reguant, and Stephen P. Ryan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package estimation.ssrulesLikelihood;

import estimation.dataManipulation.plantRecordID;

import java.util.ArrayList;


class marketYearData {

	int year;
	int market;
	String bootid;
	String state;
	ArrayList<Integer> plantIDList = new ArrayList<Integer>();
	double marketCapacity = 0;
	boolean entryThisPeriod = false; // i am defining this so that if a firm
										// shows up next period, it counts as
										// entering in this period

	marketYearData(plantRecordID p) {
		year = p.getYear();
		state = p.getBootstrapId().toString();
		bootid = p.getBootstrapId();
		market = p.getMarketIndex();
		plantIDList.add(p.getPlantID());
		marketCapacity += p.getPlantCapacity();
	}

	void add(plantRecordID p) {
		plantIDList.add(p.getPlantID());
		marketCapacity += p.getPlantCapacity();
	}

	public int getYear() {
		return year;
	}

	public String getState() {
		return state;
	}

	public String getBootId() {
		return bootid;
	}

	void setEntry(boolean b) {
		entryThisPeriod = b;
	}

	String outputEntryInformation() {
		int entryIndicator = 0;
		if (entryThisPeriod) {
			entryIndicator = 1;
		}
		String s = market + "," + year + "," + entryIndicator + ","
				+ marketCapacity + "," + 0 + "\n";
		return s;
	}

	@Override
	public boolean equals(Object o) {
		marketYearData m = (marketYearData) o;
		if (m.getState().equalsIgnoreCase(getState())
				&& m.getYear() == getYear() 
				&& m.getBootId().contentEquals(getBootId()) ) {
			return true;
		}
		return false;
	}
}
